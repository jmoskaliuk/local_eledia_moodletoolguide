<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * German language strings.
 *
 * @package    local_toolguide
 * @copyright  2026 eLeDia GmbH
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Moodle Tool Guide';
$string['toolguide'] = 'Tool Guide';
$string['toolguide:view'] = 'Tool Guide anzeigen';
$string['toolguide:viewfab'] = 'Schaltfläche „Tool Guide“ auf allen Seiten sehen';
$string['pagetitle'] = 'Moodle Tool Guide – Interaktiv';
$string['pagedesc'] = 'Finden Sie die passende Moodle-Aktivität für Ihr didaktisches Ziel.';
$string['fab_title'] = 'Moodle Tool Guide öffnen';
$string['fab_label'] = 'Moodle Tool Guide';
$string['privacy:metadata'] = 'Das Plugin Moodle Tool Guide speichert keine personenbezogenen Daten.';
