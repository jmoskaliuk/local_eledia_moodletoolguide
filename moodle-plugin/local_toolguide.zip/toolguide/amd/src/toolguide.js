/* eslint-disable */
/* Auto-generated from Prototyp_ToolGuide.html — do not edit by hand. */
(function() {
  "use strict";
  if (typeof React === "undefined" || typeof ReactDOM === "undefined") {
    console.error("[local_toolguide] React/ReactDOM not loaded");
    return;
  }
  // Inject component-scoped styles into the host page.
  var __tgStyle = document.createElement("style");
  __tgStyle.textContent = "*, *::before, *::after { box-sizing: border-box; }\n#toolguide-root { font-family: Inter, system-ui, -apple-system, sans-serif; color: #353535; }\n#toolguide-root ::selection { background: #F98012; color: white; }\n#toolguide-root button:focus-visible, #toolguide-root a:focus-visible { outline: 3px solid #F98012; outline-offset: 2px; }\nhtml.hc #toolguide-root, html.hc #toolguide-root * { background: #000 !important; color: #fff !important; }\nhtml.hc #toolguide-root a { color: #FCBC82 !important; text-decoration: underline !important; }\nhtml.hc #toolguide-root button[aria-pressed=\"true\"] { background: #FCBC82 !important; color: #000 !important; border-color: #FCBC82 !important; }\n@media (prefers-reduced-motion: reduce) { #toolguide-root *, #toolguide-root *::before, #toolguide-root *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; } }";
  document.head.appendChild(__tgStyle);

const { useState, useMemo } = React;

const TOOLS = [
  { id:"datei", name:"Datei", desc:"Datei hochladen (z.B. Word, PDF, PowerPoint)", complexity:"einfach", complexityText:"Einfach wie ein E-Mail Anhang. Aber machen Dateien f\u00fcr sich alleine Sinn?", bloom:"1/6",setup:"einfach",setupText:"Datei hochladen, fertig.",support:"gering",supportText:"Keine laufende Pflege nötig.", docsUrl:"https://docs.moodle.org/501/de/Datei", longDesc:"Mit der Aktivit\u00e4t \u00abDatei\u00bb stellen Sie Kursteilnehmenden einzelne Dateien zum Download bereit \u2013 PDFs, Word-Dokumente, Pr\u00e4sentationen oder Bilder. Die Datei erscheint direkt auf der Kursseite und kann per Klick ge\u00f6ffnet oder heruntergeladen werden. Dateien eignen sich besonders f\u00fcr Skripte, Arbeitsbl\u00e4tter und erg\u00e4nzende Materialien. Beachten Sie, dass Dateien allein keine Interaktion erm\u00f6glichen. Kombinieren Sie sie mit Foren oder Aufgaben, um den Lernprozess aktiv zu gestalten.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Lehrende laden Dateien zur Information hoch."}, bewerten:{r:"rot",t:"Nein. Stattdessen: Kenntnisse \u00fcber Forum oder Aufgabe erfassen."}, komm:{r:"rot",t:"Nein. Keine direkte Option zur Interaktion oder Kommunikation."}, collab:{r:"rot",t:"Nein. Stattdessen: Foren, Wikis und Glossare nutzen."}, bloomG:{r:"rot",t:"Ist keine Lernaktivit\u00e4t, sondern reine Infovermittlung."}}},
  { id:"verzeichnis", name:"Verzeichnis", desc:"Eine Reihe von Dateien hochladen", complexity:"einfach", complexityText:"Einfach wie ein E-Mail Anhang. Aber machen Dateien alleine Sinn?", bloom:"1/6",setup:"einfach",setupText:"Ordner anlegen, Dateien einsortieren.",support:"gering",supportText:"Bei Änderungen Dateien ersetzen.", docsUrl:"https://docs.moodle.org/501/de/Verzeichnis", longDesc:"Ein Verzeichnis b\u00fcndelt mehrere Dateien in einem Ordner auf der Kursseite. Teilnehmende k\u00f6nnen den gesamten Ordner oder einzelne Dateien herunterladen. Das ist praktisch, wenn Sie eine Sammlung von Dokumenten zu einem Thema bereitstellen m\u00f6chten. Verzeichnisse halten die Kursseite \u00fcbersichtlich, wenn viele Dateien ben\u00f6tigt werden. Wie bei Einzeldateien ist keine direkte Interaktion m\u00f6glich \u2013 es ist ein reines Bereitstellungs-Tool.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Dateien in Ordner hochladen ist Trainer/innensache."}, bewerten:{r:"rot",t:"Nein. Stattdessen: Kenntnisse \u00fcber Forum oder Aufgabe erfassen."}, komm:{r:"rot",t:"Nein. Keine direkte Option zur Interaktion."}, collab:{r:"orange",t:"Sammeln und Teilen von Dateien m\u00f6glich. Erfordert Rollenanpassung."}, bloomG:{r:"rot",t:"Ist keine Lernaktivit\u00e4t, sondern reine Infovermittlung."}}},
  { id:"textseite", name:"Textseite", desc:"Eine Seite mit Texten in Moodle erstellen", complexity:"einfach", complexityText:"Einfach. Text formatieren, Bilder und Videos erg\u00e4nzen.", bloom:"2/6",setup:"einfach",setupText:"Im Editor schreiben – wie ein Word-Dokument.",support:"gering",supportText:"Selten zu aktualisieren.", docsUrl:"https://docs.moodle.org/501/de/Textseite", longDesc:"Eine Textseite erm\u00f6glicht es, Inhalte direkt in Moodle zu erstellen \u2013 mit formatiertem Text, Bildern, Videos und Links. Im Gegensatz zur Datei m\u00fcssen Teilnehmende nichts herunterladen, sondern lesen alles direkt im Browser. Textseiten eignen sich f\u00fcr Einleitungen, Anleitungen oder kurze Informationseinheiten. Sie k\u00f6nnen multimedial angereichert werden und sind sofort sichtbar. F\u00fcr umfangreichere Inhalte empfiehlt sich die Aktivit\u00e4t \u00abBuch\u00bb.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Nur Lehrende erstellen diese Seiten."}, bewerten:{r:"rot",t:"Nein. Stattdessen: Kenntnisse \u00fcber Forum oder Aufgabe erfassen."}, komm:{r:"rot",t:"Nein. Keine direkte Option zur Interaktion."}, collab:{r:"orange",t:"Gemeinsames Erstellen m\u00f6glich. Erfordert Rollenanpassung."}, bloomG:{r:"rot",t:"Ist keine Lernaktivit\u00e4t, sondern reine Infovermittlung."}}},
  { id:"buch", name:"Buch", desc:"Eine Reihe von Textseiten in Moodle erstellen", complexity:"einfach", complexityText:"Einfach. Text formatieren, Bilder und Videos erg\u00e4nzen.", bloom:"2/6",setup:"mittel",setupText:"Kapitelstruktur planen, dann befüllen.",support:"gering",supportText:"Selten zu aktualisieren.", docsUrl:"https://docs.moodle.org/501/de/Buch", longDesc:"Ein Buch besteht aus mehreren Textseiten mit Kapiteln und Unterkapiteln. Es eignet sich hervorragend f\u00fcr l\u00e4ngere, strukturierte Inhalte wie Skripte oder Leitf\u00e4den. Teilnehmende k\u00f6nnen zwischen den Seiten bl\u00e4ttern und das gesamte Buch ausdrucken. Das Buch bietet eine \u00fcbersichtliche Navigation \u00fcber ein Inhaltsverzeichnis. Es ist ein reines Lese-Material und enth\u00e4lt keine interaktiven Elemente.", goals:{ info:{r:"gr\u00fcn",t:"Gutes Tool zur Vermittlung von Informationen. Drucken m\u00f6glich."}, bewerten:{r:"rot",t:"Nein. Stattdessen: Lektion, Forum oder Aufgabe nutzen."}, komm:{r:"rot",t:"Nein. Keine direkte Option zur Interaktion."}, collab:{r:"orange",t:"Gemeinsames Erstellen m\u00f6glich. Erfordert Rollenanpassung."}, bloomG:{r:"rot",t:"Ist keine Lernaktivit\u00e4t, sondern reine Infovermittlung."}}},
  { id:"url", name:"URL", desc:"Link zu einer Webseite", complexity:"einfach", complexityText:"Einfach. Web-Adresse finden und einf\u00fcgen.", bloom:"2/6",setup:"einfach",setupText:"Link einfügen.",support:"gering",supportText:"Prüfen, ob Ziel-Link noch aktiv ist.", docsUrl:"https://docs.moodle.org/501/de/URL/Link", longDesc:"Mit der Ressource URL verlinken Sie externe Webseiten direkt von der Kursseite. Das k\u00f6nnen Artikel, Videos, Online-Tools oder andere Lernressourcen sein. Teilnehmende gelangen per Klick zur verlinkten Seite. URLs eignen sich ideal, um externe Inhalte nahtlos in Ihren Kurs einzubinden. Die didaktischen M\u00f6glichkeiten h\u00e4ngen vom verlinkten Inhalt ab \u2013 von einfacher Information bis hin zu komplexen Lernszenarien.", goals:{ info:{r:"gr\u00fcn",t:"Komfortable M\u00f6glichkeit, externe Infos bereitzustellen."}, bewerten:{r:"orange",t:"Nicht direkt. Verlinkung auf externe Pr\u00fcfungstools."}, komm:{r:"orange",t:"Nicht direkt. Verlinkung auf externe Kommunikationstools."}, collab:{r:"orange",t:"Nicht direkt. Verlinkung auf externe Kooperationswerkzeuge."}, bloomG:{r:"gr\u00fcn",t:"6/6 m\u00f6glich. Abh\u00e4ngig vom Inhalt der verlinkten Seite."}}},
  { id:"wiki", name:"Wiki", desc:"Gemeinsam in der Gruppe Texte erstellen", complexity:"mittel", complexityText:"Erfordert Auseinandersetzung mit Wikiprinzip.", bloom:"6/6",setup:"mittel",setupText:"Erstanlage einfach, Aufbau planen.",support:"hoch",supportText:"Beiträge moderieren, Versionen prüfen.", docsUrl:"https://docs.moodle.org/501/de/Wiki", longDesc:"Das Wiki erm\u00f6glicht kooperatives Schreiben: Teilnehmende erstellen und bearbeiten gemeinsam Textseiten mit Verlinkungen. Es funktioniert nach dem Wikipedia-Prinzip \u2013 jeder kann Inhalte beitragen und \u00e4ndern. Die Versionshistorie dokumentiert alle \u00c4nderungen transparent. Wikis eignen sich f\u00fcr Gruppenreferate, Wissenssammlungen oder Projektdokumentationen. Der Einstieg erfordert etwas Einarbeitung, bietet dann aber gro\u00dfe Flexibilit\u00e4t.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Als Info-Seite nutzen. Bearbeiten durch alle im Kurs."}, bewerten:{r:"gr\u00fcn",t:"Flexibel einsetzbar, z.B. Bewertung der erstellten Wiki-Inhalte."}, komm:{r:"orange",t:"Teilweise f\u00fcr Diskussionen geeignet. Kommentare zu Wiki-Inhalten."}, collab:{r:"gr\u00fcn",t:"Ja. Teilnehmende k\u00f6nnen kooperativ arbeiten und diskutieren."}, bloomG:{r:"gr\u00fcn",t:"6/6 m\u00f6glich. Abh\u00e4ngig vom Einsatzszenario."}}},
  { id:"glossar", name:"Glossar", desc:"Informationen pr\u00e4sentieren und gemeinsam erstellen", complexity:"einfach", complexityText:"Einfach. Kann flexibel eingestellt werden.", bloom:"4/6",setup:"einfach",setupText:"Anlegen, Felder wählen.",support:"mittel",supportText:"Einträge sichten, ggf. freischalten.", docsUrl:"https://docs.moodle.org/501/de/Glossar", longDesc:"Im Glossar k\u00f6nnen Lehrende und Teilnehmende Fachbegriffe mit Definitionen sammeln. Eintr\u00e4ge werden automatisch im gesamten Kurs verlinkt, wenn der Begriff auftaucht. Teilnehmende k\u00f6nnen eigene Eintr\u00e4ge verfassen und die anderer kommentieren. Das Glossar eignet sich f\u00fcr Begriffssammlungen, FAQ-Listen oder als gemeinsam erstelltes Nachschlagewerk. Eintr\u00e4ge k\u00f6nnen bewertet werden, was es auch als Lernaktivit\u00e4t nutzbar macht.", goals:{ info:{r:"gr\u00fcn",t:"Glossar f\u00fcr Begriffsdefinitionen."}, bewerten:{r:"gr\u00fcn",t:"Glossareintr\u00e4ge erstellen lassen und dann bewerten."}, komm:{r:"orange",t:"Teilweise. Eintr\u00e4ge k\u00f6nnen kommentiert werden."}, collab:{r:"orange",t:"Autor/in kann bearbeiten. Teilnehmende kommentieren."}, bloomG:{r:"gr\u00fcn",t:"6/6 m\u00f6glich. Abh\u00e4ngig vom Einsatzszenario."}}},
  { id:"datenbank", name:"Datenbank", desc:"Materialien sammeln, teilen & suchen", complexity:"komplex", complexityText:"Schwierig anzulegen. Vorher Aufbau planen!", bloom:"5/6",setup:"komplex",setupText:"Felder im Detail planen und definieren.",support:"mittel",supportText:"Einträge moderieren, Sammlung pflegen.", docsUrl:"https://docs.moodle.org/501/de/Datenbank", longDesc:"Die Datenbank-Aktivit\u00e4t erm\u00f6glicht es, strukturierte Eintr\u00e4ge mit frei definierbaren Feldern zu sammeln. Teilnehmende k\u00f6nnen Texte, Bilder, Dateien und Links in einem einheitlichen Format eintragen. Alle Eintr\u00e4ge sind durchsuchbar und k\u00f6nnen kommentiert und bewertet werden. Die Datenbank eignet sich f\u00fcr Materialsammlungen, Steckbriefe oder Projektportfolios. Die Einrichtung erfordert Planung, bietet daf\u00fcr aber sehr flexible Einsatzm\u00f6glichkeiten.", goals:{ info:{r:"orange",t:"Lehrende k\u00f6nnen Material pr\u00e4sentieren. Besser: TN tragen Daten ein."}, bewerten:{r:"gr\u00fcn",t:"Ja. Inhalte k\u00f6nnen bewertet werden. Flexibel einsetzbar."}, komm:{r:"orange",t:"Teilweise. Eintr\u00e4ge k\u00f6nnen kommentiert werden."}, collab:{r:"orange",t:"Autor/in kann bearbeiten. Teilnehmende kommentieren."}, bloomG:{r:"gr\u00fcn",t:"6/6 m\u00f6glich. Abh\u00e4ngig vom Einsatzszenario."}}},
  { id:"umfrage", name:"Umfrage", desc:"Befragung mit vordefinierten Fragen", complexity:"einfach", complexityText:"Einfach. Aus 3 Typen w\u00e4hlen.", bloom:"2/6",setup:"einfach",setupText:"Vorlage wählen, fertig.",support:"gering",supportText:"Keine Pflege – Auswertung am Ende.", docsUrl:"https://docs.moodle.org/501/de/Umfrage", longDesc:"Die Umfrage bietet drei vordefinierte, wissenschaftlich validierte Frageb\u00f6gen zur Evaluation von Lernumgebungen. Sie erfasst, wie Teilnehmende das Lernklima und den Unterricht wahrnehmen. Die Ergebnisse helfen Lehrenden, ihren Kurs zu verbessern. Im Gegensatz zum Feedback k\u00f6nnen die Fragen nicht ver\u00e4ndert werden. Die Umfrage eignet sich besonders zur Reflexion des Lernprozesses und zur Kursoptimierung.", goals:{ info:{r:"rot",t:"Nein. Die Umfrage ist ungeeignet zur Informationsverteilung."}, bewerten:{r:"rot",t:"Eher nicht. Besser zur Evaluation des Kurses."}, komm:{r:"rot",t:"Nein. Nur Einweg-Kommunikation: TN an Lehrende."}, collab:{r:"rot",t:"Nein. Rein individuelle Aktivit\u00e4t."}, bloomG:{r:"orange",t:"Hilft Teilnehmenden Lernprozess zu reflektieren."}}},
  { id:"feedback", name:"Feedback", desc:"Erstelle selbst Evaluationsfrageb\u00f6gen", complexity:"einfach", complexityText:"Einfach in Bedienung. Zeitaufwand f\u00fcr Fragen.", bloom:"3/6",setup:"mittel",setupText:"Fragen formulieren kostet Zeit.",support:"gering",supportText:"Auswertung am Ende.", docsUrl:"https://docs.moodle.org/501/de/Feedback", longDesc:"Mit der Feedback-Aktivit\u00e4t erstellen Sie eigene Frageb\u00f6gen mit frei definierbaren Fragen. Sie k\u00f6nnen Multiple-Choice, Textfelder, Bewertungsskalen und mehr einsetzen. Die Antworten k\u00f6nnen anonym oder namentlich erfasst werden. Feedback eignet sich hervorragend f\u00fcr Kursevaluationen, Erwartungsabfragen oder Stimmungsbilder. Im Gegensatz zur Umfrage haben Sie volle Kontrolle \u00fcber die Fragestellungen.", goals:{ info:{r:"rot",t:"Nein. Nicht zur Informationsverteilung vorgesehen."}, bewerten:{r:"rot",t:"Nein. Evaluationen generieren Feedback f\u00fcr Lehrende."}, komm:{r:"rot",t:"Nein. Nur Einweg-Kommunikation."}, collab:{r:"rot",t:"Nein. Rein individuelle Aktivit\u00e4t."}, bloomG:{r:"orange",t:"Kann kreativ gestaltet werden."}}},
  { id:"abstimmung", name:"Abstimmung", desc:"Teilnehmende stimmen \u00fcber eine Frage ab", complexity:"einfach", complexityText:"Einfach. Frage(n) und Antworten anlegen.", bloom:"1/6",setup:"einfach",setupText:"Frage und Optionen eintippen.",support:"gering",supportText:"Keine Pflege nötig.", docsUrl:"https://docs.moodle.org/501/de/Abstimmung", longDesc:"Die Abstimmung stellt eine einzelne Frage mit vorgegebenen Antwortm\u00f6glichkeiten. Teilnehmende w\u00e4hlen eine Option, die Ergebnisse werden als Balkendiagramm angezeigt. Sie eignet sich f\u00fcr schnelle Meinungsbilder, Terminabsprachen oder Gruppeneinteilungen. Die Einrichtung dauert nur wenige Minuten. F\u00fcr komplexere Befragungen mit mehreren Fragen nutzen Sie besser die Feedback-Aktivit\u00e4t.", goals:{ info:{r:"rot",t:"Nein. Haupts\u00e4chlich zur schnellen Abfrage zu einem Thema."}, bewerten:{r:"gr\u00fcn",t:"Als Schnellabfrage einer Fragestellung verwenden."}, komm:{r:"rot",t:"Nein. Besser Forum oder Chat nutzen."}, collab:{r:"rot",t:"Nein. Besser Forum, Glossar oder Wiki nutzen."}, bloomG:{r:"orange",t:"Erlaubt einfache Abfrage von Wissen und Verst\u00e4ndnis."}}},
  { id:"test", name:"Test", desc:"Testfragen mit automatischer Bewertung", complexity:"mittel", complexityText:"Zeitaufwand beim Erstellen. Auswertung automatisch.", bloom:"4/6",setup:"komplex",setupText:"Fragenpool aufbauen, Konfiguration durchdenken.",support:"mittel",supportText:"Ergebnisse sichten, Probleme klären.", docsUrl:"https://docs.moodle.org/501/de/Test", longDesc:"Der Test ist das zentrale Pr\u00fcfungswerkzeug in Moodle mit \u00fcber 15 Fragetypen \u2013 von Multiple-Choice \u00fcber L\u00fcckentext bis Zuordnung. Die Auswertung erfolgt automatisch mit sofortigem Feedback an die Teilnehmenden. Tests k\u00f6nnen zeitgesteuert, mit Zufallsfragen und mehreren Versuchen konfiguriert werden. Sie eignen sich f\u00fcr Selbsttests, \u00dcbungen und formale Pr\u00fcfungen gleicherma\u00dfen. Der Fragenpool erm\u00f6glicht die Wiederverwendung von Fragen \u00fcber Kurse hinweg.", goals:{ info:{r:"rot",t:"Zielt auf Bewertung, nicht Verteilung von Informationen."}, bewerten:{r:"gr\u00fcn",t:"Ja. F\u00fcr Fragen mit eindeutiger Antwort. Automatisch."}, komm:{r:"rot",t:"Nein. Besser Forum oder Chat nutzen."}, collab:{r:"rot",t:"Nein. Besser Forum oder Wiki nutzen."}, bloomG:{r:"gr\u00fcn",t:"Durch kreativen Umgang vielf\u00e4ltig einsetzbar."}}},
  { id:"lektion", name:"Lektion", desc:"Informationen und Testfragen seitenweise aufbauen", complexity:"mittel", complexityText:"Erfordert Planung, dann effektive Lernaktivit\u00e4t.", bloom:"4/6",setup:"komplex",setupText:"Verzweigungslogik sorgfältig planen.",support:"gering",supportText:"Nach Aufbau weitgehend selbstläufig.", docsUrl:"https://docs.moodle.org/501/de/Lektion", longDesc:"Die Lektion pr\u00e4sentiert Inhalte auf einzelnen Seiten und verkn\u00fcpft sie mit Testfragen. Je nach Antwort werden Teilnehmende zu verschiedenen Seiten weitergeleitet \u2013 ein verzweigter Lernpfad entsteht. So k\u00f6nnen Sie adaptives Lernen umsetzen, bei dem der Weg vom Wissensstand abh\u00e4ngt. Lektionen eignen sich f\u00fcr gef\u00fchrte Lerneinheiten mit integrierten Verst\u00e4ndnispr\u00fcfungen. Die Erstellung erfordert Planung, ergibt aber eine sehr effektive Lernaktivit\u00e4t.", goals:{ info:{r:"gr\u00fcn",t:"Gut geeignet f\u00fcr gef\u00fchrte Informationspr\u00e4sentation."}, bewerten:{r:"gr\u00fcn",t:"Ja, erlaubt Bewertung durch integrierte Testfragen."}, komm:{r:"rot",t:"Nein. Teilnehmende arbeiten einzeln."}, collab:{r:"rot",t:"Nein. Teilnehmende arbeiten einzeln."}, bloomG:{r:"gr\u00fcn",t:"Durch kreativen Umgang vielf\u00e4ltig einsetzbar."}}},
  { id:"aufgabe", name:"Aufgabe", desc:"Aufgabenstellung mit individueller Bewertung", complexity:"einfach", complexityText:"Einfach. Auswahl aus vier Aufgabentypen.", bloom:"6/6",setup:"einfach",setupText:"Abgabetyp und Frist festlegen.",support:"hoch",supportText:"Bewertung und Feedback pro Abgabe.", docsUrl:"https://docs.moodle.org/501/de/Aufgabe", longDesc:"Die Aufgabe ist das vielseitigste Bewertungswerkzeug in Moodle. Teilnehmende reichen Texte, Dateien oder Medien ein, die Sie individuell mit Note und Kommentar bewerten. Vier Abgabetypen stehen zur Verf\u00fcgung: Dateiabgabe, Onlinetext, Audio-/Videoaufnahme. Abgabefristen, Verl\u00e4ngerungen und Gruppenabgaben sind konfigurierbar. Die Aufgabe eignet sich f\u00fcr Essays, Projektarbeiten, Pr\u00e4sentationen und jede Form individueller Leistungsnachweise.", goals:{ info:{r:"rot",t:"Nein. Kann aber Inhalte f\u00fcr Aufgabenstellung enthalten."}, bewerten:{r:"gr\u00fcn",t:"Ja. Individuelle Bewertung mit Note und Kommentar."}, komm:{r:"rot",t:"Wenig Interaktion. Au\u00dfer: wiederholte Abgabe mit Feedback."}, collab:{r:"orange",t:"Gruppenmitglied gibt stellvertretend L\u00f6sung ab."}, bloomG:{r:"gr\u00fcn",t:"Abh\u00e4ngig von Aufgabenformulierung und Beurteilungsform."}}},
  { id:"beurteilung", name:"Gegenseitige Beurteilung", desc:"Aufgabe mit Peer-Feedback", complexity:"komplex", complexityText:"Erfordert sorgf\u00e4ltige Planung.", bloom:"5/6",setup:"komplex",setupText:"Phasen, Kriterien und Bewertungsraster planen.",support:"hoch",supportText:"Phasen aktiv begleiten und steuern.", docsUrl:"https://docs.moodle.org/501/de/Gegenseitige_Beurteilung", longDesc:"Die Gegenseitige Beurteilung (Workshop) kombiniert Aufgabenabgabe mit Peer-Review. Teilnehmende reichen zun\u00e4chst eigene Arbeiten ein und bewerten anschlie\u00dfend die Einreichungen anderer nach vorgegebenen Kriterien. Dieser Prozess f\u00f6rdert kritisches Denken und Reflexion. Die Endbewertung setzt sich aus Peer- und Trainer-Bewertung zusammen. Die Einrichtung ist anspruchsvoll, bietet aber ein p\u00e4dagogisch sehr wertvolles Lernszenario.", goals:{ info:{r:"rot",t:"Nein. Ein anderes Tool verwenden."}, bewerten:{r:"gr\u00fcn",t:"Ja. Peer-Bewertung. TN beurteilen L\u00f6sungen anderer."}, komm:{r:"rot",t:"Nein. Erlaubt nur Feedback, keine Kommunikation."}, collab:{r:"rot",t:"Nein. F\u00fcr Gruppenaufgaben Forum oder Wiki nutzen."}, bloomG:{r:"gr\u00fcn",t:"Abh\u00e4ngig von Aufgabenformulierung und Beurteilungsform."}}},
  { id:"lernpaket", name:"Lernpaket", desc:"Lerninhalte im Format SCORM einbinden", complexity:"komplex", complexityText:"Erfordert Software oder Kauf von Inhalten.", bloom:"4/6",setup:"komplex",setupText:"SCORM-Inhalte mit externer Software erstellen.",support:"gering",supportText:"Nach Einbinden weitgehend selbstläufig.", docsUrl:"https://docs.moodle.org/501/de/Lernpaket", longDesc:"Lernpakete binden extern erstellte SCORM- oder AICC-Inhalte in Moodle ein. Diese interaktiven Lernmodule werden mit Autorentools wie Articulate, Captivate oder iSpring erstellt. Der Lernfortschritt und Ergebnisse werden automatisch an Moodle zur\u00fcckgemeldet. Lernpakete eignen sich f\u00fcr multimediale, interaktive Selbstlerneinheiten. Die Einbindung ist einfach, die Erstellung der Inhalte erfordert jedoch spezielle Software.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Gut geeignet f\u00fcr Informationsvermittlung."}, bewerten:{r:"gr\u00fcn",t:"Ja, Bewertungen k\u00f6nnen integriert sein."}, komm:{r:"rot",t:"Nein. Teilnehmende arbeiten einzeln."}, collab:{r:"rot",t:"Nein. Teilnehmende arbeiten einzeln."}, bloomG:{r:"gr\u00fcn",t:"Durch kreativen Umgang vielf\u00e4ltig einsetzbar."}}},
  { id:"chat", name:"Chat", desc:"Echtzeit Text-Chat mit Teilnehmenden", complexity:"einfach", complexityText:"Einfach. Erfordert Moderation, kleine Gruppen.", bloom:"3/6",setup:"einfach",setupText:"Aktivität anlegen, Termin festlegen.",support:"hoch",supportText:"Live moderieren während der Sitzung.", docsUrl:"https://docs.moodle.org/501/de/Chat", longDesc:"Der Chat erm\u00f6glicht synchrone Textgespr\u00e4che in Echtzeit zwischen Kursteilnehmenden. Er eignet sich f\u00fcr Sprechstunden, Gruppendiskussionen oder spontanen Austausch in kleinen Gruppen. Chatverl\u00e4ufe werden protokolliert und k\u00f6nnen sp\u00e4ter eingesehen werden. Eine Moderation ist empfehlenswert, um den Gespr\u00e4chsverlauf zu steuern. F\u00fcr gr\u00f6\u00dfere Gruppen oder asynchrone Kommunikation ist das Forum besser geeignet.", goals:{ info:{r:"orange",t:"Erfordert Anwesenheit zum Zeitpunkt des Chats."}, bewerten:{r:"orange",t:"Chatbeitr\u00e4ge k\u00f6nnen wie m\u00fcndliche Mitarbeit bewertet werden."}, komm:{r:"gr\u00fcn",t:"Ja. Diskussionen in kleinen Gruppen oder Fragestunden."}, collab:{r:"gr\u00fcn",t:"Ja. Teilnehmende k\u00f6nnen zusammen arbeiten und diskutieren."}, bloomG:{r:"gr\u00fcn",t:"Kann mit kleinen Gruppen kreativ genutzt werden."}}},
  { id:"forum", name:"Forum", desc:"F\u00fcr vielf\u00e4ltige Lernstrategien verwendbar", complexity:"einfach", complexityText:"Einfach. Titel und Beschreibung gen\u00fcgen.", bloom:"5/6",setup:"einfach",setupText:"Forumtyp wählen, Titel vergeben.",support:"hoch",supportText:"Beiträge moderieren und beantworten.", docsUrl:"https://docs.moodle.org/501/de/Forum", longDesc:"Das Forum ist das vielseitigste Kommunikationswerkzeug in Moodle. Es erm\u00f6glicht zeitversetzte Diskussionen, in denen Teilnehmende Beitr\u00e4ge verfassen, aufeinander antworten und Dateien anh\u00e4ngen. Verschiedene Forentypen stehen zur Verf\u00fcgung \u2013 vom Nachrichtenforum bis zur offenen Diskussion. Beitr\u00e4ge k\u00f6nnen per E-Mail-Benachrichtigung verfolgt und sogar bewertet werden. Foren eignen sich f\u00fcr Ank\u00fcndigungen, Peer-Learning, Reflexion und kooperatives Arbeiten.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Nachrichtenforum und Mail-Benachrichtigung."}, bewerten:{r:"orange",t:"Jein. Beitr\u00e4ge k\u00f6nnen f\u00fcr einen Zeitraum bewertet werden."}, komm:{r:"gr\u00fcn",t:"Ja. Zeitversetzte Kommunikation. Kursgruppen nutzbar."}, collab:{r:"gr\u00fcn",t:"Ja. TN tauschen sich beim Erstellen von Inhalten aus."}, bloomG:{r:"gr\u00fcn",t:"Kann auch mit gro\u00dfen Gruppen kreativ genutzt werden."}}},
  { id:"extern", name:"Externes Tool", desc:"Externe Lernaktivit\u00e4t verbinden (LTI)", complexity:"komplex", complexityText:"Erfordert Zugangsdaten zu externen Anbietern.", bloom:"4/6",setup:"komplex",setupText:"Zugangsdaten/LTI-Konfig vom Anbieter nötig.",support:"gering",supportText:"Funktion gelegentlich prüfen.", docsUrl:"https://docs.moodle.org/501/de/Externes_Tool", longDesc:"Das Externe Tool verbindet Moodle \u00fcber den LTI-Standard mit externen Lernplattformen und Diensten. So k\u00f6nnen Teilnehmende direkt aus Moodle heraus auf externe Tools zugreifen \u2013 ohne separaten Login. Bewertungen k\u00f6nnen automatisch nach Moodle zur\u00fcck\u00fcbertragen werden. Typische Einsatzgebiete sind Simulationen, Labore, Verlagsinhalte oder spezialisierte Lerntools. Die Einrichtung erfordert technische Konfiguration und Zugangsdaten vom Anbieter.", goals:{ info:{r:"orange",t:"Abh\u00e4ngig vom verbundenen Tool."}, bewerten:{r:"orange",t:"Bewertungen k\u00f6nnen nach Moodle \u00fcbertragen werden."}, komm:{r:"orange",t:"Abh\u00e4ngig vom verbundenen Tool."}, collab:{r:"orange",t:"Abh\u00e4ngig vom verbundenen Tool."}, bloomG:{r:"orange",t:"H\u00e4ngt vom verbundenen Tool ab."}}},
  { id:"h5p", name:"H5P", desc:"Werkzeuge f\u00fcr interaktive Inhalte", complexity:"einfach", complexityText:"Einfache Bedienung durch Formulare.", bloom:"5/6",setup:"mittel",setupText:"Inhaltstyp wählen, im Editor befüllen.",support:"gering",supportText:"Keine Pflege im laufenden Betrieb.", docsUrl:"https://docs.moodle.org/501/de/H5P-Aktivit%C3%A4t", longDesc:"H5P bietet \u00fcber 40 interaktive Inhaltstypen direkt in Moodle \u2013 von interaktiven Videos \u00fcber Zeitstrahlen bis zu Drag-and-Drop-Aufgaben. Die Erstellung erfolgt \u00fcber intuitive Formulare ohne Programmierkenntnisse. Bewertungen werden automatisch erfasst und an das Moodle-Bewertungssystem \u00fcbergeben. H5P-Inhalte sind responsiv und funktionieren auf allen Ger\u00e4ten. Es ist eines der vielseitigsten Werkzeuge f\u00fcr interaktive und ansprechende Lernerfahrungen.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Gute Visualisierung von Informationen."}, bewerten:{r:"gr\u00fcn",t:"Ja. Automatische Bewertung."}, komm:{r:"rot",t:"Nein. Keine Kommunikation m\u00f6glich."}, collab:{r:"rot",t:"Nein. Teilnehmende arbeiten einzeln."}, bloomG:{r:"gr\u00fcn",t:"Vielf\u00e4ltige Unterst\u00fctzung von Lernszenarien."}}},
  { id:"bbb", name:"BigBlueButton", desc:"Videokonferenz, Whiteboard, Chat", complexity:"einfach", complexityText:"Einfache Bedienung.", bloom:"5/6",setup:"einfach",setupText:"Termin anlegen, Raum konfigurieren.",support:"hoch",supportText:"Live moderieren, Aufzeichnungen verwalten.", docsUrl:"https://docs.moodle.org/501/de/BigBlueButton", longDesc:"BigBlueButton ist ein vollwertiges Videokonferenzsystem, das direkt in Moodle integriert ist. Es bietet Live-Video, Bildschirmfreigabe, interaktives Whiteboard, Umfragen und Breakout-R\u00e4ume. Sitzungen k\u00f6nnen aufgezeichnet und sp\u00e4ter im Kurs bereitgestellt werden. BigBlueButton eignet sich f\u00fcr Vorlesungen, Seminare, Sprechstunden und Gruppenarbeit. Die Bedienung ist einfach \u2013 ein Klick gen\u00fcgt, um einer Konferenz beizutreten.", goals:{ info:{r:"gr\u00fcn",t:"Ja. Vortr\u00e4ge und Pr\u00e4sentationen werden live gehalten."}, bewerten:{r:"orange",t:"Begrenzt: Geeignet f\u00fcr Einzel-/Kleingruppenpr\u00fcfungen."}, komm:{r:"gr\u00fcn",t:"Ja. Gespr\u00e4che, Videocalls, Chats m\u00f6glich."}, collab:{r:"gr\u00fcn",t:"Ja, mittels Whiteboard und gemeinsamen Notizen."}, bloomG:{r:"gr\u00fcn",t:"Vielf\u00e4ltige Unterst\u00fctzung von Lernszenarien."}}},
  { id:"board", name:"Board", desc:"Visuelle Pinnwand mit Spalten und Karten", complexity:"einfach", complexityText:"Sticky-Note-Style.", bloom:"3/6",setup:"einfach",setupText:"Spalten definieren, fertig in 5 Minuten.",support:"gering",supportText:"Gelegentlich aufräumen, ggf. Beiträge moderieren.", docsUrl:"https://moodle.org/plugins/mod_board", longDesc:"Board ist eine visuelle Pinnwand im Stil von Padlet oder Trello. Lehrende legen Spalten an, Lernende posten Karten mit Text, Bildern, Links oder Videos. Karten können verschoben, geliket und kommentiert werden. Board ist niedrigschwellig, optisch ansprechend und ideal für Brainstorming, Erwartungsabfragen, Sammlung von Beispielen oder kollektive Wissensbasen. Es ersetzt externe Tools wie Padlet datenschutzkonform direkt in Moodle.", goals:{ info:{r:"grün",t:"Ja. Sammlung von Quellen, Bildern, Links als visuelle Wissensbasis."}, bewerten:{r:"orange",t:"Teilweise. Likes möglich, keine echte Bewertungslogik."}, komm:{r:"grün",t:"Ja. Brainstorming, Erwartungsabfrage, kollektive Sammlung – niedrigschwellig und visuell."}, collab:{r:"grün",t:"Ja. Klassisches Sticky-Note-Format für kollaboratives Sammeln und Strukturieren."}, bloomG:{r:"grün",t:"3/6 typisch (Anwenden), bei strukturierenden Aufgaben bis Stufe 4 (Analysieren)."}}},
  { id:"anwesenheit", name:"Anwesenheit", desc:"Anwesenheit der Lernenden pro Sitzung erfassen", complexity:"mittel", complexityText:"Verwaltungswerkzeug.", bloom:"1/6",setup:"mittel",setupText:"Sitzungsserie anlegen, Statusoptionen konfigurieren.",support:"mittel",supportText:"Pro Sitzung Anwesenheit erfassen oder Selbsteintrag prüfen.", docsUrl:"https://moodle.org/plugins/mod_attendance", longDesc:"Anwesenheit ist das Standard-Plugin für Anwesenheitsverwaltung in Moodle. Lehrende planen Sitzungen (einmalig oder als Serie), erfassen pro Sitzung den Status der Lernenden (anwesend, verspätet, entschuldigt, fehlend) oder lassen die Lernenden sich selbst eintragen. Reports zeigen die Bilanz pro Person und Kurs. Die Anwesenheit kann gewichtet in die Gesamtbewertung einfließen – ideal für Präsenzkurse, Blended Learning und förderliche Anwesenheitspflicht.", goals:{ info:{r:"orange",t:"Teilweise. Lernende sehen ihre eigene Anwesenheitsbilanz als Information."}, bewerten:{r:"grün",t:"Ja. Anwesenheit kann in die Gesamtbewertung einfließen, Reports für Lehrkraft."}, komm:{r:"rot",t:"Nein. Reines Verwaltungswerkzeug ohne Kommunikationsfunktion."}, collab:{r:"rot",t:"Nein. Keine kollaborative Funktion."}, bloomG:{r:"orange",t:"1/6 – administratives Tool, kein direktes Lernziel."}}},
  { id:"lerntagebuch", name:"Lerntagebuch", desc:"Privates Reflexionstagebuch zwischen Lernender und Lehrkraft", complexity:"einfach", complexityText:"Vertraulicher Dialog.", bloom:"5/6",setup:"einfach",setupText:"Aktivität anlegen, Reflexionsfrage formulieren.",support:"hoch",supportText:"Jeder Eintrag braucht persönliches, qualifiziertes Feedback.", docsUrl:"https://moodle.org/plugins/mod_diary", longDesc:"Das Lerntagebuch (Diary / Journal) ist eine bewusst private Aktivität: Lernende schreiben Einträge zu Reflexionsfragen oder zum eigenen Lernfortschritt, nur die Lehrkraft sieht den Eintrag und kommentiert. Es fördert Metakognition und Selbstreflexion und erlaubt qualitatives, individuelles Feedback. Geeignet für Lernprozessbegleitung, Praxisphasen, Coaching und alle Settings, in denen persönliche Auseinandersetzung wichtiger ist als ein gemeinsames Produkt.", goals:{ info:{r:"orange",t:"Teilweise. Eher Reflexion eigener Lernerfahrung als Wissensvermittlung."}, bewerten:{r:"grün",t:"Ja. Bewertung von Reflexionstiefe, qualitatives Feedback durch Lehrkraft."}, komm:{r:"grün",t:"Ja. 1:1-Dialog zwischen Lernender und Lehrkraft, vertraulich."}, collab:{r:"rot",t:"Nein. Bewusst privat – keine Sichtbarkeit für andere Lernende."}, bloomG:{r:"grün",t:"5/6 (Bewerten / Reflektieren). Hohe metakognitive Anforderung."}}},
];

// Tool icon data: SVG + background color per Moodle category
const TOOL_ICONS = {
  datei:      {bg:"#DDA4C9", svg:`<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 2v6h6" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  verzeichnis:{bg:"#DDA4C9", svg:`<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2v11z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  textseite:  {bg:"#DDA4C9", svg:`<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  buch:       {bg:"#DDA4C9", svg:`<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 7h8M8 11h5" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/>`},
  url:        {bg:"#DDA4C9", svg:`<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  lernpaket:  {bg:"#DDA4C9", svg:`<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  wiki:       {bg:"#A5C387", svg:`<path d="M12 20h9" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  glossar:    {bg:"#A5C387", svg:`<rect x="3" y="2" width="18" height="20" rx="3" stroke="white" stroke-width="1.8" fill="none"/><path d="M8 6h2" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M12 6.25a3.5 3.5 0 0 1 3.5 3.5v.5" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/><circle cx="12" cy="16" r="0.5" fill="white" stroke="white" stroke-width="1"/>`},
  datenbank:  {bg:"#A5C387", svg:`<ellipse cx="12" cy="5" rx="9" ry="3" stroke="white" stroke-width="1.8" fill="none"/><path d="M21 12c0 1.66-4.03 3-9 3s-9-1.34-9-3" stroke="white" stroke-width="1.8" fill="none"/><path d="M3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5" stroke="white" stroke-width="1.8" fill="none"/>`},
  forum:      {bg:"#65A1B3", svg:`<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 9h8M8 13h5" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/>`},
  chat:       {bg:"#65A1B3", svg:`<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  bbb:        {bg:"#65A1B3", svg:`<rect x="2" y="3" width="20" height="14" rx="2" stroke="white" stroke-width="1.8" fill="none"/><path d="M8 21h8M12 17v4" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/><circle cx="12" cy="10" r="2.5" stroke="white" stroke-width="1.5" fill="none"/>`},
  test:       {bg:"#7C6576", svg:`<path d="M9 11l3 3L22 4" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  aufgabe:    {bg:"#7C6576", svg:`<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 2v6h6" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M9 15l2 2 4-4" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  lektion:    {bg:"#7C6576", svg:`<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2V3z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7V3z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  beurteilung:{bg:"#7C6576", svg:`<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="9" cy="7" r="4" stroke="white" stroke-width="1.8" fill="none"/><path d="M23 21v-2a4 4 0 0 0-3-3.87" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M16 3.13a4 4 0 0 1 0 7.75" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/>`},
  abstimmung: {bg:"#7C6576", svg:`<rect x="4" y="14" width="4" height="7" rx="1" stroke="white" stroke-width="1.8" fill="none"/><rect x="10" y="8" width="4" height="13" rx="1" stroke="white" stroke-width="1.8" fill="none"/><rect x="16" y="3" width="4" height="18" rx="1" stroke="white" stroke-width="1.8" fill="none"/>`},
  h5p:        {bg:"#3AADAA", svg:`<circle cx="12" cy="12" r="9" stroke="white" stroke-width="1.8" fill="none"/><polygon points="10,8 16,12 10,16" fill="white"/>`},
  extern:     {bg:"#3AADAA", svg:`<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 3h6v6" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M10 14L21 3" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  umfrage:    {bg:"#8A8A8E", svg:`<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/><rect x="8" y="2" width="8" height="4" rx="1" stroke="white" stroke-width="1.8" fill="none"/><path d="M8 12h4M8 16h6" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round"/>`},
  feedback:   {bg:"#8A8A8E", svg:`<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`},
  board:      {bg:"#f98012", svg:`<rect x="3" y="4" width="18" height="16" rx="2" stroke="white" stroke-width="1.8" fill="none"/><line x1="9" y1="4" x2="9" y2="20" stroke="white" stroke-width="1.8"/><line x1="15" y1="4" x2="15" y2="20" stroke="white" stroke-width="1.8"/><rect x="4.5" y="6" width="3" height="4" fill="white"/><rect x="10.5" y="6" width="3" height="3" fill="white"/><rect x="16.5" y="6" width="3" height="5" fill="white"/>`},
  anwesenheit:{bg:"#669933", svg:`<rect x="4" y="3" width="16" height="18" rx="2" stroke="white" stroke-width="1.8" fill="none"/><path d="M8 11l2 2 5-5" stroke="white" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><line x1="8" y1="16" x2="16" y2="16" stroke="white" stroke-width="1.5" stroke-linecap="round"/><line x1="8" y1="18.5" x2="14" y2="18.5" stroke="white" stroke-width="1.5" stroke-linecap="round"/>`},
  lerntagebuch:{bg:"#194866", svg:`<path d="M4 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4z" stroke="white" stroke-width="1.8" fill="none"/><line x1="8" y1="7" x2="16" y2="7" stroke="white" stroke-width="1.5" stroke-linecap="round"/><line x1="8" y1="11" x2="16" y2="11" stroke="white" stroke-width="1.5" stroke-linecap="round"/><line x1="8" y1="15" x2="13" y2="15" stroke="white" stroke-width="1.5" stroke-linecap="round"/>`},
};

// SVG path data for goal icons (white stroke on colored bg, or colored stroke standalone)
const GOAL_SVG = {
  info: `<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2V3z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7V3z"/>`,
  bewerten: `<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>`,
  komm: `<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10z"/>`,
  collab: `<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>`,
  bloomG: `<polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"/>`,
};

// ============================================================================
// i18n
// ============================================================================
const I18N = {
  de: {
    title: "Moodle Tool Guide",
    subtitle: "Finde das passende Werkzeug für dein didaktisches Ziel",
    nav_matrix: "Matrix",
    nav_cards: "Karten",
    nav_wizard: "Assistent",
    search_placeholder: "Tool suchen…",
    compare_btn: "Vergleichen",
    filter_setup_all: "Aufwand Einrichtung: alle",
    filter_support_all: "Aufwand Betreuung: alle",
    filter_goal_default: "Gut geeignet für …",
    filter_bloom_all: "🎓 Bloom: Alle Stufen",
    filter_bloom_from: "ab Stufe",
    setup: "Einrichtung",
    setup_help: "Wie viel Aufwand kostet es, diese Aktivität EINMALIG anzulegen und zu konfigurieren?",
    support: "Betreuung",
    support_help: "Wie viel laufender Aufwand entsteht WÄHREND der Nutzung – moderieren, bewerten, antworten?",
    setup_einfach: "Einfach",
    setup_mittel: "Mittel",
    setup_komplex: "Komplex",
    support_gering: "Gering",
    support_mittel: "Mittel",
    support_hoch: "Hoch",
    activity: "Aktivität",
    bloom_short: "Bloom",
    bloom_help: "Welche kognitiven Lernzielstufen nach Bloom's Taxonomie deckt diese Aktivität typischerweise ab? 1=Wiedergeben, 6=Erschaffen.",
    suit_good: "Gut geeignet",
    suit_partial: "Teilweise geeignet",
    suit_bad: "Ungeeignet",
    empty_title: "Keine passenden Aktivitäten gefunden",
    empty_text: "Zu der gewählten Kombination gibt es in Moodle keine passende Aktivität. Lockere einen oder mehrere Filter, um Vorschläge zu erhalten – oder probiere den Assistenten für eine geführte Auswahl.",
    empty_reset: "Filter zurücksetzen",
    wizard_step1: "Ziel",
    wizard_step2: "Einrichtung",
    wizard_step3: "Betreuung",
    wizard_step4: "Bloom",
    wizard_q1: "Was möchtest du erreichen?",
    wizard_q2: "Wie viel Aufwand für die Einrichtung darf es sein?",
    wizard_q3: "Wie viel Aufwand für die laufende Betreuung darf es sein?",
    wizard_results: "passende Tools gefunden",
    wizard_back: "Zurück",
    wizard_restart: "Neu starten",
    wizard_skip: "Egal",
    wizard_skip_desc: "Spielt keine Rolle",
    overview: "Überblick",
    suitability_header: "Eignung nach didaktischem Ziel",
    docs_btn: "Moodle Docs",
    community_btn: "Mehr Infos und Ideen in der eledia.community",
    in_compare: "✓ Im Vergleich",
    add_compare: "+ Vergleichen",
    description: "Beschreibung",
    repo_btn: "Quellcode auf GitHub",
    footer: "Basierend auf dem Moodle Tool Guide · eLeDia · Idee: Joyce Seitzinger",
    bloom_levels: ["Wiedergeben", "Verstehen", "Anwenden", "Analysieren", "Bewerten", "Erschaffen"],
    bloom_descs: [
      "Fakten und grundlegende Konzepte abrufen.",
      "Ideen oder Konzepte in eigenen Worten wiedergeben.",
      "Informationen in neuen Situationen nutzen.",
      "Verbindungen zwischen Ideen herstellen.",
      "Basierend auf den Lernmaterialien einen Standpunkt rechtfertigen.",
      "Eine neue oder originelle Arbeit entwickeln."
    ],
    goals: {
      info: { label: "Information & Transfer", q: "Ist es geeignet zur Weitergabe von Informationen?" },
      bewerten: { label: "Bewerten", q: "Ermöglicht es, den Kenntnisstand zu erfassen?" },
      komm: { label: "Kommunikation & Interaktion", q: "Kann es zur Kommunikation genutzt werden?" },
      collab: { label: "Gemeinsam Inhalte erstellen", q: "Können Inhalte kooperativ erstellt werden?" },
      bloomG: { label: "Bloom's Lernziele", q: "Welche Lernziele werden unterstützt?" }
    }
  ,
    wizard_step5: "Ergebnis"
  ,
    wizard_q4: "Welche Bloom-Stufe mindestens?"
  ,
    credit_original: "Original-Konzept"
  ,
    credit_translation: "Basiert auf einer Übersetzung von"
  ,
    dialog_close: "Schließen"
  ,
    credit_license: "Lizenz"
  ,
    credit_eledia: "Angepasst von den Moodle-Expert*innen von eLeDia | eLearning im Dialog. Mehr Moodle-Wissen auf"
  ,
    wizard_breadcrumb: "Assistent-Schritte"
  ,
    wizard_jump_to: "Zurück zu Schritt"
  ,
    a11y_font_larger: "Schrift größer"
  ,
    a11y_font_smaller: "Schrift kleiner"
  ,
    a11y_font_reset: "Schrift normal"
  ,
    alt_eledia_logo: "eLeDia – eLearning im Dialog"
  ,
    alt_eledia_favicon: "eLeDia Logo"
  ,
    alt_moodle_partner: "Moodle Premium Certified Services Provider"
  ,
    alt_github: "Quellcode auf GitHub"
  ,
    alt_cc_byncsa: "Lizenz: Creative Commons Namensnennung – Nicht-kommerziell – Weitergabe unter gleichen Bedingungen 4.0 International"
  },
  en: {
    title: "Moodle Tool Guide",
    subtitle: "Find the right tool for your didactic goal",
    nav_matrix: "Matrix",
    nav_cards: "Cards",
    nav_wizard: "Wizard",
    search_placeholder: "Search tool…",
    compare_btn: "Compare",
    filter_setup_all: "Setup effort: all",
    filter_support_all: "Support effort: all",
    filter_goal_default: "Well suited for …",
    filter_bloom_all: "🎓 Bloom: all levels",
    filter_bloom_from: "from level",
    setup: "Setup",
    setup_help: "How much effort does it take to ONE-TIME create and configure this activity?",
    support: "Support",
    support_help: "How much ongoing effort is needed DURING use – moderating, grading, replying?",
    setup_einfach: "Easy",
    setup_mittel: "Medium",
    setup_komplex: "Complex",
    support_gering: "Low",
    support_mittel: "Medium",
    support_hoch: "High",
    activity: "Activity",
    bloom_short: "Bloom",
    bloom_help: "Which cognitive learning levels of Bloom's Taxonomy does this activity typically support? 1=Remember, 6=Create.",
    suit_good: "Well suited",
    suit_partial: "Partially suited",
    suit_bad: "Not suited",
    empty_title: "No matching activities found",
    empty_text: "There is no Moodle activity that matches the selected combination. Loosen one or more filters to see suggestions – or try the Wizard for a guided selection.",
    empty_reset: "Reset filters",
    wizard_step1: "Goal",
    wizard_step2: "Setup",
    wizard_step3: "Support",
    wizard_step4: "Bloom",
    wizard_q1: "What do you want to achieve?",
    wizard_q2: "How much setup effort is acceptable?",
    wizard_q3: "How much ongoing support effort is acceptable?",
    wizard_results: "matching tools found",
    wizard_back: "Back",
    wizard_restart: "Start over",
    wizard_skip: "Any",
    wizard_skip_desc: "Doesn't matter",
    overview: "Overview",
    suitability_header: "Suitability by didactic goal",
    docs_btn: "Moodle Docs",
    community_btn: "More ideas at eledia.community",
    in_compare: "✓ In comparison",
    add_compare: "+ Compare",
    description: "Description",
    repo_btn: "Source on GitHub",
    footer: "Based on the Moodle Tool Guide · eLeDia · Idea: Joyce Seitzinger",
    bloom_levels: ["Remember", "Understand", "Apply", "Analyze", "Evaluate", "Create"],
    bloom_descs: [
      "Recall facts and basic concepts.",
      "Explain ideas or concepts in your own words.",
      "Use information in new situations.",
      "Draw connections among ideas.",
      "Justify a stand or decision based on the material.",
      "Produce new or original work."
    ],
    goals: {
      info: { label: "Information & Transfer", q: "Is it suitable for delivering information?" },
      bewerten: { label: "Assessment", q: "Does it allow measuring knowledge?" },
      komm: { label: "Communication & Interaction", q: "Can it be used for communication?" },
      collab: { label: "Collaborative Creation", q: "Can content be created cooperatively?" },
      bloomG: { label: "Bloom's Learning Goals", q: "Which learning goals are supported?" }
    }
  ,
    wizard_step5: "Result"
  ,
    wizard_q4: "Minimum Bloom level?"
  ,
    credit_original: "Original concept"
  ,
    credit_translation: "Based on a translation by"
  ,
    dialog_close: "Close"
  ,
    credit_license: "License"
  ,
    credit_eledia: "Adapted by the Moodle experts of eLeDia | eLearning im Dialog. More Moodle know-how at"
  ,
    wizard_breadcrumb: "Wizard steps"
  ,
    wizard_jump_to: "Back to step"
  ,
    a11y_font_larger: "Larger text"
  ,
    a11y_font_smaller: "Smaller text"
  ,
    a11y_font_reset: "Reset text size"
  ,
    alt_eledia_logo: "eLeDia – eLearning im Dialog"
  ,
    alt_eledia_favicon: "eLeDia logo"
  ,
    alt_moodle_partner: "Moodle Premium Certified Services Provider"
  ,
    alt_github: "Source on GitHub"
  ,
    alt_cc_byncsa: "License: Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International"
  },
  fr: {
    title: "Guide des outils Moodle",
    subtitle: "Trouvez l'outil adapté à votre objectif didactique",
    nav_matrix: "Matrice",
    nav_cards: "Cartes",
    nav_wizard: "Assistant",
    search_placeholder: "Rechercher un outil…",
    compare_btn: "Comparer",
    filter_setup_all: "Effort de mise en place : tous",
    filter_support_all: "Effort d'animation : tous",
    filter_goal_default: "Bien adapté pour …",
    filter_bloom_all: "🎓 Bloom : tous les niveaux",
    filter_bloom_from: "à partir du niveau",
    setup: "Mise en place",
    setup_help: "Quel effort faut-il pour créer et configurer cette activité UNE FOIS ?",
    support: "Animation",
    support_help: "Quel effort continu est nécessaire PENDANT l'utilisation – modérer, évaluer, répondre ?",
    setup_einfach: "Facile",
    setup_mittel: "Moyen",
    setup_komplex: "Complexe",
    support_gering: "Faible",
    support_mittel: "Moyen",
    support_hoch: "Élevé",
    activity: "Activité",
    bloom_short: "Bloom",
    bloom_help: "Quels niveaux cognitifs de la taxonomie de Bloom cette activité couvre-t-elle ? 1=Se souvenir, 6=Créer.",
    suit_good: "Bien adapté",
    suit_partial: "Partiellement adapté",
    suit_bad: "Inadapté",
    empty_title: "Aucune activité correspondante",
    empty_text: "Il n'existe pas d'activité Moodle correspondant à cette combinaison. Assouplissez un ou plusieurs filtres pour voir des suggestions – ou essayez l'Assistant pour une sélection guidée.",
    empty_reset: "Réinitialiser les filtres",
    wizard_step1: "Objectif",
    wizard_step2: "Mise en place",
    wizard_step3: "Suivi",
    wizard_step4: "Bloom",
    wizard_q1: "Que voulez-vous accomplir ?",
    wizard_q2: "Combien d'effort de mise en place est acceptable?",
    wizard_q3: "Combien d'effort de suivi continu est acceptable?",
    wizard_results: "outils correspondants trouvés",
    wizard_back: "Retour",
    wizard_restart: "Recommencer",
    wizard_skip: "Peu importe",
    wizard_skip_desc: "Aucune importance",
    overview: "Aperçu",
    suitability_header: "Adéquation par objectif didactique",
    docs_btn: "Docs Moodle",
    community_btn: "Plus d'idées sur eledia.community",
    in_compare: "✓ Dans la comparaison",
    add_compare: "+ Comparer",
    description: "Description",
    repo_btn: "Code source sur GitHub",
    footer: "Basé sur le Moodle Tool Guide · eLeDia · Idée : Joyce Seitzinger",
    bloom_levels: ["Se souvenir", "Comprendre", "Appliquer", "Analyser", "Évaluer", "Créer"],
    bloom_descs: [
      "Rappeler des faits et des concepts de base.",
      "Expliquer des idées ou des concepts en ses propres mots.",
      "Utiliser l'information dans de nouvelles situations.",
      "Établir des liens entre les idées.",
      "Justifier une position en s'appuyant sur le matériel.",
      "Produire un travail nouveau ou original."
    ],
    goals: {
      info: { label: "Information & Transfert", q: "Convient-il à la diffusion d'informations ?" },
      bewerten: { label: "Évaluer", q: "Permet-il de mesurer les connaissances ?" },
      komm: { label: "Communication & Interaction", q: "Peut-il être utilisé pour communiquer ?" },
      collab: { label: "Création collaborative", q: "Le contenu peut-il être créé en coopération ?" },
      bloomG: { label: "Objectifs de Bloom", q: "Quels objectifs d'apprentissage sont soutenus ?" }
    }
  ,
    wizard_step5: "Résultat"
  ,
    wizard_q4: "Niveau Bloom minimum?"
  ,
    credit_original: "Concept original"
  ,
    credit_translation: "Basé sur une traduction de"
  ,
    dialog_close: "Fermer"
  ,
    credit_license: "Licence"
  ,
    credit_eledia: "Adapté par les expert·e·s Moodle de eLeDia | eLearning im Dialog. Plus de savoir Moodle sur"
  ,
    wizard_breadcrumb: "Étapes de l'assistant"
  ,
    wizard_jump_to: "Retour à l'étape"
  ,
    a11y_font_larger: "Texte plus grand"
  ,
    a11y_font_smaller: "Texte plus petit"
  ,
    a11y_font_reset: "Taille normale"
  ,
    alt_eledia_logo: "eLeDia – eLearning im Dialog"
  ,
    alt_eledia_favicon: "Logo eLeDia"
  ,
    alt_moodle_partner: "Moodle Premium Certified Services Provider"
  ,
    alt_github: "Code source sur GitHub"
  ,
    alt_cc_byncsa: "Licence : Creative Commons Attribution – Pas d'utilisation commerciale – Partage dans les mêmes conditions 4.0 International"
  },
  es: {
    title: "Guía de herramientas Moodle",
    subtitle: "Encuentra la herramienta adecuada para tu objetivo didáctico",
    nav_matrix: "Matriz",
    nav_cards: "Tarjetas",
    nav_wizard: "Asistente",
    search_placeholder: "Buscar herramienta…",
    compare_btn: "Comparar",
    filter_setup_all: "Esfuerzo de configuración: todos",
    filter_support_all: "Esfuerzo de tutoría: todos",
    filter_goal_default: "Bien adaptado para …",
    filter_bloom_all: "🎓 Bloom: todos los niveles",
    filter_bloom_from: "desde el nivel",
    setup: "Configuración",
    setup_help: "¿Cuánto esfuerzo cuesta crear y configurar esta actividad UNA VEZ?",
    support: "Tutoría",
    support_help: "¿Cuánto esfuerzo continuo se necesita DURANTE el uso – moderar, evaluar, responder?",
    setup_einfach: "Fácil",
    setup_mittel: "Medio",
    setup_komplex: "Complejo",
    support_gering: "Bajo",
    support_mittel: "Medio",
    support_hoch: "Alto",
    activity: "Actividad",
    bloom_short: "Bloom",
    bloom_help: "¿Qué niveles cognitivos de la Taxonomía de Bloom cubre esta actividad? 1=Recordar, 6=Crear.",
    suit_good: "Bien adaptado",
    suit_partial: "Parcialmente adaptado",
    suit_bad: "No adaptado",
    empty_title: "No se encontraron actividades",
    empty_text: "No hay ninguna actividad de Moodle que coincida con esta combinación. Relaja uno o varios filtros para ver sugerencias – o prueba el Asistente para una selección guiada.",
    empty_reset: "Restablecer filtros",
    wizard_step1: "Objetivo",
    wizard_step2: "Configuración",
    wizard_step3: "Acompañamiento",
    wizard_step4: "Bloom",
    wizard_q1: "¿Qué quieres lograr?",
    wizard_q2: "¿Cuánto esfuerzo de configuración es aceptable?",
    wizard_q3: "¿Cuánto esfuerzo de acompañamiento continuo es aceptable?",
    wizard_results: "herramientas encontradas",
    wizard_back: "Atrás",
    wizard_restart: "Reiniciar",
    wizard_skip: "Cualquiera",
    wizard_skip_desc: "No importa",
    overview: "Resumen",
    suitability_header: "Idoneidad por objetivo didáctico",
    docs_btn: "Documentación Moodle",
    community_btn: "Más ideas en eledia.community",
    in_compare: "✓ En comparación",
    add_compare: "+ Comparar",
    description: "Descripción",
    repo_btn: "Código fuente en GitHub",
    footer: "Basado en el Moodle Tool Guide · eLeDia · Idea: Joyce Seitzinger",
    bloom_levels: ["Recordar", "Comprender", "Aplicar", "Analizar", "Evaluar", "Crear"],
    bloom_descs: [
      "Recordar hechos y conceptos básicos.",
      "Explicar ideas o conceptos con tus propias palabras.",
      "Usar información en nuevas situaciones.",
      "Establecer conexiones entre ideas.",
      "Justificar una postura basándose en el material.",
      "Producir un trabajo nuevo u original."
    ],
    goals: {
      info: { label: "Información y transferencia", q: "¿Es adecuado para transmitir información?" },
      bewerten: { label: "Evaluar", q: "¿Permite medir conocimientos?" },
      komm: { label: "Comunicación e interacción", q: "¿Puede usarse para comunicarse?" },
      collab: { label: "Crear en colaboración", q: "¿Se puede crear contenido cooperativamente?" },
      bloomG: { label: "Objetivos de Bloom", q: "¿Qué objetivos de aprendizaje se apoyan?" }
    }
  ,
    wizard_step5: "Resultado"
  ,
    wizard_q4: "¿Nivel Bloom mínimo?"
  ,
    credit_original: "Concepto original"
  ,
    credit_translation: "Basado en una traducción de"
  ,
    dialog_close: "Cerrar"
  ,
    credit_license: "Licencia"
  ,
    credit_eledia: "Adaptado por las y los expertos Moodle de eLeDia | eLearning im Dialog. Más saber Moodle en"
  ,
    wizard_breadcrumb: "Pasos del asistente"
  ,
    wizard_jump_to: "Volver al paso"
  ,
    a11y_font_larger: "Texto más grande"
  ,
    a11y_font_smaller: "Texto más pequeño"
  ,
    a11y_font_reset: "Tamaño normal"
  ,
    alt_eledia_logo: "eLeDia – eLearning im Dialog"
  ,
    alt_eledia_favicon: "Logo eLeDia"
  ,
    alt_moodle_partner: "Moodle Premium Certified Services Provider"
  ,
    alt_github: "Código fuente en GitHub"
  ,
    alt_cc_byncsa: "Licencia: Creative Commons Atribución – No comercial – Compartir igual 4.0 Internacional"
  }
};


// Moodle 5 activity purposes — official color palette from core.
const PURPOSE_COLORS = {
  administration:    "#da58ef",
  assessment:        "#f90086",
  collaboration:     "#5b40ff",
  communication:     "#eb6200",
  interactivecontent:"#8d3d1b",
  content:           "#0099ad"
};

const PURPOSE_LABELS = {
  de: {
    administration:"Verwaltung", assessment:"Bewertung", collaboration:"Zusammenarbeit",
    communication:"Kommunikation", interactivecontent:"Interaktive Inhalte", content:"Ressourcen"
  },
  en: {
    administration:"Administration", assessment:"Assessment", collaboration:"Collaboration",
    communication:"Communication", interactivecontent:"Interactive content", content:"Resources"
  },
  fr: {
    administration:"Administration", assessment:"Évaluation", collaboration:"Collaboration",
    communication:"Communication", interactivecontent:"Contenu interactif", content:"Ressources"
  },
  es: {
    administration:"Administración", assessment:"Evaluación", collaboration:"Colaboración",
    communication:"Comunicación", interactivecontent:"Contenido interactivo", content:"Recursos"
  }
};

// Map every tool id to its Moodle activity purpose.
const TOOL_PURPOSE = {
  datei:"content", verzeichnis:"content", textseite:"content", buch:"content", url:"content",
  wiki:"collaboration", glossar:"collaboration", datenbank:"collaboration", lerntagebuch:"collaboration",
  forum:"communication", chat:"communication", bbb:"communication", abstimmung:"communication",
  feedback:"communication", umfrage:"communication", board:"communication",
  test:"assessment", aufgabe:"assessment", beurteilung:"assessment",
  lektion:"interactivecontent", lernpaket:"interactivecontent", extern:"interactivecontent",
  anwesenheit:"administration"
};

function purposeOf(tool) { return TOOL_PURPOSE[tool.id] || "content"; }
function purposeColor(tool) { return PURPOSE_COLORS[purposeOf(tool)]; }
function purposeLabel(tool, lang) { return (PURPOSE_LABELS[lang]||PURPOSE_LABELS.de)[purposeOf(tool)]; }

const REPO_URL = "https://github.com/jmoskaliuk/local_eledia_moodletoolguide";

// Helper function to render text – component must call this with current lang
const t = (lang, key) => I18N[lang][key] || key;
const tg = (lang, key) => I18N[lang].goals[key] || {label:key, q:""};

// ============================================================================
// Visual helpers
// ============================================================================

// eLeDia palette accent colors for ratings
const rc = r => r==="grün"?"#669933":r==="orange"?"#267372":r==="rot"?"#C25B00":"#999";
// background tints
const rb = r => r==="grün"?"#d1e0c1":r==="orange"?"#a9cbd5":"#ffecdb";
const rl = (r, lang) => r==="grün"?t(lang,"suit_good"):r==="orange"?t(lang,"suit_partial"):t(lang,"suit_bad");

// setup/support effort labels
const setupLabel = (s, lang) => s==="einfach"?t(lang,"setup_einfach"):s==="mittel"?t(lang,"setup_mittel"):t(lang,"setup_komplex");
const supportLabel = (s, lang) => s==="gering"?t(lang,"support_gering"):s==="mittel"?t(lang,"support_mittel"):t(lang,"support_hoch");
// effort badge colors (eLeDia palette: low=green, medium=blue, high=warm)
const effortColor = level => level==="einfach"||level==="gering"?"#669933":level==="mittel"?"#194866":"#f98012";
const effortBg = level => level==="einfach"||level==="gering"?"#D1E0C1":level==="mittel"?"#A9CBD5":"#FFECDB";
const effortDots = level => level==="einfach"||level==="gering"?"●○○":level==="mittel"?"●●○":"●●●";

function ToolIcon({toolId, size=32}) {
  const icon = TOOL_ICONS[toolId];
  if (!icon) return null;
  const r = Math.round(size * 0.2);
  const purpose = TOOL_PURPOSE[toolId] || "content";
  const bg = PURPOSE_COLORS[purpose] || icon.bg;
  return React.createElement("span",{
    "aria-hidden":"true",
    style:{display:"inline-flex",alignItems:"center",justifyContent:"center",width:size,height:size,borderRadius:r,background:bg,flexShrink:0},
    dangerouslySetInnerHTML:{__html:`<svg viewBox="0 0 24 24" width="${size*0.6}" height="${size*0.6}">${icon.svg}</svg>`}
  });
}

function GoalIcon({goalKey, color, size=20, title=""}) {
  return React.createElement("span",{
    title:title,
    "aria-hidden": title ? null : "true",
    style:{display:"inline-block",width:size,height:size,pointerEvents:title?"auto":"none"},
    dangerouslySetInnerHTML:{__html:`<svg style="pointer-events:none" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${GOAL_SVG[goalKey]||""}</svg>`}
  });
}

// Rating icons for matrix cells: up / neutral / down — pure Lucide paths (v1.8.0).
// grün   = lucide thumbs-up
// orange = lucide circle-slash  (neutral / "weder noch")
// rot    = lucide thumbs-down
const LUCIDE_STROKE = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
const THUMBS_UP_PATH = '<path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/><path d="M7 10v12"/>';
const THUMBS_DOWN_PATH = '<path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z"/><path d="M17 14V2"/>';
const CIRCLE_SLASH_PATH = '<circle cx="12" cy="12" r="10"/><line x1="9" x2="15" y1="15" y2="9"/>';
const THUMBS = {
  grün:   `<g ${LUCIDE_STROKE}>${THUMBS_UP_PATH}</g>`,
  orange: `<g ${LUCIDE_STROKE}>${CIRCLE_SLASH_PATH}</g>`,
  rot:    `<g ${LUCIDE_STROKE}>${THUMBS_DOWN_PATH}</g>`
};


// Accessibility: focus trap + initial focus + return focus for modal dialogs
function useFocusTrap(active) {
  const containerRef = React.useRef(null);
  React.useEffect(() => {
    if (!active) return;
    const previouslyFocused = document.activeElement;
    const container = containerRef.current;
    if (!container) return;
    // Initial focus: first focusable in dialog, else container itself
    const getFocusable = () => Array.from(container.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    )).filter(el => !el.disabled && el.offsetParent !== null);
    const focusables = getFocusable();
    if (focusables.length > 0) {
      focusables[0].focus();
    } else {
      container.setAttribute("tabindex","-1");
      container.focus();
    }
    // Trap Tab cycles
    const handleKeyDown = (e) => {
      if (e.key !== "Tab") return;
      const fs = getFocusable();
      if (fs.length === 0) { e.preventDefault(); return; }
      const first = fs[0];
      const last = fs[fs.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    container.addEventListener("keydown", handleKeyDown);
    return () => {
      container.removeEventListener("keydown", handleKeyDown);
      // Return focus to previously focused element
      if (previouslyFocused && previouslyFocused.focus) {
        try { previouslyFocused.focus(); } catch (e) {}
      }
    };
  }, [active]);
  return containerRef;
}

function ThumbIcon({rating, size=22, title=""}) {
  const color = rc(rating);
  return React.createElement("span", {
    title: title,
    role: "img",
    "aria-label": title,
    style: {display:"inline-flex",alignItems:"center",justifyContent:"center",width:size+10,height:size+10,borderRadius:8,background:rb(rating),color:color,cursor:"help"},
    dangerouslySetInnerHTML: {__html:`<svg width="${size}" height="${size}" viewBox="0 0 24 24" style="pointer-events:none">${THUMBS[rating]||THUMBS.rot}</svg>`}
  });
}

function BloomHats({bloom, lang, size=14}) {
  // Classic moodletoolguide rendering: n filled mortarboards out of 6.
  const n = parseInt(bloom) || 0;
  const out = [];
  for (let i = 0; i < 6; i++) {
    out.push(React.createElement("span",{
      key:i,
      style:{
        fontSize:size,
        opacity: i < n ? 1 : 0.18,
        filter: i < n ? "none" : "grayscale(1)",
        marginRight:1, lineHeight:1
      },
      "aria-hidden":"true"
    },"\u{1F393}"));
  }
  return React.createElement("span",{
    role:"img","aria-label":"Bloom "+n+"/6",
    style:{display:"inline-flex",alignItems:"center",lineHeight:1}
  }, out);
}

function BloomBars({bloom, lang, size=14}) {
  const n = parseInt(bloom) || 0;
  const levels = I18N[lang].bloom_levels;
  const descs = I18N[lang].bloom_descs;
  // eLeDia gradient: dark blue → teal → green → yellow → orange (CI tones)
  const colors = ["#194866","#267372","#669933","#A5C387","#FCBC82","#F98012"];
  const barW = Math.round(size * 0.9);
  const barH = Math.max(3, Math.round(size * 0.35));
  return React.createElement("span", {
    role:"img","aria-label":"Bloom "+n+"/6",
    title:"Bloom "+n+"/6",
    style:{display:"inline-flex",flexDirection:"column-reverse",gap:1,alignItems:"flex-start",cursor:"help",padding:"1px 2px"},
  },
    Array.from({length:6},(_,i) => {
      const active = i < n;
      const w = barW * (0.4 + 0.12*i);
      return React.createElement("span",{
        key:i,
        title: (i+1)+". "+levels[i]+(active?" \u2013 "+descs[i]:""),
        "aria-label": (i+1)+". "+levels[i],
        style:{display:"block",width:w,height:barH,borderRadius:1,background:active?colors[i]:"#E9E9E9",transition:"background 0.2s"}
      });
    })
  );
}

// effort badge component – display: "compact" (dots only), "value" (dots+value), "labeled" (dots + "Label: Value")
function EffortBadge({level, kind, lang, display}) {
  const value = kind==="setup" ? setupLabel(level, lang) : supportLabel(level, lang);
  const colLabel = kind==="setup" ? t(lang,"setup") : t(lang,"support");
  const help = kind==="setup" ? t(lang,"setup_help") : t(lang,"support_help");
  display = display || "value";
  if (display === "compact") {
    // matrix cells: dots only, full info via title
    return React.createElement("span", {
      title: colLabel+": "+value+" – "+help,
      role:"img","aria-label":colLabel+": "+value,
      style:{display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:14,letterSpacing:2,color:effortColor(level),cursor:"help",padding:"4px 6px",borderRadius:8,background:effortBg(level)}
    }, React.createElement("span",{"aria-hidden":"true"},effortDots(level)));
  }
  if (display === "labeled") {
    // cards: only label + dots ("Einrichtung ●○○"), value is in title
    return React.createElement("span", {
      title: help+" – "+value,
      "aria-label": colLabel+": "+value,
      style:{display:"inline-flex",alignItems:"center",gap:6,padding:"4px 10px",borderRadius:12,fontSize:11,fontWeight:600,background:effortBg(level),color:effortColor(level),cursor:"help"}
    },
      React.createElement("span",{"aria-hidden":"true",style:{fontSize:10,letterSpacing:1.5}},effortDots(level)),
      React.createElement("span",null,colLabel)
    );
  }
  // default "value": dots + value
  return React.createElement("span", {
    title: help+" – "+value,
    style: {display:"inline-flex",alignItems:"center",gap:4,padding:"3px 8px",borderRadius:12,fontSize:11,fontWeight:600,background:effortBg(level),color:effortColor(level),cursor:"help"}
  },
    React.createElement("span",{"aria-hidden":"true",style:{fontSize:9,letterSpacing:1}},effortDots(level)),
    value
  );
}

// ============================================================================
// Components
// ============================================================================
function ToolCard({tool, onSelect, onCompare, isC, lang}) {
  const goals = ["info","bewerten","komm","collab","bloomG"];
  return React.createElement("div", {
    onClick:()=>onSelect(tool),
    role:"button",
    tabIndex:0,
    onKeyDown:e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();onSelect(tool);}},
    "aria-label":tool.name,
    style:{background:"white",borderRadius:12,padding:18,cursor:"pointer",boxShadow:"0 1px 3px rgba(0,0,0,0.08)",border:isC?"2px solid #f98012":"2px solid transparent",transition:"all 0.2s"},
    onMouseEnter:e=>{e.currentTarget.style.boxShadow="0 4px 12px rgba(0,0,0,0.12)";e.currentTarget.style.transform="translateY(-2px)"},
    onMouseLeave:e=>{e.currentTarget.style.boxShadow="0 1px 3px rgba(0,0,0,0.08)";e.currentTarget.style.transform="none"}
  },
    React.createElement("div",{style:{display:"flex",gap:12,alignItems:"flex-start",marginBottom:12}},
      React.createElement(ToolIcon,{toolId:tool.id,size:42}),
      React.createElement("div",{style:{flex:1,minWidth:0}},
        React.createElement("h3",{style:{margin:0,fontSize:17,color:"#194866",fontWeight:700}},tool.name),
        React.createElement("p",{style:{margin:"2px 0 0",fontSize:12,color:"#707070",lineHeight:1.3}},tool.desc)
      )
    ),
    React.createElement("div",{style:{display:"flex",gap:6,marginBottom:10,flexWrap:"wrap"}},
      React.createElement(EffortBadge,{level:tool.setup,kind:"setup",lang:lang,display:"labeled"}),
      React.createElement(EffortBadge,{level:tool.support,kind:"support",lang:lang,display:"labeled"})
    ),
    React.createElement("div",{style:{display:"flex",gap:6,marginBottom:10,flexWrap:"wrap",alignItems:"center"}},
      goals.map(gk=>React.createElement("span",{key:gk,title:tg(lang,gk).label+": "+rl(tool.goals[gk].r,lang),style:{display:"inline-flex",alignItems:"center",justifyContent:"center",width:30,height:30,borderRadius:8,background:rb(tool.goals[gk].r),cursor:"help"}},
        React.createElement(GoalIcon,{goalKey:gk,color:rc(tool.goals[gk].r),size:16})
      ))
    ),
    React.createElement("div",{style:{marginBottom:10}},React.createElement(BloomHats,{bloom:tool.bloom,lang:lang,size:25})),
    React.createElement("p",{style:{fontSize:11,color:"#707070",lineHeight:1.4,margin:"0 0 10px",borderTop:"1px solid #E9E9E9",paddingTop:8,fontStyle:"italic"}},tool.complexityText),
    onCompare&&React.createElement("div",{style:{display:"flex",justifyContent:"flex-end",alignItems:"center"}},
      React.createElement("button",{onClick:e=>{e.stopPropagation();onCompare(tool.id)},style:{fontSize:11,padding:"4px 10px",borderRadius:6,border:isC?"1px solid #f98012":"1px solid #E9E9E9",background:isC?"#FFECDB":"white",color:isC?"#f98012":"#707070",cursor:"pointer"}},isC?t(lang,"in_compare"):t(lang,"add_compare"))
    )
  );
}

function MatrixView({tools, onSelect, filters, onResetFilters, lang}) {
  let filtered = tools.filter(t=>{
    if(filters.setup&&t.setup!==filters.setup) return false;
    if(filters.support&&t.support!==filters.support) return false;
    if(filters.goal&&filters.onlyGreen&&t.goals[filters.goal]?.r!=="grün") return false;
    if(filters.bloomMin&&parseInt(t.bloom)<filters.bloomMin) return false;
    return true;
  });
  if(filtered.length===0) {
    return React.createElement("div",{role:"status","aria-live":"polite",style:{maxWidth:600,margin:"40px auto",padding:32,background:"#FFECDB",border:"2px dashed #f98012",borderRadius:12,textAlign:"center"}},
      React.createElement("div",{style:{fontSize:48,marginBottom:8},"aria-hidden":"true"},"🔍"),
      React.createElement("h3",{style:{margin:"0 0 8px",color:"#194866",fontSize:18}},t(lang,"empty_title")),
      React.createElement("p",{style:{margin:"0 0 16px",color:"#353535",fontSize:14,lineHeight:1.5}},t(lang,"empty_text")),
      React.createElement("button",{onClick:onResetFilters,style:{padding:"8px 16px",borderRadius:8,border:"none",background:"#b85a00",color:"white",cursor:"pointer",fontSize:13,fontWeight:600}},t(lang,"empty_reset"))
    );
  }
  const goalKeys = ["info","bewerten","komm","collab","bloomG"];
  return React.createElement("div",{style:{overflowX:"auto",borderRadius:12,boxShadow:"0 1px 3px rgba(0,0,0,0.05)"}},
    React.createElement("div",{role:"status","aria-live":"polite",className:"sr-only"},filtered.length+" "+t(lang,"wizard_results")),
    React.createElement("table",{style:{width:"100%",borderCollapse:"separate",borderSpacing:0,fontSize:13,background:"white"},"aria-label":"Moodle Tool Guide Matrix"},
      React.createElement("thead",null,
        React.createElement("tr",null,
          React.createElement("th",{scope:"col",style:{position:"sticky",left:0,background:"#194866",color:"white",padding:"12px 14px",textAlign:"left",zIndex:2,minWidth:130}},t(lang,"activity")),
          React.createElement("th",{scope:"col",title:t(lang,"setup_help"),style:{background:"#194866",color:"white",padding:"12px 8px",textAlign:"center",minWidth:90,cursor:"help"}},
            React.createElement("div",{style:{display:"flex",justifyContent:"center",opacity:0.9},"aria-hidden":"true"},React.createElement(IconMonitorCog,{size:16,color:"white"})),React.createElement("div",{style:{fontSize:12,marginTop:4}},t(lang,"setup"))
          ),
          React.createElement("th",{scope:"col",title:t(lang,"support_help"),style:{background:"#194866",color:"white",padding:"12px 8px",textAlign:"center",minWidth:90,cursor:"help"}},
            React.createElement("div",{style:{display:"flex",justifyContent:"center",opacity:0.9},"aria-hidden":"true"},React.createElement(IconUsers,{size:16,color:"white"})),React.createElement("div",{style:{fontSize:12,marginTop:4}},t(lang,"support"))
          ),
          goalKeys.map((gk,i)=>React.createElement("th",{key:gk,scope:"col",title:tg(lang,gk).q,style:{background:"#194866",color:"white",padding:"12px 10px",textAlign:"center",minWidth:80,cursor:"help",borderRadius:i===goalKeys.length-1?"0 8px 0 0":0}},
            React.createElement("div",{style:{display:"flex",justifyContent:"center"}},React.createElement(GoalIcon,{goalKey:gk,color:"white",size:18})),
            React.createElement("div",{style:{fontSize:11,marginTop:4,maxWidth:90,margin:"4px auto 0"}},tg(lang,gk).label)
          ))
        )
      ),
      React.createElement("tbody",null,
        filtered.map((tool,idx)=>React.createElement("tr",{key:tool.id,onClick:()=>onSelect(tool),tabIndex:0,role:"button","aria-label":tool.name,
          onKeyDown:e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();onSelect(tool);}},
          style:{cursor:"pointer",background:idx%2===0?"white":"#F3F5F8"},
          onMouseEnter:e=>e.currentTarget.style.background="#D1ECEB",onMouseLeave:e=>e.currentTarget.style.background=idx%2===0?"white":"#F3F5F8"},
          React.createElement("td",{style:{position:"sticky",left:0,background:"inherit",padding:"10px 14px",fontWeight:600,borderBottom:"1px solid #E9E9E9",zIndex:1}},
            React.createElement("div",{style:{display:"flex",alignItems:"center",gap:8}},React.createElement(ToolIcon,{toolId:tool.id,size:28}),React.createElement("span",{style:{color:"#194866"}},tool.name))
          ),
          React.createElement("td",{style:{padding:8,textAlign:"center",borderBottom:"1px solid #E9E9E9"}},
            React.createElement(EffortBadge,{level:tool.setup,kind:"setup",lang:lang,display:"compact"})
          ),
          React.createElement("td",{style:{padding:8,textAlign:"center",borderBottom:"1px solid #E9E9E9"}},
            React.createElement(EffortBadge,{level:tool.support,kind:"support",lang:lang,display:"compact"})
          ),
          goalKeys.map(gk=>{
            const r = tool.goals[gk].r;
            const tooltipText = tg(lang,gk).label+": "+rl(r,lang)+" – "+tool.goals[gk].t;
            if (gk==="bloomG") {
              return React.createElement("td",{key:gk,style:{padding:8,textAlign:"center",borderBottom:"1px solid #E9E9E9"}},
                React.createElement("div",{title:tooltipText,style:{display:"flex",justifyContent:"center",cursor:"help"}},
                  React.createElement(BloomHats,{bloom:tool.bloom,lang:lang,size:14})
                )
              );
            }
            return React.createElement("td",{key:gk,style:{padding:8,textAlign:"center",borderBottom:"1px solid #E9E9E9"}},
              React.createElement(ThumbIcon,{rating:r,size:22,title:tooltipText})
            );
          })
        ))
      )
    )
  );
}

function DetailModal({tool,onClose,lang}) {
  if(!tool) return null;
  const goalKeys = ["info","bewerten","komm","collab","bloomG"];
  React.useEffect(()=>{
    const h = e => { if(e.key==="Escape") onClose(); };
    document.addEventListener("keydown",h);
    return () => document.removeEventListener("keydown",h);
  },[onClose]);
  const trapRef = useFocusTrap(true);
  return React.createElement("div",{role:"dialog","aria-modal":"true","aria-label":tool.name,style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:100,display:"flex",justifyContent:"center",alignItems:"center",padding:20},onClick:onClose},
    React.createElement("div",{ref:trapRef,style:{background:"white",borderRadius:16,maxWidth:700,width:"100%",maxHeight:"90vh",overflow:"auto",padding:24},onClick:e=>e.stopPropagation()},
      React.createElement("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:20,gap:12}},
        React.createElement("div",{style:{display:"flex",gap:14,alignItems:"center",flex:1,minWidth:0}},
          React.createElement(ToolIcon,{toolId:tool.id,size:48}),
          React.createElement("div",{style:{minWidth:0}},
            React.createElement("h2",{style:{margin:0,fontSize:22,color:"#194866"}},tool.name),
            React.createElement("p",{style:{margin:"4px 0 0",color:"#707070",fontSize:14}},tool.desc)
          )
        ),
        React.createElement("button",{onClick:onClose,"aria-label":t(lang,"dialog_close"),style:{background:"none",border:"none",fontSize:28,cursor:"pointer",color:"#8A8A8E",padding:4,lineHeight:1}},"\u00D7")
      ),
      React.createElement("div",{style:{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}},
        React.createElement(EffortBadge,{level:tool.setup,kind:"setup",lang:lang}),
        React.createElement(EffortBadge,{level:tool.support,kind:"support",lang:lang}),
        React.createElement("span",{style:{background:"#F3F5F8",padding:"4px 12px",borderRadius:20,fontSize:12,display:"inline-flex",alignItems:"center",gap:6}},"Bloom: ",React.createElement(BloomHats,{bloom:tool.bloom,lang:lang,size:14}))
      ),
      tool.longDesc?React.createElement("div",{style:{margin:"0 0 20px",padding:14,background:"#F3F5F8",borderRadius:10,borderLeft:"4px solid #194866"}},
        React.createElement("h3",{style:{fontSize:14,margin:"0 0 6px",color:"#194866",textTransform:"uppercase",letterSpacing:0.5}},t(lang,"overview")),
        React.createElement("p",{style:{margin:0,fontSize:13,color:"#353535",lineHeight:1.6}},tool.longDesc)
      ):null,
      React.createElement("h3",{style:{fontSize:14,margin:"0 0 12px",color:"#194866",textTransform:"uppercase",letterSpacing:0.5}},t(lang,"suitability_header")),
      goalKeys.map(gk=>React.createElement("div",{key:gk,style:{marginBottom:10,padding:12,background:rb(tool.goals[gk].r),borderRadius:10,borderLeft:"4px solid "+rc(tool.goals[gk].r)}},
        React.createElement("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4,gap:8}},
          React.createElement("span",{style:{display:"inline-flex",alignItems:"center",gap:6,fontWeight:600,fontSize:13,color:"#194866"}},React.createElement(GoalIcon,{goalKey:gk,color:rc(tool.goals[gk].r),size:18}),tg(lang,gk).label),
          React.createElement("span",{style:{fontSize:11,color:rc(tool.goals[gk].r),fontWeight:600,whiteSpace:"nowrap"}},rl(tool.goals[gk].r,lang))
        ),
        React.createElement("p",{style:{margin:0,fontSize:12,color:"#353535",lineHeight:1.5}},tool.goals[gk].t)
      )),
      React.createElement("div",{style:{display:"flex",gap:10,flexWrap:"wrap",marginTop:20}},
        tool.docsUrl?React.createElement("a",{href:tool.docsUrl,target:"_blank",rel:"noopener",style:{fontSize:13,padding:"8px 16px",borderRadius:8,background:"#A9CBD5",color:"#194866",textDecoration:"none",border:"1px solid #A9CBD5",fontWeight:500}},t(lang,"docs_btn")):null,
        React.createElement("a",{href:"https://community.eledia.de",target:"_blank",rel:"noopener",style:{fontSize:13,padding:"8px 16px",borderRadius:8,background:"#FFECDB",color:"#f98012",textDecoration:"none",border:"1px solid #FCBC82",fontWeight:500}},t(lang,"community_btn"))
      )
    )
  );
}

function CompareView({toolIds,tools,onClose,lang}) {
  const items = toolIds.map(id=>tools.find(t2=>t2.id===id)).filter(Boolean);
  if(items.length<2) return null;
  const goalKeys = ["info","bewerten","komm","collab","bloomG"];
  const trapRef = useFocusTrap(true);
  return React.createElement("div",{role:"dialog","aria-modal":"true","aria-labelledby":"compare-dialog-title",style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:100,display:"flex",justifyContent:"center",alignItems:"center",padding:20},onClick:onClose},
    React.createElement("div",{ref:trapRef,style:{background:"white",borderRadius:16,maxWidth:900,width:"100%",maxHeight:"90vh",overflow:"auto",padding:24},onClick:e=>e.stopPropagation()},
      React.createElement("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:20}},
        React.createElement("h2",{id:"compare-dialog-title",style:{margin:0,fontSize:20,color:"#194866"}},t(lang,"compare_btn")),
        React.createElement("button",{onClick:onClose,"aria-label":t(lang,"dialog_close"),style:{background:"none",border:"none",fontSize:24,cursor:"pointer",color:"#8A8A8E"}},"\u00D7")
      ),
      React.createElement("div",{style:{overflowX:"auto"}},
      React.createElement("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:13}},
        React.createElement("thead",null,React.createElement("tr",null,
          React.createElement("th",{scope:"col",style:{textAlign:"left",padding:10,borderBottom:"2px solid #E9E9E9",width:"22%"}}),
          items.map(t2=>React.createElement("th",{scope:"col",key:t2.id,style:{textAlign:"center",padding:10,borderBottom:"2px solid #E9E9E9",fontSize:14}},React.createElement("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:6}},React.createElement(ToolIcon,{toolId:t2.id,size:32}),React.createElement("span",{style:{color:"#194866"}},t2.name))))
        )),
        React.createElement("tbody",null,
          React.createElement("tr",null,React.createElement("td",{style:{padding:10,fontWeight:600,borderBottom:"1px solid #F3F5F8",color:"#707070"}},t(lang,"description")),items.map(t2=>React.createElement("td",{key:t2.id,style:{padding:10,textAlign:"center",borderBottom:"1px solid #F3F5F8",color:"#353535",fontSize:12}},t2.desc))),
          React.createElement("tr",null,React.createElement("td",{style:{padding:10,fontWeight:600,borderBottom:"1px solid #F3F5F8",color:"#707070"}},t(lang,"setup")),items.map(t2=>React.createElement("td",{key:t2.id,style:{padding:10,textAlign:"center",borderBottom:"1px solid #F3F5F8"}},React.createElement(EffortBadge,{level:t2.setup,kind:"setup",lang:lang})))),
          React.createElement("tr",null,React.createElement("td",{style:{padding:10,fontWeight:600,borderBottom:"1px solid #F3F5F8",color:"#707070"}},t(lang,"support")),items.map(t2=>React.createElement("td",{key:t2.id,style:{padding:10,textAlign:"center",borderBottom:"1px solid #F3F5F8"}},React.createElement(EffortBadge,{level:t2.support,kind:"support",lang:lang})))),
          React.createElement("tr",null,React.createElement("td",{style:{padding:10,fontWeight:600,borderBottom:"1px solid #F3F5F8",color:"#707070"}},"Bloom"),items.map(t2=>React.createElement("td",{key:t2.id,style:{padding:10,textAlign:"center",borderBottom:"1px solid #F3F5F8"}},React.createElement(BloomHats,{bloom:t2.bloom,lang:lang,size:14})))),
          goalKeys.map(gk=>{
            return React.createElement("tr",{key:gk},
              React.createElement("td",{style:{padding:10,fontWeight:600,borderBottom:"1px solid #F3F5F8",color:"#707070"}},React.createElement("span",{style:{display:"inline-flex",alignItems:"center",gap:6}},React.createElement(GoalIcon,{goalKey:gk,color:"#353535",size:16}),tg(lang,gk).label)),
              items.map(t2=>{
                return React.createElement("td",{key:t2.id,style:{padding:10,textAlign:"center",borderBottom:"1px solid #F3F5F8"}},
                  React.createElement(ThumbIcon,{rating:t2.goals[gk].r,size:20,title:rl(t2.goals[gk].r,lang)+" – "+t2.goals[gk].t})
                );
              })
            );
          })
        )
      )
      )
    )
  );
}

function WizardView({tools,onSelect,lang}) {
  const [step,setStep]=React.useState(0);
  const [goal,setGoal]=React.useState(null);
  const [setup,setSetup]=React.useState(null);
  const [support,setSupport]=React.useState(null);
  const [bloomMin,setBloomMin]=React.useState(0);

  const results = React.useMemo(()=>{
    if(step<4) return [];
    return tools.filter(t2=>{
      if(goal&&t2.goals[goal]?.r==="rot") return false;
      if(setup&&t2.setup!==setup) return false;
      if(support&&t2.support!==support) return false;
      if(bloomMin>0&&parseInt(t2.bloom)<bloomMin) return false;
      return true;
    }).sort((a,b)=>{
      if(!goal) return 0;
      const o={"grün":0,"orange":1,"rot":2};
      return (o[a.goals[goal].r]||0)-(o[b.goals[goal].r]||0);
    });
  },[step,goal,setup,support,bloomMin,tools]);

  const sty=active=>({padding:"6px 14px",borderRadius:20,fontSize:12,fontWeight:active?600:400,background:active?"#194866":"#F3F5F8",color:active?"white":"#707070",border:"none"});
  const optBtn=(sel,onClick,children)=>React.createElement("button",{onClick,style:{padding:"14px 18px",borderRadius:12,border:sel?"2px solid #b85a00":"2px solid #E9E9E9",background:sel?"#FFECDB":"white",color:"#353535",cursor:"pointer",textAlign:"left",fontSize:14,transition:"all 0.15s",width:"100%"}},children);

  const goBack = () => { if(step>0) setStep(step-1); };

  return React.createElement("div",{style:{maxWidth:600,margin:"0 auto"}},
    React.createElement("nav",{"aria-label":t(lang,"wizard_breadcrumb"),style:{display:"flex",gap:6,marginBottom:24,justifyContent:"center",flexWrap:"wrap"}},
      [t(lang,"wizard_step1"),t(lang,"wizard_step2"),t(lang,"wizard_step3"),t(lang,"wizard_step4"),t(lang,"wizard_step5")].map((s,i)=>{
        const reachable = i <= step;
        const active = i === step;
        return React.createElement("button",{
          key:i,
          onClick: reachable ? () => setStep(i) : undefined,
          disabled: !reachable,
          "aria-current": active ? "step" : undefined,
          title: reachable ? t(lang,"wizard_jump_to")+" "+(i+1)+". "+s : "",
          style:{...sty(active), cursor: reachable && !active ? "pointer" : (active ? "default" : "not-allowed"), opacity: reachable ? 1 : 0.45}
        },(i+1)+". "+s);
      })
    ),
    step===0&&React.createElement("div",null,
      React.createElement("h3",{style:{textAlign:"center",marginBottom:20,color:"#194866"}},t(lang,"wizard_q1")),
      React.createElement("div",{style:{display:"grid",gap:10}},
        ["info","bewerten","komm","collab"].map(gk=>optBtn(goal===gk,()=>{setGoal(gk);setStep(1)},
          React.createElement("div",{style:{display:"flex",alignItems:"center",gap:10}},React.createElement(GoalIcon,{goalKey:gk,color:goal===gk?"#f98012":"#353535",size:22}),React.createElement("div",null,React.createElement("strong",{style:{color:"#194866"}},tg(lang,gk).label),React.createElement("br"),React.createElement("span",{style:{fontSize:12,color:"#707070"}},tg(lang,gk).q)))
        ))
      )
    ),
    step===1&&React.createElement("div",null,
      React.createElement("h3",{style:{textAlign:"center",marginBottom:20,color:"#194866"}},t(lang,"wizard_q2")),
      React.createElement("p",{style:{textAlign:"center",fontSize:12,color:"#707070",marginTop:-12,marginBottom:18}},t(lang,"setup_help")),
      React.createElement("div",{style:{display:"grid",gap:10}},
        ["einfach","mittel","komplex"].map(c=>optBtn(setup===c,()=>{setSetup(c);setStep(2)},
          React.createElement("div",{style:{display:"flex",alignItems:"center",gap:10}},
            React.createElement(IconMonitorCog,{size:18,color:effortColor(c)}),
            React.createElement("span",{style:{fontSize:11,letterSpacing:1.5,color:effortColor(c)}},effortDots(c)),
            React.createElement("strong",{style:{color:"#194866"}},setupLabel(c,lang))
          )
        )),
        optBtn(false,()=>{setSetup(null);setStep(2)},React.createElement("strong",{style:{color:"#353535"}},t(lang,"wizard_skip")+" – "+t(lang,"wizard_skip_desc")))
      ),
      React.createElement("div",{style:{display:"flex",justifyContent:"flex-end",marginTop:20}},
        React.createElement("button",{onClick:goBack,style:{padding:"8px 16px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",color:"#353535",cursor:"pointer",fontSize:13}},"\u2190 "+t(lang,"wizard_back"))
      )
    ),
    step===2&&React.createElement("div",null,
      React.createElement("h3",{style:{textAlign:"center",marginBottom:20,color:"#194866"}},t(lang,"wizard_q3")),
      React.createElement("p",{style:{textAlign:"center",fontSize:12,color:"#707070",marginTop:-12,marginBottom:18}},t(lang,"support_help")),
      React.createElement("div",{style:{display:"grid",gap:10}},
        ["gering","mittel","hoch"].map(c=>optBtn(support===c,()=>{setSupport(c);setStep(3)},
          React.createElement("div",{style:{display:"flex",alignItems:"center",gap:10}},
            React.createElement(IconUsers,{size:18,color:effortColor(c)}),
            React.createElement("span",{style:{fontSize:11,letterSpacing:1.5,color:effortColor(c)}},effortDots(c)),
            React.createElement("strong",{style:{color:"#194866"}},supportLabel(c,lang))
          )
        )),
        optBtn(false,()=>{setSupport(null);setStep(3)},React.createElement("strong",{style:{color:"#353535"}},t(lang,"wizard_skip")+" – "+t(lang,"wizard_skip_desc")))
      ),
      React.createElement("div",{style:{display:"flex",justifyContent:"flex-end",marginTop:20}},
        React.createElement("button",{onClick:goBack,style:{padding:"8px 16px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",color:"#353535",cursor:"pointer",fontSize:13}},"\u2190 "+t(lang,"wizard_back"))
      )
    ),
    step===3&&React.createElement("div",null,
      React.createElement("h3",{style:{textAlign:"center",marginBottom:20,color:"#194866"}},t(lang,"wizard_q4")),
      React.createElement("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:6}},
        I18N[lang].bloom_levels.map((name,i)=>{
          const lvl=i+1, w=140+(5-i)*30;
          const ciPalette = ["#194866","#267372","#669933","#A5C387","#FCBC82","#F98012"];
          const ciColor = ciPalette[i];
          const isActive = bloomMin===lvl;
          return React.createElement("button",{key:i,onClick:()=>{setBloomMin(lvl);setStep(4)},
            title:I18N[lang].bloom_descs[i],
            style:{width:w,padding:"10px 0",borderRadius:6,border:isActive?"2px solid "+ciColor:"2px solid #E9E9E9",background:isActive?ciColor:ciColor+"22",color:isActive?"white":"#194866",cursor:"pointer",fontSize:13,fontWeight:600,transition:"all .15s"}
          },lvl+". "+name);
        }),
        React.createElement("button",{onClick:()=>{setBloomMin(0);setStep(4)},style:{marginTop:8,padding:"8px 20px",borderRadius:6,border:"1px solid #E9E9E9",background:"white",color:"#353535",cursor:"pointer",fontSize:13}},t(lang,"wizard_skip"))
      ),
      React.createElement("div",{style:{display:"flex",justifyContent:"flex-end",marginTop:20}},
        React.createElement("button",{onClick:goBack,style:{padding:"8px 16px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",color:"#353535",cursor:"pointer",fontSize:13}},"\u2190 "+t(lang,"wizard_back"))
      )
    ),
    step===4&&React.createElement("div",null,
      React.createElement("h3",{style:{textAlign:"center",marginBottom:4,color:"#194866"}},results.length+" "+t(lang,"wizard_results")),
      React.createElement("p",{style:{textAlign:"center",color:"#707070",fontSize:13,marginBottom:20}},
        (goal?tg(lang,goal).label:"")+(setup?" \u00B7 "+t(lang,"setup")+": "+setupLabel(setup,lang):"")+(support?" \u00B7 "+t(lang,"support")+": "+supportLabel(support,lang):"")+(bloomMin>0?" \u00B7 ab Bloom "+bloomMin:"")
      ),
      results.length===0 ? React.createElement("div",{role:"status","aria-live":"polite",style:{padding:24,background:"#FFECDB",border:"2px dashed #f98012",borderRadius:12,textAlign:"center"}},
        React.createElement("p",{style:{margin:0,color:"#353535",fontSize:14}},t(lang,"empty_text"))
      ) :
      React.createElement("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:16}},
        results.map(t2=>React.createElement(ToolCard,{key:t2.id,tool:t2,onSelect:onSelect,lang:lang}))
      ),
      React.createElement("div",{style:{display:"flex",gap:8,justifyContent:"flex-end",marginTop:20}},
        React.createElement("button",{onClick:()=>{setStep(0);setGoal(null);setSetup(null);setSupport(null);setBloomMin(0)},
          style:{padding:"8px 16px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",color:"#353535",cursor:"pointer",fontSize:13}},"\u21A9 "+t(lang,"wizard_restart")),
        React.createElement("button",{onClick:goBack,style:{padding:"8px 16px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",color:"#353535",cursor:"pointer",fontSize:13}},"\u2190 "+t(lang,"wizard_back"))
      )
    )
  );
}

// ----- Footer logos & icons -----
const ELEDIA_LOGO_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJIAAABJCAYAAADWgn9iAAABRmlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGB6kpOcW8wkwMCQm1dSFOTupBARGaXAfoGBg4GbQZjBmME6Mbm4wDEgwIcBCPLy81IZMMC3awyMIPqyLsgsTHm8gCu5oKgESP8BYqOU1OJkBgZGAyCWLy8pAIozBQDFRZKywewUELsoJMgZyK4AsvnSIewOEDsJwp4BYhcBPQFkrwCpT4ew94DNgbAvgNglqRUgexmc8wsqizLTM0oUjAwMDBQcU/KTUhWCK4tLUnOLFTzzkvOLCvKLEktSQZZD3AcGghCFoBDTMLS0tNCEeUiQwZEhhSGfIYkhlUGBIYjBncEJSGswGDJYAqEFgybD8AWgtANhfQ4EpwlGsTMIMQRILi0qgzIZmYwJ8xFmzJFgYPBfysDA8gchZtLLwLBAh4GBfypCTM2QgUFAn4Fh3xwA7dtV9/MA0fIAAAjXSURBVHja7Zx7jBbVFcB/CxVkea3FKmIpDM0Q5FGk6IJZqrW1oihqrW2lijUxaF9ioq2GbXGY1IrP1kZjkZpWtChoodLER7uhD61VKhBlF5VO6ZRHCV0jBYRIeW3/mLPJcPfO49tv9tt19/ySL9mZuTNzZ+6555x7zpkFRVEURVEURVEURVEURVEURVEURVEURVGUkgg9d2DouR/RN9G9qKqgAM0E6oGpsut1YL7jB7/TYVBByitE1wE/t9yvBbjC8YOVOhQqSFlCVANsAQYlNNkHnOT4wQc6HB9eelXgHhelCBHAAOACHQoVpCyG5GgzWIeiZM4EJvUkQdqYo81WlYuSeBz4G7Ae+FlX6FAlluF/BkLASTjeCPypTD/sPOA8Y/d8xw8OVfh99gX8HO32A7uB/wIbgCbgaM57OMDs2PYc4Hbg3e4kSKcBc4ERwB7gGccPng0992LgL8AJRvttwCzHD46Wed9pwG3GPh+otCD1sfQjD7uBF4E7ZWKlcY6x3RuoA57tLqbtOjFj3wAuBK4EVgBLHT/YDIwGfgQ0iJaaB5zp+MFGlBp5XxuAJUB1StvVxvZh4KXuYtrOAB5JCCdcCTQ6fnAn8AOVmUyuEc1+CbDTcnwbsAi4gSgO91NgV3cRpK+Lik3iZmChPHhPYxPwS8OPOgU4Vfyd8QkrsmXAuQnv7JvAg8ARuX63cbYn5ggB9CcKPvY0/gHcnaHNbwZmWXyha8TU2XirKz1kUT5Slmo9ILNHacta4GvAfZZj95EvDtdtNNJy4NKU488BH2Qs4auIouDTgFrRctuAdeKgL3f8oCKmUdI6V0g/aoHh4givA55w/ODNDrhtvTz71Ni+E4G7ZInfysnAdywCt8dyzWrgK8AXgY+LOa2W9xoCjwKrinA5isq19QaeB863HNspL2dLysANAX4hDmYSq4A5jh+8azl/AeCZL7E9+bvQc88CnpIQho1DwPeB+y1hi4HAXsskujjn7UcAmw1/8z3gY7HBHm8JEQwHthv7LpDnqMm45/PATPLHsTrUtB2RztwLNMf2rwA+myFEk4E3MoQI0Xivhp7brwM10U3AyylCBHAccE+CKSqXLcDbFv9yWInXqQV+k0OIAGYA13elONJB4FZRn8OAfmIeNqUMXB/gV6J2W2kCvi2CU2+o7E8C3+sgIToD+ImhDZYBVwFfNVZeAHNDz53QAV1Zb9l3ejtW0cfHtptFK9YAl4lpM9t3ro8Ueu4gGfgpopleAx52/OBAjtNvAsYYK5HJjh8clO3fhp4biopuZV7ouYscP2guUIh6AQ8Zpn6h4wf1se2nQ88dDFweM+f3UnzlwnpZrZmr4udKuMYUY3th7PxVwGeAW2LH3U7VSDIjm4hC+5fKS74H2BB67uiMc4cQ5YiOcRpjQtTK7w37fTwwueDBm2W8/AOinWz+RJw6WSQUyXbLvpNLvMYfiQKVs4CR8necVyzms1+naKTQc/sCS8XRMxkFPBF6bp3jB4dT4icDYtvvA40J5uJtYFxseyzwQoGDd66x3QAMDT13aMYgD5DnL7J6wTYBG0u8Rpb531e0UinHtE0DJmQ4fJOIarNtTLCseF7Pee/TCtYCZl9myi9vX4oUpLGWfW8UcN0TgeniXE/vSnGkiTnbJAnH+DLuXV2wfzSuK/RFfLTTLSvijWX07VqispMpdGBpdTmC9O8y25hmY0MJDmWRAcH+8ouzHPhnzvP/XmBfrrZMsHfICOYmCGQ9Uerlo5bjuxL2d4ogvSwPmOSk7QXWZAxAXMXuM1ZJFcHxg/dDz91pCPZrjh88UOGuDLU4xZCep0tb/t9h8TN/Lb+hQKGfgfUqYwB2SNwoibmOH6Tl4Myk42SJK3UGZl+mVvj+dUSFbWbh3x+I4mylMEhCGceMhfhet4vmLzzV1KvM2fwQ8CWiDHcrm4CLHD9YknF6k7HdN221EXpun9Bz52SFFdqJ2ZcZoefWpvTllNBzbytj6V8lWuFs4Emi6lHT5zxIVC5S6qCPs5jqv3a0r1d2QFI+blwpcaEjjh/sznnqK0SVkvHS0TvkOg8Dmx0/aAk9t784i/OATxCVVVyb4/qLQ889nNFmk+MHdwEPECVG+8VWkKtDz70BeNHxg10iNCPE77heBL8ph19XZ8Rtqoki9AMzzvPb6X/1teybQZRwrhKB/WFCOKbdIZVCvXiJAV0ty+ldMtteSMrah547Vhxnm0DvkNl4qmUV4zp+EMaus4C2Sds8vOT4wTlyjXlEgVWTFtG4J9H2s6k1wFmx57MlbUulBfguUUC0JWG1m5a0rSH6qMBko8S90vKInxdzWlnTZgjFbKLw/q1ENdtXyWxdHnpu7wRt9hZwo6hxk2EWIYIoNdERH1Tej72AvooohTA4IeYzssA+vAp8DvhxGX7MbqKyZ5vJaxWi/cC/LG3e6RQfydAsSxI0y5fFLCWZxkUSO1mT4wU9Bkxy/KDwb7kkNXM5UZHZe1kmEVgAOHHNWCL7xNwsBeaLANVR5qdZwi3AypTV9qeIovnNRqhmR6eattBzF3Ns8ZXJVmBkWmGaaK2JYhYniD/0H3nAN4HVljxc67nDsadqstjr+EGT5XqDgU/H+lIt/dhOlMdqSniW3rRNmNpM19aY6S6VatoGLdcB/7O0PZsoQTtKhH+t+KWt1aoniKkcIxP1mc4WpAbafqBoMiQjHKB8iCnKR9qfYxbu0detgpRF1v83WuH4gRb/d2OKKv5/iuhDyAstx5rFmST0XFfiFX2ABomOK92AwuJIoecOEIH5lsQrDhEVpc0VJ3UxUeVfVczcPQLcmFKzpPQ0QYoJ1HFEmeUDjh/skX2PkVwX/KjjB3N0KFSQsgRrFNEnNkkcBUbLP5pQerizncb0HH2o1aFQQcriYI421ToUKkhZrM3RpkGHQgUpFflOfkVKk8cdP9D/IamClIvZCcK0jAI+F1Z6wKrNWMGNAb5AVOu9xvGDRh0CRVEURVEURVEURVEURVEURVEURVEURVGUrsD/AWP2TqYzUA7aAAAAAElFTkSuQmCC";
const ELEDIA_FAVICON_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAbDklEQVR42u2de3RdV33nP7+9z+NeybEtOZk4NikUAmHsJjwSSFoeSdpOC6y2M5mORGfKlMcwPPpKeDUlTnx1HUygdCBdZdYqmbYZypA1SJSkM7SUziwSm+EVoCRAzAohKc0D52FLlm1J9zz2/s0f51zp2rFkWfdKupbvXusuydY59zx+3/177e/vt6E3eqM3eqM3emNtDwXRGkaHsDqKHR3CqiK9N7PWBV/DaI1g3r8rcleNQDkzwRCsaeGPYmUYB3gFobbh2RlmixgTKxwNA/uIyFNPAjmADmFlDHcmAWBNol4VEUEBZmobnhMFwVud019T4fmRpYIRfK44z6Sx/KP3Ojp51Hz6nI8cPHKmgUDWqvBrNcwOs/EPjZHrbGTWk0NeCF0pwCGBQWwgYMFl+mCScX1/ffyzWsNIHd8DwGno6Ano+HUDG9b3ye22Kq/LZxSn5ICh+Lu0HK+ABzQOJMBCnvrdYW3iBh3FMoyX4pgeAE4H4TOEYRs2lYEvRn3mymRKMyAQOflzKngBH/VL0DjiP1TdNfH+Fh9izQ6zZp5kCCNjuMQP3BL1F8IXIVyM8MuZYBRsOqVZpc/8YTIy8HoZxukQtqcBThNvf/rGja+qVOzePNdcdWkRjoIPLOKdPjXTyLevv/nIOCPIWvUJ1oYGuL+w08ZITQw4v3RgC5jc4cI+c25cCX+7jCZMTwN0caJH6vgjtYGfia3cp4Xw23ouBR8GSJ7pw9H4pu386Y/S8mVpTwN06TOE8JowFqO077QJmCyDIDDPmx4cf4mAjg2tTS1w+j/U9mJWCvLyjs5PwZkQDP5SgKFtazNpdvoDYLhwzlT02aWbJh0EAUbMT/fCwC6O/QVUQVDpLzWAdPICKroB4O4eALrSg9WWn/lyXECUBODKHgC6Nwoof3sKA2hHPQFVlf09E3AaPIOIfA8zu9DT/vAYHALy3VZnsweALo0CjOg/FAJr/5kUNAgwaaqTcZR8rdXZ7AGgC6MABdl/qH9vmuqPwwBR2haWs5Gg8EXZcfRpHcKu1VVBcxrcX1B+bPlp/tvMOoA17E997LEZhVtMJIJvCwBqBPIcjPIxAIbWrg8gXQ5Mv5jjtACBwLOjRI58I47k4iTVXJZAeVMli/slTI74v6jcNPHWtc4Q6kYAWObSuS8AXg1cDGwp/+9x4F5gL/BQ8xytocWawMaLK4H5ikHWZe7UQKBKFlclzBL9bliRV/Ktg9OM4kXWLilEuvBeFHg5cB3wK0A0z/EzwP8CPlQCQu66AnvVHvKjNw78ciWWz1oj6xqFJjCygLkr1w80rkqQp35flvPavvrEI2cCNUy66D6kVPkjwA7mZq4rQdEKECk1BUAK7AQ+DJi7rsBctYf8aG3DSyuB/Usby4tIIcnVn8ikCARRVBDFXO4/Oz2RvXP9R48eOFN4gdIl92BKQd8GvIk5rp5Z4B61PMeWx3wCeAdg76ohV9XJ9Y1UsgsGfl+8vCUI5MJZSLXAKWuoGuEravhoeMP4Hc3kUo8UuvI2/xbgGiArZ/9i762ZBg6BDwA3tvoEAN+vEW0Pzr48U3eZqPy0qlbFcFjUPGDFf1l2TnyvKXhG0LVs87vR4QN4XSnItPx5qh9fAkeZS9tbBdHRk3P6FntcTwMsz7Wj0om7sBTkUgXRNAffBi5rAUYrY7i45naU+2ev788Udd9to2mRh1vUuLb5aX7H647TML1xkoTLaoymnf0PLQLsxHdq+Z29cRqYnnXA/haPvl0N0PyOh1vyB70S8C7WPBd1SPCtzqACCfDcLtByPRNwEg0wWN6D7+D3ajn7z+lpgO72AZbr+nqck9kbi/DEV2vMLMMsNSUIjh4HiOX2aKVYkQT2IWwrr1tHu5lLIKs48z2wFfgh0Mex+f52Zr8Ah4DnAwdazELnBT6XW1gwl1DyFk035hxWSwP4UjD7gQcplnvbSQK1fq8BflAKv5P+xazg765hpU5OC09g/3vO7d+8Lt2UohvF2Fh9nkVwCKIDUn/6KK1JqVFMt5SdyyqDLwd2A9eXv7cLyOZ37AA+2HKNzgi/pV+AgmQ3DbxCPL+k8ApVLiycWqkGBpyCog2BcZAfiujeQM3npXbwm1B0MumGquPVBEBzdr4A+D5zq3qy9Mk5GwJeCDzaKQ3QKqwDtcH164U3i+WNgchLCMsr5Erui25UCiogRiAwgC3a0PgUVHWvGndLeMPkHceD6kwDAMytBP4Z8PY2tUBGsSL4x8D7OJZZtHTht1DCkl0b32AwI0EszyOHJFVFcJStZ5qt5pptaLRZpSBlfkIJ4rjJPdAv5Lm5tlI/8EOtEUh9GQpbTgMANMPAjcA/As9mblFnKar/AeBlwBQdSC83Z+fh9687p68a/VcbyRAZJE5zTsIyWkBNORTiqtg804k0l7f01w/euVogWO08QFM9jwP/DpgshZ8vQfjN7zjSifBPawQyjDt6w8YXVfuir9pYhhoz6hKnXiCQJb47ASuCbcyoE2WgGnHHTG3grVInX6ih5VrVAMebgsuBz5bhoedYVpAcZ+t9i9/wMMWq4rc7ofqbM3/q+sGXR1W+EFgZbDQ0N6azAlLwxkBoxSQpV1fqB+9caZ+gW/LkTbX/deBngc8wVxNgjovlpeVvAnyqPKczwq8VIVqjNrgtrvIFKzLYSNQtJHwtKpSdQn7cx+kCmkjAeA+5V28D/6nGDZsulGHcXL3jmaMBjo8MAF4B/BZwFXA+UGnJHv4YuAv4K+AbJzi3LW8fNqzPjfl6EJoLG4k6I/P7JKo4I9gwkmd6Lg7SVFFwsoBf4xVXqYhNGvqVmPFXsw9hbGV6FHYVABRkpIbsqyNjczM5BJ4FnF1qgaeBx1pmuqFDfIKm+m3sHPxM3C/Djan51X55MR9XxKQN9QpfF9Fvq5cnEETQzYq8VODnokhIEnWyEJAgj6sSNKb9f67WJ/58pUyBrLbAGS1LvI572LddQrj9HMy7vkjidV6/QTuV6Wu+8GRk4PVRxfzPpDF/UUlTrceRSJ7p7d77D8f1Q9890bHprrMvAffhMDS/kMyoF3Ni9a7ggwBxqT4+PhW9cPN/eXK6FJCuSQCcqORKP3JuPz43bDzYkLeTNf//E28jvP0BdM+eWWF3ikF0jOqfaAyc1V/hfhvKljxHT+Tpa1E76AMrNnf6e1Ft/OMAtRpm5JnHe6njdQibbh/831Esr00a82sCVVxcFTszo2/sq4//1UqEhsFqCv9bbyN80bM2vTbA/1qOvDidSjcDgWkMHk7rPGREv5Q5/9fV+uTDsw7acqROR4rcfmOEd0RVszWZmX/2i+LDithkWq+v7Br/uL6NkPNwUsfXT6CNmkI8ckHwZpH8fmsZdA6dt4OpR63ofyr9m2VPE6+oBih6+YAI2qhvuDowdsQGcjFSWnRfJs6kdJkM5KkeNch/PzqVjmz40JGDnS7WbGbvDtU2bOgT8wNr5VznTtwcUhUXx2KTht9b2TVxhdYIqONOpqabIJjZOfCxSr+5dj6AKagFVMhcmm+r7j780HIXqZgVFX6taOWe1AduiaPgc9bIxUlDXdLQPMnUpw6f5miSq08a6pIZzdWzzsT8bn9/eM9UbfDlMobrKIe/VtT+94n99ahiNuf5bO7hmbNFkNypGuH9AGxf5Fr/dlQVsaJ3+KwI/+aZjeLAhbFEJgyuXAkZmRUT/miB5MbIwCejPnNNmhRCF8G2ZNaMCCLFTysQeEWTKc2skefGofzDVG3w8g7Hyr6c3W/Ezy9MBRdFYvJc74nqE19t5gsWdYXhosI4rOj38swfDAxGT9LLSFVfBcvfnWxlfIBy/TvZOXBT1G9+K53SFIgWY38EBCFMMs3jUDaEljumapsuYeTgfqU99dhUrzO19RcYo5flKbJAqKZYEPic1jBswepiG1KNlAtFjclJlcFHjZVNeJ2PAGPK5aWLFIT68oaCy64BdKgIr9L64GUmkh3ZtOZaxPan6qwEjUTzMJbNAf7jHarfMwBW7C+EsYncwmsQ1iWqYv3/kTpe3k4mUtQRnvRTL6IBqeMFfrJgNzNF1CuCPutgbfAsoTAfp68GKLlx3ukH48hII1MxsrQHMoYgnVEXRebqtL7xCqkd2tNWwmRfeW/Iz58kTNTQIpljEhtMa+3cfzGFN/2YxWuf0FmyRpaqzizoews4D4ps7M/tOcDhIju5PPmAZQVAU8UmtbNfagP/82mifqG06iL9CcWi5OadwB7Glu6XyBhOawQN9MXkwoLOX0FiOwvnv5mQElAwTxY9chCJvCp9aaLMZ2oExCsEQuSqRZdS9p2+GqDMz7t/ayNDPqNe2jc71qcqqvwrvXnDgLx/cqLZMvYUvX+hjs4EA+eZnPOd05OGxQaMtXLWUqeiUK4O6UnB6a0V49VVWAEBLdsYmSNCvrJU0m0jWUAyjw8DGWw0eFHTyVyC+heAIOf8KDTV3Bc0rpMIhsyjuUNzf+qfzKF6Kujxy5+nWTYAKEi9jtcakQjnd7iTt5cAwFwA0FLqvfhRtn7zRs4TOxcOLgaAZah66h/pviql5dMAJdIPsaEPZKMv2JIdbeUuajYt+fwSNEb17EKqZ2ZXkJVaC1iel9sBoXlv1jeX3GRxD6Ir9L709AZA+TY3bpmcSvcPHDLGLJT8OPWvVhDRpzvwroPF3pIp+s0tuxr3isUA2fJfK1hG+avWMPJ2smSEf8LyPPLOoFoVqzmI6A9b4/ml3ai4RUxHF0Vis8TfrJjPgQYYWdYMXeZVQoJ9AIwt32LQioSBqrIHwy92SK350GKy3D91ROV77b4gVaYWcVcqFjzyk2r94LdW2k4vJylkuQHgS1N9Z54wYgSjbT6KgjeRGG3I359dP3i43eVhI34CNYWDKic7VrfqEPbBzQTPf2L5iBpjzSBlBXiBywoAKcJAI/WJ7ye1wb+LqvKrC1GtFqlSJM9Qp/xpWze3r7nZpN+PN5xU/AoisrVcjmat7Cm8/MvB+8qVMKs7XKaZEUSXuK2L9+Rhn9g885/qrx/8Vluzv1yjcD58PM00N4JZwMMXPHjVC4E1tXnEsgNAxnCMYuKdE9/LM90R9okVIT/VcMpDXqlIkM3oP1XEvUtrmNkmDEsZ9ZLYub7yKLA/sAuGq8ZlisD2qdqmLdC6V1HH4j5ZzlW/1dMAFOpSR7GVXRMfSY7qJ6J+CSmWOU/ugSuqSlaJJMidHkgzf7XUD483TUzbUcp7Hpvxyvel2BNE58s55UoeVU2/VX19aZc79u60hhFWp0XtylUGDeNHh7CV+vg70mlfDwMxcSxWi4rqZhWNn/1oUWkTWCTuN2Hu9D6X8Op1Hzh0nw5hO8STK/kAuqesP1pIAMalqsbquw/UBtdD4d+0Gc6KjhbP8vjbzuvTD561SVuqjNcUAAR0eKx4aXFtYiRJ5ErvdE8ciImrEsSx2DgQEwdi4lBMXBUbVyVAeCpP3E0HDoWvqHxg/AcdJYWWjqAa/fs8Ub9Q9Y6AyXN8GJtnrTd6SwlAsxQQKIjWCERQGcaltcHLNz8n+XqSBB8TUIbWeGlYqxB199mvynP/q165tKimIUTkkIEfBoYvMR18Xm5+6slZVdlhhmyzJiDRgW/GFfOSJF0YCKq4uCI2TX09rk2MlPcVMIJbSIW3NJEyTa6/1tYP5kFwvcI1YSBBlvqpPNXt1d2HHqG2Mt1DVrUw5Pg4V4ewbMNKnfQ4GxkBvmzyrJ3svDVL2R7Z9DuVKh9Ppk9awoWAi2KxWar/LfS8V+rjh1vuX+4uj72yedL2YqbPfsd1AxuyqrwJ4T1hRc5PZxT1pHG/RI0p/aPqrvHrVqpfwKovTzZfGi0dtMrZEpaOXnrC80pqeLvxuJYJoAPv27Rufb/fZ61szd2Jq4KeoQmqYvNUf6Re/zhUN9Z0TucDGuHgS73naq/8+yCWZ5NBI1cnUlwrMOC9HphW98IN9cMTzRqKNQ2A49Xk2BBmaNvcZg9aG1yf4p5rTLApz8GE7sAhFz50btF5qyPNlpqzLR3Z9DthlY8nU5rLInoBqOLiUCwBZIk+IbDXef22iHkc9Q6RWGGLQbcBL7NGLjSxUG5h4xRM6+KSV1ylT2zW0HdFtfFbVkILdBcAWnyD7KaB1xiVtzjVVwpyXhAWt5plCqKPCfJlVD8Z1ia+ePy5SwEeNYT92HTLwFejyFx6smrelnM9ikYBVkKZ2/mo+XabdM4c0lzRgnls5qk79GGA5Jk+HA1u2s41P0qbDvSaB8BsafYNmy40kf5JGMgvY0AzJXPliy698cgCoRRsQ6efzxr5tdXdhx9qhyE8S2C9YeAiE8s9KJHz81fxnChfQUHi0mOIL3MqfFE9hZqmJW3434hHJj6z3FpAukn4M7WB1wSB3B6EMpA01JWvzhxHpVIt0ohemG229HSeutdXb5q8qy0QlOdO79z4m9Wq/R9pqs77Y9X0cg8PeRQieaYPPDnZf+n5H32sUbYdWxYtsOotYpolVtP1jVeEofyNQQbKBSMrgj0Bj05EEFP8zSYNza3IOUFk/za9cdPL2ikbK88N+nYd+nRjxv1uFIm1ppiVK+D/eK+4SiCBsWKB6YH1E2ctX0VAF2iAWUFF/edkLrrXGrM5yxZne4+ZNYqrRGKzXB8JI/diGpOT7aSKm2o32Tn4ZhvxZ9ZIlDQ058SAbFfwRdu40pnMU33Iox+KXjhxmwzjlkR5P200wL7Ce0+S6I/C2GzOUs1lCYUjRrCNRPOwKj+VJvYDUse3U0zRbNkW7xq/LU30Suf0u/E6CUKLlGlrv9R5WZYF+NIZJI7ExlWxmdeHs8S/Z9Lx0njnxJ+vhPBXNxFUOl26a2B7jtxXlMMtHZAKagVVIXeJ3Vbd/XTbtfVNn0Df9axqNnD0WsFcE8RybrP5k9fZ7J+U7p4c93YLcqfO/i5WsEFY5BrLTSv3Os9th9T+9WxoO4pleGWaRK3mfgEG8A0nb670iS2bJpg2kCyuSNNG3rs3AHXa7BzW9Cek/tgMcPORWv9fxDPxb4qR3zDCJVFF7Fxzi8KF9+VKjkjprTQbxZfHJalvkOp9auQL6t3fBPXJe49Jbg3jV5JssnoaoIy9EwbvjSO5KMk6UjbmokhMmvp74pGJy1WLhhQdudfjWrzr7sFtzusrVOUS5/mXgp4LnKUqVQQVtIFyBJGDIjyKZ583cp/6/L5qffLHx2QixzArNeO7AgBN1Ty9Y+B8G/KAFanmevLSrMWYgdAgmdMjMdEFUn/yqU6BoCXraE8Ul+soln8+t8LRRngI2LiuknH0yeSExxbgt3TBBhKrYwKadXmBbA0s1TRfoGnSKZqB3IM1clYqja3AU50srS6BlLdEMOZu4EqaavvJqbmjJ4+d4fcjzcUsqeNZpe7g3QGAIWAMBOkTC7jOFIw04+nAismc6WsFW8dVZ51jtqOfJXHosbq1BE3XEkhXddMoxeVFX6zOysZ7BUy6wrZUuye32u15gPvLzhzWPJ1m6gwLMnJPNRSUzGvifF6UjW3rbQXffQAoGbkHXfzPqvpEYDtlpdHACgKP3L9/8vHWa/VGFwFAQHUIu7W+f1qEr0koza1X2h2eAFX48qW3kmmNoJv37DtzNUDTEQSM6idRRLQzUQAesWJuB2B7T/hdmwhqDaUSGfhmHJkXL5aEMU+M7uKK2GRGvxrXx1/ZyhI6JhRrVhIPwey/x1YnCXPGRwFsR2SYfLqu16pytzGoX0JCSBU1Fs2dqrG8WwTVIUxT8FKYl2NNzNgzEzlrpd7vtAGADON0CCu1Q3umdw6OVM+SkXRKM1WCxSaGFLwIPqxIkBz1f1DZNfGNkmjarLRxevOGgTyzV3nl5/D6HET6RJgAHhDj9gb55P+T4bkET7dt77pmTcBsAqXZSrY2cEvUb67JZxSn5BRbLsp8sx7BWSEIKkI67XfH9YkbdBTL/YjUySdqGzaut+Z9XuRNQSBbjtlbpMnXyyH3fp8qfxLtnLj1TANBd1DCSjbw8BiuURv8/SBktw1lnUuU3OGeUbKlSGixJhZcqpNZrn9QrU/c2qSYS5185sYNV4WxvdVGcoE2lLT5PaWzKTLbrs/EgRhCcAn/N038W/p2Tzx6poCgu1jB5Utv1M5+gbX+vcCvB6EMPnMfDnC5HlD4XJ67D1frkw/rEJahwqw0ahv+TRDaUSsSNpKCZLKQSSkJHj6uSJBn+mOXZL9U+cCRB88EEHRd4vKYDZpr52zOjftZ7/VFimwRg0f1SSNybxAEX5UdZcnYUFkkMoabqg1eHgXsRQmcw59KVOE9eaUqQZ7qg0HkLmuXWtYDQDvhYREhuJOBhftRRlBGENadW82m0u+EoXl+ki4tpFQli/slTKb8pyv1iTd0eoeSHgBOTRiz8fvd5f9d2UzwDBWbMJSACYo9fwaui/vMh5Kji6vsWeCt5GEoQZ7JlVHtwJ61HCIGXY3ORSylNjdV0No561LNf88nqpi26/YRg6q6dwN7motXa3GY0/4JRovuGonPropiszXP6UhHcpeogPziVG3TFqnjV6N9Sw8Aixllz18J5Cosqh2gf5XMIhfF0mfRywHuHsH2ANCdo8j3Oy4qK/M6M1PnSOo/M+t79ADQhX5CM0QT2USxq0dnVbVw3lrOA5jesyzsYSIawvJv39YDQDuhYvHLzHG0zI4Eyaoy2TMB3TzGimcwRh4un6ajIZtVeahnAk6DKMCp/1pHrb9iXaJg82+0Ops9AHRpFEDuv5A1NDNg22UYK/g4EpzXfaGbvE9ZmZZtPQAsMQrQGqa6+/BDqvq3YUVEtU1heTwBIsJtUicvy7h6JqBrR7P6x/hdLldvzNL39lHwYSQ2ndFHQi+3lvWArgeAbtYC5Zby8c7J77hMb46KgrNsCRGFGsEbi6jqO6U+fphhzFreUWzt5AGG8TqEjUYmbsym9M6430QKmS7SedOy2UNYlWCmoTsq9Ym/09G1vRS8pgAgoIwWwg51/PXZtL89rkoYWTGz3cgVbZqG8mfRlVxxcSQ2CMQkU/66vvr4B88UlvCaW+Fq7auT1jf9tgjXBzFbceBzLXfmLg4KDRAUtFOf6XfSXN5brR/80longaxpADRB0Oy2fai2frDPBv8R+Nd4LlbYKIJVSEV4wojeg8iofWT8TrmV7EyrD5C1/HDHC1Nr6wcTgs2CiyKioz8h+MnW+v7p2b+fQTP/jBmqxeYM8xE6dAiro1hd45PhjNQAJwJD2TKmGB3cd6A3eqM3eqM3euM0G/8fITmd0iAaLugAAAAASUVORK5CYII=";
const CC_BYNCSA_DATA = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiID8+PCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEgQmFzaWMvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEtYmFzaWMuZHRkIj4NCjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgd2lkdGg9IjEyMCIgaGVpZ2h0PSI0MiIgdmlld0JveD0iMCAwIDEyMCA0MiIgYmFzZVByb2ZpbGU9ImJhc2ljIiB2ZXJzaW9uPSIxLjEiPg0KPGcgaWQ9InN1cmZhY2UxIj4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoNjYuNjY2NjY3JSw2OS44MDM5MjIlLDY3LjA1ODgyNCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSAzLjQxMDE1NiAwLjQ1MzEyNSBMIDExNi43NjE3MTkgMC42NTIzNDQgQyAxMTguMzQ3NjU2IDAuNjUyMzQ0IDExOS43NjE3MTkgMC40MTc5NjkgMTE5Ljc2MTcxOSAzLjgxNjQwNiBMIDExOS42MjEwOTQgNDEuMTQ0NTMxIEwgMC41NDY4NzUgNDEuMTQ0NTMxIEwgMC41NDY4NzUgMy42NzU3ODEgQyAwLjU0Njg3NSAyIDAuNzEwOTM4IDAuNDUzMTI1IDMuNDEwMTU2IDAuNDUzMTI1IFogIi8+DQo8cGF0aCBzdHlsZT0iIHN0cm9rZTpub25lO2ZpbGwtcnVsZTpub256ZXJvO2ZpbGw6cmdiKDAlLDAlLDAlKTtmaWxsLW9wYWNpdHk6MTsiIGQ9Ik0gMTE3Ljc1MzkwNiAwIEwgMi4yNDYwOTQgMCBDIDEuMDA3ODEzIDAgMCAxLjAwNzgxMyAwIDIuMjQ2MDk0IEwgMCA0MS40OTIxODggQyAwIDQxLjc3MzQzOCAwLjIyNjU2MyA0MiAwLjUwNzgxMyA0MiBMIDExOS40OTIxODggNDIgQyAxMTkuNzczNDM4IDQyIDEyMCA0MS43NzM0MzggMTIwIDQxLjQ5MjE4OCBMIDEyMCAyLjI0NjA5NCBDIDEyMCAxLjAwNzgxMyAxMTguOTkyMTg4IDAgMTE3Ljc1MzkwNiAwIFogTSAyLjI0NjA5NCAxLjAxNTYyNSBMIDExNy43NTM5MDYgMS4wMTU2MjUgQyAxMTguNDMzNTk0IDEuMDE1NjI1IDExOC45ODQzNzUgMS41NjY0MDYgMTE4Ljk4NDM3NSAyLjI0NjA5NCBDIDExOC45ODQzNzUgMi4yNDYwOTQgMTE4Ljk4NDM3NSAxOC4wNDI5NjkgMTE4Ljk4NDM3NSAyOS40Njg3NSBMIDM2LjQyOTY4OCAyOS40Njg3NSBDIDMzLjQwMjM0NCAzNC45Mzc1IDI3LjU3MDMxMyAzOC42NTIzNDQgMjAuODgyODEzIDM4LjY1MjM0NCBDIDE0LjE4NzUgMzguNjUyMzQ0IDguMzU5Mzc1IDM0Ljk0MTQwNiA1LjMzNTkzOCAyOS40Njg3NSBMIDEuMDE1NjI1IDI5LjQ2ODc1IEMgMS4wMTU2MjUgMTguMDQyOTY5IDEuMDE1NjI1IDIuMjQ2MDk0IDEuMDE1NjI1IDIuMjQ2MDk0IEMgMS4wMTU2MjUgMS41NjY0MDYgMS41NjY0MDYgMS4wMTU2MjUgMi4yNDYwOTQgMS4wMTU2MjUgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMTAwJSwxMDAlLDEwMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSAzNC41MjM0MzggMTkuNTUwNzgxIEMgMzQuNTI3MzQ0IDI3LjA4MjAzMSAyOC40MjU3ODEgMzMuMTg3NSAyMC44OTQ1MzEgMzMuMTkxNDA2IEMgMTMuMzY3MTg4IDMzLjE5OTIxOSA3LjI1NzgxMyAyNy4wOTc2NTYgNy4yNTM5MDYgMTkuNTY2NDA2IEMgNy4yNTM5MDYgMTkuNTYyNSA3LjI1MzkwNiAxOS41NTg1OTQgNy4yNTM5MDYgMTkuNTUwNzgxIEMgNy4yNDYwOTQgMTIuMDIzNDM4IDEzLjM0NzY1NiA1LjkxNDA2MyAyMC44Nzg5MDYgNS45MTAxNTYgQyAyOC40MTAxNTYgNS45MDYyNSAzNC41MTk1MzEgMTIuMDAzOTA2IDM0LjUyMzQzOCAxOS41MzUxNTYgQyAzNC41MjM0MzggMTkuNTM5MDYzIDM0LjUyMzQzOCAxOS41NDY4NzUgMzQuNTIzNDM4IDE5LjU1MDc4MSBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigwJSwwJSwwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDMxLjk3MjY1NiA4LjQ0NTMxMyBDIDM0Ljk5NjA5NCAxMS40Njg3NSAzNi41MDc4MTMgMTUuMTcxODc1IDM2LjUwNzgxMyAxOS41NTA3ODEgQyAzNi41MDc4MTMgMjMuOTI5Njg4IDM1LjAxOTUzMSAyNy41OTM3NSAzMi4wNTA3ODEgMzAuNTM5MDYzIEMgMjguODk0NTMxIDMzLjY0MDYyNSAyNS4xNjc5NjkgMzUuMTkxNDA2IDIwLjg2NzE4OCAzNS4xOTE0MDYgQyAxNi42MTcxODggMzUuMTkxNDA2IDEyLjk1NzAzMSAzMy42NTIzNDQgOS44ODI4MTMgMzAuNTc4MTI1IEMgNi44MDQ2ODggMjcuNTAzOTA2IDUuMjY5NTMxIDIzLjgyODEyNSA1LjI2OTUzMSAxOS41NTA3ODEgQyA1LjI2OTUzMSAxNS4yNzczNDQgNi44MDQ2ODggMTEuNTc0MjE5IDkuODgyODEzIDguNDQ1MzEzIEMgMTIuODc4OTA2IDUuNDIxODc1IDE2LjUzOTA2MyAzLjkxMDE1NiAyMC44NjcxODggMy45MTAxNTYgQyAyNS4yNDYwOTQgMy45MTAxNTYgMjguOTQ5MjE5IDUuNDIxODc1IDMxLjk3MjY1NiA4LjQ0NTMxMyBaIE0gMTEuOTE3OTY5IDEwLjQ4MDQ2OSBDIDkuMzU5Mzc1IDEzLjA2MjUgOC4wODIwMzEgMTYuMDg1OTM4IDguMDgyMDMxIDE5LjU1NDY4OCBDIDguMDgyMDMxIDIzLjAyMzQzOCA5LjM0NzY1NiAyNi4wMjM0MzggMTEuODc1IDI4LjU1MDc4MSBDIDE0LjQwNjI1IDMxLjA4MjAzMSAxNy40MTc5NjkgMzIuMzQzNzUgMjAuOTE0MDYzIDMyLjM0Mzc1IEMgMjQuNDEwMTU2IDMyLjM0Mzc1IDI3LjQ0NTMxMyAzMS4wNjY0MDYgMzAuMDI3MzQ0IDI4LjUxMTcxOSBDIDMyLjQ4MDQ2OSAyNi4xNDA2MjUgMzMuNzA3MDMxIDIzLjE1MjM0NCAzMy43MDcwMzEgMTkuNTU0Njg4IEMgMzMuNzA3MDMxIDE1Ljk4NDM3NSAzMi40NjA5MzggMTIuOTUzMTI1IDI5Ljk2ODc1IDEwLjQ2MDkzOCBDIDI3LjQ3NjU2MyA3Ljk3MjY1NiAyNC40NjA5MzggNi43MjY1NjMgMjAuOTE0MDYzIDYuNzI2NTYzIEMgMTcuMzY3MTg4IDYuNzI2NTYzIDE0LjM2NzE4OCA3Ljk3NjU2MyAxMS45MTc5NjkgMTAuNDgwNDY5IFogTSAxOC42NDQ1MzEgMTguMDMxMjUgQyAxOC4yNTM5MDYgMTcuMTc5Njg4IDE3LjY2Nzk2OSAxNi43NTM5MDYgMTYuODg2NzE5IDE2Ljc1MzkwNiBDIDE1LjUxMTcxOSAxNi43NTM5MDYgMTQuODIwMzEzIDE3LjY3OTY4OCAxNC44MjAzMTMgMTkuNTM1MTU2IEMgMTQuODIwMzEzIDIxLjM5MDYyNSAxNS41MTE3MTkgMjIuMzIwMzEzIDE2Ljg4NjcxOSAyMi4zMjAzMTMgQyAxNy43OTY4NzUgMjIuMzIwMzEzIDE4LjQ0OTIxOSAyMS44NjcxODggMTguODM5ODQ0IDIwLjk2MDkzOCBMIDIwLjc1IDIxLjk4MDQ2OSBDIDE5LjgzOTg0NCAyMy41OTc2NTYgMTguNDcyNjU2IDI0LjQwNjI1IDE2LjY1MjM0NCAyNC40MDYyNSBDIDE1LjI0NjA5NCAyNC40MDYyNSAxNC4xMjEwOTQgMjMuOTc2NTYzIDEzLjI3MzQzOCAyMy4xMTMyODEgQyAxMi40Mjk2ODggMjIuMjUzOTA2IDEyLjAwMzkwNiAyMS4wNjY0MDYgMTIuMDAzOTA2IDE5LjU1MDc4MSBDIDEyLjAwMzkwNiAxOC4wNjI1IDEyLjQ0MTQwNiAxNi44ODI4MTMgMTMuMzEyNSAxNi4wMDc4MTMgQyAxNC4xODM1OTQgMTUuMTMyODEzIDE1LjI3MzQzOCAxNC42OTUzMTMgMTYuNTc0MjE5IDE0LjY5NTMxMyBDIDE4LjUgMTQuNjk1MzEzIDE5Ljg3ODkwNiAxNS40NTMxMjUgMjAuNzEwOTM4IDE2Ljk3MjY1NiBaIE0gMjcuNjMyODEzIDE4LjAzMTI1IEMgMjcuMjQyMTg4IDE3LjE3OTY4OCAyNi42Njc5NjkgMTYuNzUzOTA2IDI1LjkxNDA2MyAxNi43NTM5MDYgQyAyNC41MDc4MTMgMTYuNzUzOTA2IDIzLjgwNDY4OCAxNy42Nzk2ODggMjMuODA0Njg4IDE5LjUzNTE1NiBDIDIzLjgwNDY4OCAyMS4zOTA2MjUgMjQuNTA3ODEzIDIyLjMyMDMxMyAyNS45MTQwNjMgMjIuMzIwMzEzIEMgMjYuODI4MTI1IDIyLjMyMDMxMyAyNy40NjQ4NDQgMjEuODY3MTg4IDI3LjgyODEyNSAyMC45NjA5MzggTCAyOS43ODEyNSAyMS45ODA0NjkgQyAyOC44NzEwOTQgMjMuNTk3NjU2IDI3LjUwNzgxMyAyNC40MDYyNSAyNS42OTE0MDYgMjQuNDA2MjUgQyAyNC4yODUxNTYgMjQuNDA2MjUgMjMuMTY0MDYzIDIzLjk3NjU2MyAyMi4zMTY0MDYgMjMuMTEzMjgxIEMgMjEuNDc2NTYzIDIyLjI1MzkwNiAyMS4wNTA3ODEgMjEuMDY2NDA2IDIxLjA1MDc4MSAxOS41NTA3ODEgQyAyMS4wNTA3ODEgMTguMDYyNSAyMS40ODA0NjkgMTYuODgyODEzIDIyLjMzOTg0NCAxNi4wMDc4MTMgQyAyMy4xOTUzMTMgMTUuMTMyODEzIDI0LjI4NTE1NiAxNC42OTUzMTMgMjUuNjEzMjgxIDE0LjY5NTMxMyBDIDI3LjUzNTE1NiAxNC42OTUzMTMgMjguOTEwMTU2IDE1LjQ1MzEyNSAyOS43NDIxODggMTYuOTcyNjU2IFogIi8+DQo8cGF0aCBzdHlsZT0iIHN0cm9rZTpub25lO2ZpbGwtcnVsZTpub256ZXJvO2ZpbGw6cmdiKDEwMCUsMTAwJSwxMDAlKTtmaWxsLW9wYWNpdHk6MTsiIGQ9Ik0gNjIuNTAzOTA2IDE1LjIyMjY1NiBDIDYyLjUwMzkwNiAyMS4xNTIzNDQgNTcuNjk1MzEzIDI1Ljk2MDkzOCA1MS43NjE3MTkgMjUuOTYwOTM4IEMgNDUuODMyMDMxIDI1Ljk2MDkzOCA0MS4wMjM0MzggMjEuMTUyMzQ0IDQxLjAyMzQzOCAxNS4yMjI2NTYgQyA0MS4wMjM0MzggOS4yOTI5NjkgNDUuODMyMDMxIDQuNDg0Mzc1IDUxLjc2MTcxOSA0LjQ4NDM3NSBDIDU3LjY5NTMxMyA0LjQ4NDM3NSA2Mi41MDM5MDYgOS4yOTI5NjkgNjIuNTAzOTA2IDE1LjIyMjY1NiBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigwJSwwJSwwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDU0Ljg3MTA5NCAxMi4xMTcxODggQyA1NC44NzEwOTQgMTEuNzAzMTI1IDU0LjUzNTE1NiAxMS4zNjcxODggNTQuMTIxMDk0IDExLjM2NzE4OCBMIDQ5LjM3ODkwNiAxMS4zNjcxODggQyA0OC45NjQ4NDQgMTEuMzY3MTg4IDQ4LjYyODkwNiAxMS43MDMxMjUgNDguNjI4OTA2IDEyLjExNzE4OCBMIDQ4LjYyODkwNiAxNi44NTkzNzUgTCA0OS45NTMxMjUgMTYuODU5Mzc1IEwgNDkuOTUzMTI1IDIyLjQ3NjU2MyBMIDUzLjU0Njg3NSAyMi40NzY1NjMgTCA1My41NDY4NzUgMTYuODU5Mzc1IEwgNTQuODcxMDk0IDE2Ljg1OTM3NSBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigwJSwwJSwwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDUzLjM3MTA5NCA5LjEyMTA5NCBDIDUzLjM3MTA5NCAxMC4wMTU2MjUgNTIuNjQ4NDM4IDEwLjc0MjE4OCA1MS43NSAxMC43NDIxODggQyA1MC44NTU0NjkgMTAuNzQyMTg4IDUwLjEyODkwNiAxMC4wMTU2MjUgNTAuMTI4OTA2IDkuMTIxMDk0IEMgNTAuMTI4OTA2IDguMjI2NTYzIDUwLjg1NTQ2OSA3LjUgNTEuNzUgNy41IEMgNTIuNjQ4NDM4IDcuNSA1My4zNzEwOTQgOC4yMjY1NjMgNTMuMzcxMDk0IDkuMTIxMDk0IFogIi8+DQo8cGF0aCBzdHlsZT0iIHN0cm9rZTpub25lO2ZpbGwtcnVsZTpldmVub2RkO2ZpbGw6cmdiKDAlLDAlLDAlKTtmaWxsLW9wYWNpdHk6MTsiIGQ9Ik0gNTEuNzM0Mzc1IDMuMzkwNjI1IEMgNDguNTIzNDM4IDMuMzkwNjI1IDQ1LjgwNDY4OCA0LjUxMTcxOSA0My41NzgxMjUgNi43NTM5MDYgQyA0MS4yOTY4NzUgOS4wNzQyMTkgNDAuMTU2MjUgMTEuODE2NDA2IDQwLjE1NjI1IDE0Ljk4ODI4MSBDIDQwLjE1NjI1IDE4LjE1NjI1IDQxLjI5Njg3NSAyMC44ODI4MTMgNDMuNTc4MTI1IDIzLjE2MDE1NiBDIDQ1Ljg2MzI4MSAyNS40NDE0MDYgNDguNTgyMDMxIDI2LjU4MjAzMSA1MS43MzQzNzUgMjYuNTgyMDMxIEMgNTQuOTI5Njg4IDI2LjU4MjAzMSA1Ny42OTUzMTMgMjUuNDMzNTk0IDYwLjAzOTA2MyAyMy4xMzI4MTMgQyA2Mi4yNDYwOTQgMjAuOTQ5MjE5IDYzLjM0NzY1NiAxOC4yMzQzNzUgNjMuMzQ3NjU2IDE0Ljk4ODI4MSBDIDYzLjM0NzY1NiAxMS43MzgyODEgNjIuMjI2NTYzIDguOTk2MDk0IDU5Ljk4MDQ2OSA2Ljc1MzkwNiBDIDU3LjczNDM3NSA0LjUxMTcxOSA1NC45ODgyODEgMy4zOTA2MjUgNTEuNzM0Mzc1IDMuMzkwNjI1IFogTSA1MS43NjU2MjUgNS40ODA0NjkgQyA1NC4zOTg0MzggNS40ODA0NjkgNTYuNjMyODEzIDYuNDA2MjUgNTguNDY4NzUgOC4yNjE3MTkgQyA2MC4zMjgxMjUgMTAuMDk3NjU2IDYxLjI1NzgxMyAxMi4zMzk4NDQgNjEuMjU3ODEzIDE0Ljk4ODI4MSBDIDYxLjI1NzgxMyAxNy42NTIzNDQgNjAuMzQ3NjU2IDE5Ljg2NzE4OCA1OC41MjczNDQgMjEuNjI1IEMgNTYuNjEzMjgxIDIzLjUxOTUzMSA1NC4zNTkzNzUgMjQuNDY0ODQ0IDUxLjc2NTYyNSAyNC40NjQ4NDQgQyA0OS4xNzE4NzUgMjQuNDY0ODQ0IDQ2LjkzNzUgMjMuNTI3MzQ0IDQ1LjA1ODU5NCAyMS42NTIzNDQgQyA0My4xODM1OTQgMTkuNzgxMjUgNDIuMjQ2MDk0IDE3LjU1ODU5NCA0Mi4yNDYwOTQgMTQuOTg4MjgxIEMgNDIuMjQ2MDk0IDEyLjQxNzk2OSA0My4xOTE0MDYgMTAuMTc1NzgxIDQ1LjA4OTg0NCA4LjI2MTcxOSBDIDQ2LjkxMDE1NiA2LjQwNjI1IDQ5LjEzMjgxMyA1LjQ4MDQ2OSA1MS43NjU2MjUgNS40ODA0NjkgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMTAwJSwxMDAlLDEwMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSA0OC40MDIzNDQgMzIuNzQ2MDk0IEMgNDguNzE0ODQ0IDMyLjc0NjA5NCA0OS4wMDM5MDYgMzIuNzc3MzQ0IDQ5LjI2NTYyNSAzMi44MzIwMzEgQyA0OS41MjM0MzggMzIuODg2NzE5IDQ5Ljc1IDMyLjk3NjU2MyA0OS45MzM1OTQgMzMuMTA1NDY5IEMgNTAuMTIxMDk0IDMzLjIzMDQ2OSA1MC4yNjE3MTkgMzMuMzk4NDM4IDUwLjM2NzE4OCAzMy42MDkzNzUgQyA1MC40Njg3NSAzMy44MjAzMTMgNTAuNTE5NTMxIDM0LjA3ODEyNSA1MC41MTk1MzEgMzQuMzg2NzE5IEMgNTAuNTE5NTMxIDM0LjcyMjY1NiA1MC40NDUzMTMgMzUgNTAuMjkyOTY5IDM1LjIyMjY1NiBDIDUwLjE0MDYyNSAzNS40NDUzMTMgNDkuOTE0MDYzIDM1LjYyNSA0OS42MTcxODggMzUuNzY5NTMxIEMgNTAuMDI3MzQ0IDM1Ljg4NjcxOSA1MC4zMzIwMzEgMzYuMDkzNzUgNTAuNTM1MTU2IDM2LjM4NjcxOSBDIDUwLjczODI4MSAzNi42Nzk2ODggNTAuODM5ODQ0IDM3LjAzNTE1NiA1MC44Mzk4NDQgMzcuNDQ5MjE5IEMgNTAuODM5ODQ0IDM3Ljc4MTI1IDUwLjc3MzQzOCAzOC4wNzAzMTMgNTAuNjQ0NTMxIDM4LjMxNjQwNiBDIDUwLjUxMTcxOSAzOC41NTg1OTQgNTAuMzM1OTM4IDM4Ljc2MTcxOSA1MC4xMTcxODggMzguOTE0MDYzIEMgNDkuODk4NDM4IDM5LjA3MDMxMyA0OS42NDQ1MzEgMzkuMTgzNTk0IDQ5LjM2MzI4MSAzOS4yNTc4MTMgQyA0OS4wODIwMzEgMzkuMzMyMDMxIDQ4Ljc5Mjk2OSAzOS4zNzEwOTQgNDguNDk2MDk0IDM5LjM3MTA5NCBMIDQ1LjI3NzM0NCAzOS4zNzEwOTQgTCA0NS4yNzczNDQgMzIuNzQ2MDk0IFogTSA0OC4yMTQ4NDQgMzUuNDI1NzgxIEMgNDguNDc2NTYzIDM1LjQyNTc4MSA0OC42ODc1IDM1LjM2MzI4MSA0OC44NTU0NjkgMzUuMjQyMTg4IEMgNDkuMDIzNDM4IDM1LjExNzE4OCA0OS4xMDU0NjkgMzQuOTE3OTY5IDQ5LjEwNTQ2OSAzNC42NDA2MjUgQyA0OS4xMDU0NjkgMzQuNDg0Mzc1IDQ5LjA3ODEyNSAzNC4zNTkzNzUgNDkuMDIzNDM4IDM0LjI2MTcxOSBDIDQ4Ljk2ODc1IDM0LjE2MDE1NiA0OC44OTQ1MzEgMzQuMDg1OTM4IDQ4LjgwMDc4MSAzNC4wMjczNDQgQyA0OC43MDcwMzEgMzMuOTcyNjU2IDQ4LjYwMTU2MyAzMy45MzM1OTQgNDguNDgwNDY5IDMzLjkxNDA2MyBDIDQ4LjM1OTM3NSAzMy44OTA2MjUgNDguMjM0Mzc1IDMzLjg3ODkwNiA0OC4xMDE1NjMgMzMuODc4OTA2IEwgNDYuNzM4MjgxIDMzLjg3ODkwNiBMIDQ2LjczODI4MSAzNS40MjU3ODEgWiBNIDQ4LjMwMDc4MSAzOC4yMzQzNzUgQyA0OC40NDE0MDYgMzguMjM0Mzc1IDQ4LjU3ODEyNSAzOC4yMjI2NTYgNDguNzA3MDMxIDM4LjE5NTMxMyBDIDQ4LjgzOTg0NCAzOC4xNjc5NjkgNDguOTUzMTI1IDM4LjEyMTA5NCA0OS4wNTQ2ODggMzguMDU0Njg4IEMgNDkuMTUyMzQ0IDM3Ljk5MjE4OCA0OS4yMzA0NjkgMzcuOTAyMzQ0IDQ5LjI4OTA2MyAzNy43ODkwNjMgQyA0OS4zNDc2NTYgMzcuNjc5Njg4IDQ5LjM3ODkwNiAzNy41MzkwNjMgNDkuMzc4OTA2IDM3LjM2MzI4MSBDIDQ5LjM3ODkwNiAzNy4wMjM0MzggNDkuMjgxMjUgMzYuNzgxMjUgNDkuMDg5ODQ0IDM2LjYzNjcxOSBDIDQ4Ljg5ODQzOCAzNi40OTIxODggNDguNjQ0NTMxIDM2LjQxNzk2OSA0OC4zMjgxMjUgMzYuNDE3OTY5IEwgNDYuNzM4MjgxIDM2LjQxNzk2OSBMIDQ2LjczODI4MSAzOC4yMzQzNzUgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMTAwJSwxMDAlLDEwMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSA1MS4wOTM3NSAzMi43NDYwOTQgTCA1Mi43MjY1NjMgMzIuNzQ2MDk0IEwgNTQuMjc3MzQ0IDM1LjM2MzI4MSBMIDU1LjgyMDMxMyAzMi43NDYwOTQgTCA1Ny40NDUzMTMgMzIuNzQ2MDk0IEwgNTQuOTg0Mzc1IDM2LjgyODEyNSBMIDU0Ljk4NDM3NSAzOS4zNzEwOTQgTCA1My41MjM0MzggMzkuMzcxMDk0IEwgNTMuNTIzNDM4IDM2Ljc4OTA2MyBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigxMDAlLDEwMCUsMTAwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDk4LjQ0MTQwNiAzNy43MzA0NjkgQyA5OC41MTk1MzEgMzcuODg2NzE5IDk4LjYyNSAzOC4wMTE3MTkgOTguNzYxNzE5IDM4LjEwOTM3NSBDIDk4Ljg5NDUzMSAzOC4yMDMxMjUgOTkuMDQ2ODc1IDM4LjI3MzQzOCA5OS4yMjY1NjMgMzguMzIwMzEzIEMgOTkuNDA2MjUgMzguMzY3MTg4IDk5LjU4OTg0NCAzOC4zOTA2MjUgOTkuNzgxMjUgMzguMzkwNjI1IEMgOTkuOTEwMTU2IDM4LjM5MDYyNSAxMDAuMDUwNzgxIDM4LjM3ODkwNiAxMDAuMTk5MjE5IDM4LjM1OTM3NSBDIDEwMC4zNDc2NTYgMzguMzM1OTM4IDEwMC40ODQzNzUgMzguMjk2ODc1IDEwMC42MTcxODggMzguMjM0Mzc1IEMgMTAwLjc0NjA5NCAzOC4xNzE4NzUgMTAwLjg1MTU2MyAzOC4wODU5MzggMTAwLjk0MTQwNiAzNy45NzY1NjMgQyAxMDEuMDIzNDM4IDM3Ljg3MTA5NCAxMDEuMDcwMzEzIDM3LjczMDQ2OSAxMDEuMDcwMzEzIDM3LjU2NjQwNiBDIDEwMS4wNzAzMTMgMzcuMzg2NzE5IDEwMS4wMTE3MTkgMzcuMjQyMTg4IDEwMC44OTg0MzggMzcuMTI4OTA2IEMgMTAwLjc4NTE1NiAzNy4wMTk1MzEgMTAwLjYzMjgxMyAzNi45MjU3ODEgMTAwLjQ0OTIxOSAzNi44NTE1NjMgQyAxMDAuMjYxNzE5IDM2Ljc3NzM0NCAxMDAuMDUwNzgxIDM2LjcxMDkzOCA5OS44MjAzMTMgMzYuNjU2MjUgQyA5OS41ODIwMzEgMzYuNjAxNTYzIDk5LjM0NzY1NiAzNi41MzkwNjMgOTkuMTA1NDY5IDM2LjQ3MjY1NiBDIDk4Ljg1OTM3NSAzNi40MTAxNTYgOTguNjE3MTg4IDM2LjMzMjAzMSA5OC4zODI4MTMgMzYuMjQyMTg4IEMgOTguMTQ4NDM4IDM2LjE1NjI1IDk3LjkzNzUgMzYuMDM5MDYzIDk3Ljc1MzkwNiAzNS44OTQ1MzEgQyA5Ny41NjY0MDYgMzUuNzUzOTA2IDk3LjQxNzk2OSAzNS41NzQyMTkgOTcuMzA0Njg4IDM1LjM2MzI4MSBDIDk3LjE5MTQwNiAzNS4xNDg0MzggOTcuMTMyODEzIDM0Ljg5MDYyNSA5Ny4xMzI4MTMgMzQuNTg5ODQ0IEMgOTcuMTMyODEzIDM0LjI0NjA5NCA5Ny4yMDcwMzEgMzMuOTUzMTI1IDk3LjM1MTU2MyAzMy43MDMxMjUgQyA5Ny40OTYwOTQgMzMuNDUzMTI1IDk3LjY4MzU5NCAzMy4yNDIxODggOTcuOTE3OTY5IDMzLjA3NDIxOSBDIDk4LjE1MjM0NCAzMi45MTAxNTYgOTguNDIxODc1IDMyLjc4NTE1NiA5OC43MTg3NSAzMi43MDMxMjUgQyA5OS4wMTE3MTkgMzIuNjI1IDk5LjMwODU5NCAzMi41ODU5MzggOTkuNjA1NDY5IDMyLjU4NTkzOCBDIDk5Ljk1MzEyNSAzMi41ODU5MzggMTAwLjI4NTE1NiAzMi42MjUgMTAwLjYwMTU2MyAzMi42OTkyMTkgQyAxMDAuOTIxODc1IDMyLjc3NzM0NCAxMDEuMjAzMTI1IDMyLjkwMjM0NCAxMDEuNDQ5MjE5IDMzLjA3ODEyNSBDIDEwMS42OTkyMTkgMzMuMjUgMTAxLjg5NDUzMSAzMy40NzI2NTYgMTAyLjAzOTA2MyAzMy43MzgyODEgQyAxMDIuMTgzNTk0IDM0LjAxMTcxOSAxMDIuMjU3ODEzIDM0LjMzNTkzOCAxMDIuMjU3ODEzIDM0LjcxODc1IEwgMTAwLjg0Mzc1IDM0LjcxODc1IEMgMTAwLjgzMjAzMSAzNC41MTk1MzEgMTAwLjc4OTA2MyAzNC4zNTU0NjkgMTAwLjcxODc1IDM0LjIyNjU2MyBDIDEwMC42NDg0MzggMzQuMDk3NjU2IDEwMC41NTQ2ODggMzMuOTk2MDk0IDEwMC40Mzc1IDMzLjkyMTg3NSBDIDEwMC4zMjAzMTMgMzMuODQ3NjU2IDEwMC4xODc1IDMzLjc5Mjk2OSAxMDAuMDM1MTU2IDMzLjc2NTYyNSBDIDk5Ljg4NjcxOSAzMy43MzQzNzUgOTkuNzE4NzUgMzMuNzE4NzUgOTkuNTQyOTY5IDMzLjcxODc1IEMgOTkuNDI1NzgxIDMzLjcxODc1IDk5LjMwODU5NCAzMy43MzA0NjkgOTkuMTkxNDA2IDMzLjc1MzkwNiBDIDk5LjA3NDIxOSAzMy43ODEyNSA5OC45Njg3NSAzMy44MjQyMTkgOTguODc1IDMzLjg4MjgxMyBDIDk4Ljc3NzM0NCAzMy45NDUzMTMgOTguNjk5MjE5IDM0LjAyMzQzOCA5OC42MzY3MTkgMzQuMTE3MTg4IEMgOTguNTc4MTI1IDM0LjIxMDkzOCA5OC41NDY4NzUgMzQuMzI4MTI1IDk4LjU0Njg3NSAzNC40Njg3NSBDIDk4LjU0Njg3NSAzNC41OTc2NTYgOTguNTcwMzEzIDM0LjcwMzEyNSA5OC42MTcxODggMzQuNzg1MTU2IEMgOTguNjY3OTY5IDM0Ljg2MzI4MSA5OC43NjU2MjUgMzQuOTQxNDA2IDk4LjkxMDE1NiAzNS4wMDc4MTMgQyA5OS4wNTg1OTQgMzUuMDc0MjE5IDk5LjI1NzgxMyAzNS4xNDQ1MzEgOTkuNTExNzE5IDM1LjIxMDkzOCBDIDk5Ljc2OTUzMSAzNS4yNzczNDQgMTAwLjEwNTQ2OSAzNS4zNjcxODggMTAwLjUxOTUzMSAzNS40NzI2NTYgQyAxMDAuNjQwNjI1IDM1LjQ5NjA5NCAxMDAuODEyNSAzNS41NDI5NjkgMTAxLjAzMTI1IDM1LjYwNTQ2OSBDIDEwMS4yNSAzNS42NzE4NzUgMTAxLjQ2ODc1IDM1Ljc3MzQzOCAxMDEuNjgzNTk0IDM1LjkxNzk2OSBDIDEwMS45MDIzNDQgMzYuMDU4NTk0IDEwMi4wODU5MzggMzYuMjUgMTAyLjI0NjA5NCAzNi40ODgyODEgQyAxMDIuNDAyMzQ0IDM2LjcyNjU2MyAxMDIuNDgwNDY5IDM3LjAzMTI1IDEwMi40ODA0NjkgMzcuNDAyMzQ0IEMgMTAyLjQ4MDQ2OSAzNy43MDMxMjUgMTAyLjQyMTg3NSAzNy45ODQzNzUgMTAyLjMwNDY4OCAzOC4yNDYwOTQgQyAxMDIuMTg3NSAzOC41MDM5MDYgMTAyLjAxMTcxOSAzOC43MzA0NjkgMTAxLjc4MTI1IDM4LjkxNzk2OSBDIDEwMS41NTA3ODEgMzkuMTA1NDY5IDEwMS4yNjE3MTkgMzkuMjUzOTA2IDEwMC45MTc5NjkgMzkuMzU5Mzc1IEMgMTAwLjU3NDIxOSAzOS40NjQ4NDQgMTAwLjE3OTY4OCAzOS41MTU2MjUgOTkuNzI2NTYzIDM5LjUxNTYyNSBDIDk5LjM2MzI4MSAzOS41MTU2MjUgOTkuMDA3ODEzIDM5LjQ3MjY1NiA5OC42NjQwNjMgMzkuMzgyODEzIEMgOTguMzIwMzEzIDM5LjI5Mjk2OSA5OC4wMTk1MzEgMzkuMTUyMzQ0IDk3Ljc1NzgxMyAzOC45NTcwMzEgQyA5Ny40OTIxODggMzguNzY1NjI1IDk3LjI4NTE1NiAzOC41MTk1MzEgOTcuMTI4OTA2IDM4LjIyMjY1NiBDIDk2Ljk3NjU2MyAzNy45MjU3ODEgOTYuOTAyMzQ0IDM3LjU3NDIxOSA5Ni45MDYyNSAzNy4xNjc5NjkgTCA5OC4zMjAzMTMgMzcuMTY3OTY5IEMgOTguMzIwMzEzIDM3LjM5MDYyNSA5OC4zNTkzNzUgMzcuNTc4MTI1IDk4LjQ0MTQwNiAzNy43MzA0NjkgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMTAwJSwxMDAlLDEwMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSAxMDYuNjQ0NTMxIDMyLjc0NjA5NCBMIDEwOS4xMjEwOTQgMzkuMzcxMDk0IEwgMTA3LjYwOTM3NSAzOS4zNzEwOTQgTCAxMDcuMTA5Mzc1IDM3Ljg5NDUzMSBMIDEwNC42MzI4MTMgMzcuODk0NTMxIEwgMTA0LjExMzI4MSAzOS4zNzEwOTQgTCAxMDIuNjQ4NDM4IDM5LjM3MTA5NCBMIDEwNS4xNTIzNDQgMzIuNzQ2MDk0IFogTSAxMDYuNzMwNDY5IDM2LjgwODU5NCBMIDEwNS44OTQ1MzEgMzQuMzc4OTA2IEwgMTA1Ljg3NSAzNC4zNzg5MDYgTCAxMDUuMDE1NjI1IDM2LjgwODU5NCBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigxMDAlLDEwMCUsMTAwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDcyLjUxOTUzMSAzMi43NDYwOTQgTCA3NS4yODUxNTYgMzcuMTkxNDA2IEwgNzUuMzAwNzgxIDM3LjE5MTQwNiBMIDc1LjMwMDc4MSAzMi43NDYwOTQgTCA3Ni42Njc5NjkgMzIuNzQ2MDk0IEwgNzYuNjY3OTY5IDM5LjM3MTA5NCBMIDc1LjIxMDkzOCAzOS4zNzEwOTQgTCA3Mi40NTMxMjUgMzQuOTM3NSBMIDcyLjQzMzU5NCAzNC45Mzc1IEwgNzIuNDMzNTk0IDM5LjM3MTA5NCBMIDcxLjA3MDMxMyAzOS4zNzEwOTQgTCA3MS4wNzAzMTMgMzIuNzQ2MDk0IFogIi8+DQo8cGF0aCBzdHlsZT0iIHN0cm9rZTpub25lO2ZpbGwtcnVsZTpub256ZXJvO2ZpbGw6cmdiKDEwMCUsMTAwJSwxMDAlKTtmaWxsLW9wYWNpdHk6MTsiIGQ9Ik0gODIuMTk1MzEzIDM0LjUxMTcxOSBDIDgyLjEwOTM3NSAzNC4zNzEwOTQgODIgMzQuMjUgODEuODcxMDk0IDM0LjE0NDUzMSBDIDgxLjc0MjE4OCAzNC4wMzkwNjMgODEuNTkzNzUgMzMuOTU3MDMxIDgxLjQyOTY4OCAzMy44OTg0MzggQyA4MS4yNjU2MjUgMzMuODM5ODQ0IDgxLjA5Mzc1IDMzLjgxMjUgODAuOTE0MDYzIDMzLjgxMjUgQyA4MC41ODU5MzggMzMuODEyNSA4MC4zMDg1OTQgMzMuODc1IDgwLjA3ODEyNSAzNCBDIDc5Ljg1MTU2MyAzNC4xMjg5MDYgNzkuNjY0MDYzIDM0LjI5Njg3NSA3OS41MjM0MzggMzQuNTExNzE5IEMgNzkuMzgyODEzIDM0LjcyMjY1NiA3OS4yNzczNDQgMzQuOTY0ODQ0IDc5LjIxMDkzOCAzNS4yMzgyODEgQyA3OS4xNDg0MzggMzUuNTExNzE5IDc5LjExMzI4MSAzNS43OTI5NjkgNzkuMTEzMjgxIDM2LjA4MjAzMSBDIDc5LjExMzI4MSAzNi4zNTkzNzUgNzkuMTQ4NDM4IDM2LjYzMjgxMyA3OS4yMTA5MzggMzYuODk0NTMxIEMgNzkuMjc3MzQ0IDM3LjE1NjI1IDc5LjM4MjgxMyAzNy4zOTQ1MzEgNzkuNTIzNDM4IDM3LjYwMTU2MyBDIDc5LjY2NDA2MyAzNy44MTI1IDc5Ljg1MTU2MyAzNy45ODA0NjkgODAuMDc4MTI1IDM4LjEwOTM3NSBDIDgwLjMwODU5NCAzOC4yMzQzNzUgODAuNTg1OTM4IDM4LjI5Njg3NSA4MC45MTQwNjMgMzguMjk2ODc1IEMgODEuMzU5Mzc1IDM4LjI5Njg3NSA4MS43MDcwMzEgMzguMTY0MDYzIDgxLjk1NzAzMSAzNy44OTA2MjUgQyA4Mi4yMTA5MzggMzcuNjE3MTg4IDgyLjM2MzI4MSAzNy4yNTc4MTMgODIuNDE3OTY5IDM2LjgxMjUgTCA4My44MjgxMjUgMzYuODEyNSBDIDgzLjc5Mjk2OSAzNy4yMjY1NjMgODMuNjk1MzEzIDM3LjYwMTU2MyA4My41MzkwNjMgMzcuOTM3NSBDIDgzLjM4NjcxOSAzOC4yNjk1MzEgODMuMTc5Njg4IDM4LjU1NDY4OCA4Mi45Mjk2ODggMzguNzg5MDYzIEMgODIuNjc1NzgxIDM5LjAyNzM0NCA4Mi4zNzg5MDYgMzkuMjA3MDMxIDgyLjAzOTA2MyAzOS4zMzIwMzEgQyA4MS42OTkyMTkgMzkuNDUzMTI1IDgxLjMyNDIxOSAzOS41MTU2MjUgODAuOTE0MDYzIDM5LjUxNTYyNSBDIDgwLjQwNjI1IDM5LjUxNTYyNSA3OS45NTMxMjUgMzkuNDI5Njg4IDc5LjU0Njg3NSAzOS4yNSBDIDc5LjE0MDYyNSAzOS4wNzgxMjUgNzguODAwNzgxIDM4LjgzMjAzMSA3OC41MTk1MzEgMzguNTIzNDM4IEMgNzguMjQyMTg4IDM4LjIxNDg0NCA3OC4wMjczNDQgMzcuODUxNTYzIDc3Ljg3ODkwNiAzNy40MzM1OTQgQyA3Ny43MzA0NjkgMzcuMDE1NjI1IDc3LjY1NjI1IDM2LjU2NjQwNiA3Ny42NTYyNSAzNi4wODIwMzEgQyA3Ny42NTYyNSAzNS41ODU5MzggNzcuNzMwNDY5IDM1LjEyODkwNiA3Ny44Nzg5MDYgMzQuNzAzMTI1IEMgNzguMDI3MzQ0IDM0LjI4MTI1IDc4LjI0MjE4OCAzMy45MTAxNTYgNzguNTE5NTMxIDMzLjU5Mzc1IEMgNzguODAwNzgxIDMzLjI4MTI1IDc5LjE0MDYyNSAzMy4wMzEyNSA3OS41NDY4NzUgMzIuODUxNTYzIEMgNzkuOTUzMTI1IDMyLjY3MTg3NSA4MC40MDYyNSAzMi41ODU5MzggODAuOTE0MDYzIDMyLjU4NTkzOCBDIDgxLjI4MTI1IDMyLjU4NTkzOCA4MS42MjUgMzIuNjM2NzE5IDgxLjk0OTIxOSAzMi43NDIxODggQyA4Mi4yNzM0MzggMzIuODQ3NjU2IDgyLjU2NjQwNiAzMyA4Mi44MjAzMTMgMzMuMjAzMTI1IEMgODMuMDc4MTI1IDMzLjQwMjM0NCA4My4yODkwNjMgMzMuNjUyMzQ0IDgzLjQ1NzAzMSAzMy45NDkyMTkgQyA4My42MjUgMzQuMjQ2MDk0IDgzLjczMDQ2OSAzNC41ODU5MzggODMuNzczNDM4IDM0Ljk2ODc1IEwgODIuMzYzMjgxIDM0Ljk2ODc1IEMgODIuMzM1OTM4IDM0LjgwNDY4OCA4Mi4yODEyNSAzNC42NDg0MzggODIuMTk1MzEzIDM0LjUxMTcxOSBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigxMDAlLDEwMCUsMTAwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDExNC41NzgxMjUgMTQuOTgwNDY5IEMgMTE0LjU4NTkzOCAyMC44MjQyMTkgMTA5Ljg0NzY1NiAyNS41NjY0MDYgMTA0LjAwMzkwNiAyNS41NzQyMTkgQyA5OC4xNTYyNSAyNS41NzQyMTkgOTMuNDE0MDYzIDIwLjg0Mzc1IDkzLjQxMDE1NiAxNC45OTYwOTQgQyA5My40MTAxNTYgMTQuOTkyMTg4IDkzLjQxMDE1NiAxNC45ODQzNzUgOTMuNDEwMTU2IDE0Ljk4MDQ2OSBDIDkzLjQwNjI1IDkuMTM2NzE5IDk4LjE0MDYyNSA0LjM5NDUzMSAxMDMuOTg4MjgxIDQuMzkwNjI1IEMgMTA5LjgzMjAzMSA0LjM4MjgxMyAxMTQuNTc0MjE5IDkuMTIxMDk0IDExNC41NzgxMjUgMTQuOTY0ODQ0IEMgMTE0LjU3ODEyNSAxNC45Njg3NSAxMTQuNTc4MTI1IDE0Ljk3NjU2MyAxMTQuNTc4MTI1IDE0Ljk4MDQ2OSBaICIvPg0KPHBhdGggc3R5bGU9IiBzdHJva2U6bm9uZTtmaWxsLXJ1bGU6bm9uemVybztmaWxsOnJnYigwJSwwJSwwJSk7ZmlsbC1vcGFjaXR5OjE7IiBkPSJNIDEwMy45MTc5NjkgMy4zODY3MTkgQyAxMDAuNzA3MDMxIDMuMzg2NzE5IDk3Ljk4ODI4MSA0LjUwNzgxMyA5NS43NjE3MTkgNi43NDYwOTQgQyA5My40ODA0NjkgOS4wNjY0MDYgOTIuMzM1OTM4IDExLjgxMjUgOTIuMzM1OTM4IDE0Ljk4MDQ2OSBDIDkyLjMzNTkzOCAxOC4xNDg0MzggOTMuNDgwNDY5IDIwLjg3NSA5NS43NjE3MTkgMjMuMTU2MjUgQyA5OC4wNDY4NzUgMjUuNDM3NSAxMDAuNzY1NjI1IDI2LjU3NDIxOSAxMDMuOTE3OTY5IDI2LjU3NDIxOSBDIDEwNy4xMTMyODEgMjYuNTc0MjE5IDEwOS44Nzg5MDYgMjUuNDI1NzgxIDExMi4yMTg3NSAyMy4xMjUgQyAxMTQuNDI1NzgxIDIwLjk0MTQwNiAxMTUuNTMxMjUgMTguMjI2NTYzIDExNS41MzEyNSAxNC45ODA0NjkgQyAxMTUuNTMxMjUgMTEuNzM0Mzc1IDExNC40MDYyNSA4Ljk4ODI4MSAxMTIuMTY0MDYzIDYuNzQ2MDk0IEMgMTA5LjkxNzk2OSA0LjUwNzgxMyAxMDcuMTcxODc1IDMuMzg2NzE5IDEwMy45MTc5NjkgMy4zODY3MTkgWiBNIDEwMy45NDkyMTkgNS40NzI2NTYgQyAxMDYuNTc4MTI1IDUuNDcyNjU2IDEwOC44MTI1IDYuMzk4NDM4IDExMC42NTIzNDQgOC4yNTc4MTMgQyAxMTIuNTExNzE5IDEwLjA4OTg0NCAxMTMuNDM3NSAxMi4zMzIwMzEgMTEzLjQzNzUgMTQuOTgwNDY5IEMgMTEzLjQzNzUgMTcuNjQ4NDM4IDExMi41MzEyNSAxOS44NTkzNzUgMTEwLjcxMDkzOCAyMS42MjEwOTQgQyAxMDguNzk2ODc1IDIzLjUxMTcxOSAxMDYuNTM5MDYzIDI0LjQ2MDkzOCAxMDMuOTQ5MjE5IDI0LjQ2MDkzOCBDIDEwMS4zNTU0NjkgMjQuNDYwOTM4IDk5LjEyMTA5NCAyMy41MjM0MzggOTcuMjQyMTg4IDIxLjY0ODQzOCBDIDk1LjM2NzE4OCAxOS43NzM0MzggOTQuNDI1NzgxIDE3LjU1MDc4MSA5NC40MjU3ODEgMTQuOTgwNDY5IEMgOTQuNDI1NzgxIDEyLjQxMDE1NiA5NS4zNzUgMTAuMTY3OTY5IDk3LjI3MzQzOCA4LjI1NzgxMyBDIDk5LjA4OTg0NCA2LjM5ODQzOCAxMDEuMzE2NDA2IDUuNDcyNjU2IDEwMy45NDkyMTkgNS40NzI2NTYgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMCUsMCUsMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSA5OC43NzczNDQgMTMuMzQzNzUgQyA5OS4yNDIxODggMTAuNDI1NzgxIDEwMS4yOTI5NjkgOC44NjcxODggMTAzLjg3MTA5NCA4Ljg2NzE4OCBDIDEwNy41NzAzMTMgOC44NjcxODggMTA5LjgyODEyNSAxMS41NTQ2ODggMTA5LjgyODEyNSAxNS4xMzY3MTkgQyAxMDkuODI4MTI1IDE4LjYyODkwNiAxMDcuNDI1NzgxIDIxLjM0Mzc1IDEwMy44MTI1IDIxLjM0Mzc1IEMgMTAxLjMyNDIxOSAyMS4zNDM3NSA5OS4wOTc2NTYgMTkuODE2NDA2IDk4LjY5MTQwNiAxNi44MDg1OTQgTCAxMDEuNjEzMjgxIDE2LjgwODU5NCBDIDEwMS42OTkyMTkgMTguMzcxMDk0IDEwMi43MTA5MzggMTguOTE3OTY5IDEwNC4xNjAxNTYgMTguOTE3OTY5IEMgMTA1LjgwNDY4OCAxOC45MTc5NjkgMTA2Ljg3ODkwNiAxNy4zODY3MTkgMTA2Ljg3ODkwNiAxNS4wNDY4NzUgQyAxMDYuODc4OTA2IDEyLjU5Mzc1IDEwNS45NTMxMjUgMTEuMjkyOTY5IDEwNC4yMTQ4NDQgMTEuMjkyOTY5IEMgMTAyLjk0NTMxMyAxMS4yOTI5NjkgMTAxLjg0Mzc1IDExLjc1NzgxMyAxMDEuNjEzMjgxIDEzLjM0Mzc1IEwgMTAyLjQ2MDkzOCAxMy4zMzk4NDQgTCAxMDAuMTY0MDYzIDE1LjYzNjcxOSBMIDk3Ljg2MzI4MSAxMy4zMzk4NDQgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMTAwJSwxMDAlLDEwMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSA4OC42Mjg5MDYgMTQuOTgwNDY5IEMgODguNjMyODEzIDIwLjkzNzUgODMuODA4NTk0IDI1Ljc2OTUzMSA3Ny44NTE1NjMgMjUuNzczNDM4IEMgNzEuODk0NTMxIDI1Ljc3NzM0NCA2Ny4wNTg1OTQgMjAuOTUzMTI1IDY3LjA1NDY4OCAxNC45OTYwOTQgQyA2Ny4wNTQ2ODggMTQuOTkyMTg4IDY3LjA1NDY4OCAxNC45ODQzNzUgNjcuMDU0Njg4IDE0Ljk4MDQ2OSBDIDY3LjA1MDc4MSA5LjAyMzQzOCA3MS44Nzg5MDYgNC4xOTE0MDYgNzcuODM1OTM4IDQuMTg3NSBDIDgzLjc5Mjk2OSA0LjE4MzU5NCA4OC42MjUgOS4wMDc4MTMgODguNjI4OTA2IDE0Ljk2NDg0NCBDIDg4LjYyODkwNiAxNC45Njg3NSA4OC42Mjg5MDYgMTQuOTc2NTYzIDg4LjYyODkwNiAxNC45ODA0NjkgWiAiLz4NCjxwYXRoIHN0eWxlPSIgc3Ryb2tlOm5vbmU7ZmlsbC1ydWxlOm5vbnplcm87ZmlsbDpyZ2IoMCUsMCUsMCUpO2ZpbGwtb3BhY2l0eToxOyIgZD0iTSA3Ny44MjgxMjUgMy4zODY3MTkgQyA4MS4wNzgxMjUgMy4zODY3MTkgODMuODI0MjE5IDQuNTA3ODEzIDg2LjA3MDMxMyA2Ljc0NjA5NCBDIDg4LjMxNjQwNiA4Ljk4ODI4MSA4OS40Mzc1IDExLjczNDM3NSA4OS40Mzc1IDE0Ljk4MDQ2OSBDIDg5LjQzNzUgMTguMjI2NTYzIDg4LjMzNTkzOCAyMC45NDE0MDYgODYuMTI4OTA2IDIzLjEyNSBDIDgzLjc4OTA2MyAyNS40MjU3ODEgODEuMDE5NTMxIDI2LjU3NDIxOSA3Ny44MjgxMjUgMjYuNTc0MjE5IEMgNzQuNjcxODc1IDI2LjU3NDIxOSA3MS45NTMxMjUgMjUuNDM3NSA2OS42NzE4NzUgMjMuMTU2MjUgQyA2Ny4zODY3MTkgMjAuODc1IDY2LjI0NjA5NCAxOC4xNDg0MzggNjYuMjQ2MDk0IDE0Ljk4MDQ2OSBDIDY2LjI0NjA5NCAxMS44MTI1IDY3LjM4NjcxOSA5LjA2NjQwNiA2OS42NzE4NzUgNi43NDYwOTQgQyA3MS44OTg0MzggNC41MDc4MTMgNzQuNjEzMjgxIDMuMzg2NzE5IDc3LjgyODEyNSAzLjM4NjcxOSBaIE0gNjguODU1NDY5IDExLjg2NzE4OCBDIDY4LjUwNzgxMyAxMi44NDM3NSA2OC4zMzU5MzggMTMuODgyODEzIDY4LjMzNTkzOCAxNC45ODA0NjkgQyA2OC4zMzU5MzggMTcuNTUwNzgxIDY5LjI3MzQzOCAxOS43NzM0MzggNzEuMTUyMzQ0IDIxLjY0ODQzOCBDIDczLjAyNzM0NCAyMy41MjM0MzggNzUuMjYxNzE5IDI0LjQ2MDkzOCA3Ny44NTU0NjkgMjQuNDYwOTM4IEMgODAuNDQ5MjE5IDI0LjQ2MDkzOCA4Mi43MDMxMjUgMjMuNTExNzE5IDg0LjYyMTA5NCAyMS42MTcxODggQyA4NS4yNjE3MTkgMjEgODUuNzg5MDYzIDIwLjMyNDIxOSA4Ni4yMDMxMjUgMTkuNTg5ODQ0IEwgODEuODMyMDMxIDE3LjY0NDUzMSBDIDgxLjUzNTE1NiAxOS4xMTMyODEgODAuMjI2NTYzIDIwLjEwOTM3NSA3OC42NDA2MjUgMjAuMjI2NTYzIEwgNzguNjQwNjI1IDIyLjAxMTcxOSBMIDc3LjMwODU5NCAyMi4wMTE3MTkgTCA3Ny4zMDg1OTQgMjAuMjI2NTYzIEMgNzYuMDA3ODEzIDIwLjIxMDkzOCA3NC43NSAxOS42NzU3ODEgNzMuNzg5MDYzIDE4LjgzNTkzOCBMIDc1LjM4NjcxOSAxNy4yMjY1NjMgQyA3Ni4xNTYyNSAxNy45NDkyMTkgNzYuOTI1NzgxIDE4LjI3MzQzOCA3Ny45NzY1NjMgMTguMjczNDM4IEMgNzguNjU2MjUgMTguMjczNDM4IDc5LjQxMDE1NiAxOC4wMDc4MTMgNzkuNDEwMTU2IDE3LjEyMTA5NCBDIDc5LjQxMDE1NiAxNi44MDg1OTQgNzkuMjg5MDYzIDE2LjU4OTg0NCA3OS4wOTc2NTYgMTYuNDI1NzgxIEwgNzcuOTkyMTg4IDE1LjkzMzU5NCBMIDc2LjYxMzI4MSAxNS4zMjAzMTMgQyA3NS45MzM1OTQgMTUuMDE1NjI1IDc1LjM1NTQ2OSAxNC43NjE3MTkgNzQuNzc3MzQ0IDE0LjUwMzkwNiBaIE0gNzcuODU1NDY5IDUuNDcyNjU2IEMgNzUuMjIyNjU2IDUuNDcyNjU2IDczIDYuMzk4NDM4IDcxLjE3OTY4OCA4LjI1NzgxMyBDIDcwLjY4MzU5NCA4Ljc1MzkwNiA3MC4yNTM5MDYgOS4yNzczNDQgNjkuODkwNjI1IDkuODIwMzEzIEwgNzQuMzIwMzEzIDExLjc5Njg3NSBDIDc0LjcyMjY1NiAxMC41NjY0MDYgNzUuODkwNjI1IDkuODIwMzEzIDc3LjMwODU5NCA5LjczODI4MSBMIDc3LjMwODU5NCA3Ljk0OTIxOSBMIDc4LjY0MDYyNSA3Ljk0OTIxOSBMIDc4LjY0MDYyNSA5LjczODI4MSBDIDc5LjU1ODU5NCA5Ljc4MTI1IDgwLjU2MjUgMTAuMDMxMjUgODEuNTU0Njg4IDEwLjgwMDc4MSBMIDgwLjAzMTI1IDEyLjM2NzE4OCBDIDc5LjQ2ODc1IDExLjk2ODc1IDc4Ljc1NzgxMyAxMS42ODc1IDc4LjA0Njg3NSAxMS42ODc1IEMgNzcuNDcyNjU2IDExLjY4NzUgNzYuNjYwMTU2IDExLjg2MzI4MSA3Ni42NjAxNTYgMTIuNTg1OTM4IEMgNzYuNjYwMTU2IDEyLjY5OTIxOSA3Ni42OTUzMTMgMTIuNzk2ODc1IDc2Ljc2MTcxOSAxMi44ODI4MTMgTCA3OC4yNDYwOTQgMTMuNTQyOTY5IEwgNzkuMjUgMTMuOTg4MjgxIEMgNzkuODkwNjI1IDE0LjI3MzQzOCA4MC41MDM5MDYgMTQuNTQ2ODc1IDgxLjExMzI4MSAxNC44MTY0MDYgTCA4Ny4wNTQ2ODggMTcuNDY0ODQ0IEMgODcuMjUgMTYuNjgzNTk0IDg3LjM0NzY1NiAxNS44NTU0NjkgODcuMzQ3NjU2IDE0Ljk4MDQ2OSBDIDg3LjM0NzY1NiAxMi4zMzIwMzEgODYuNDE3OTY5IDEwLjA4OTg0NCA4NC41NjI1IDguMjU3ODEzIEMgODIuNzIyNjU2IDYuMzk4NDM4IDgwLjQ4ODI4MSA1LjQ3MjY1NiA3Ny44NTU0NjkgNS40NzI2NTYgWiAiLz4NCjwvZz4NCjwvc3ZnPg0K";
const MOODLE_PARTNER_DATA = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAADECAYAAABDXV/NAACRd0lEQVR42u2dd5wcxbW2n+qevFE5IKGAJEAEkUEgJBOMyTDGROMANjbG4dqfI9eJ4OyL7et0jRPZxmAYsgnG5CByDhLKQnm1cXJ31/dHV8/2zE7aJK2g3h+DdmZ6uqvqnKp665xTp0BDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ+N9BFHvhVIiuKT+6zU0NDTK4hIpdSNoaGgMGZERYscbUySIh76/KCClJlYaGhoaGhoaI5CrSCkeeuihgJRyRHGVioWR38cQl+J477t/OGOCzJlj8jhGTstTQ0Ojn2gE0uHG3KaT/7Zu5JRqXNW3Na7WGHaM9/7bpti0CWCTbv4y2FzXl5u3SVk6OjrE+PHjc3PmzMl6n910003mGWecYY9YgiVPxxQ3Y7920dzGqRPy5ztwpu3IPSS0aPXS0NDo/0hjYNgZMs272Bs/9OvN0nFEn4FIGMXvDVHyfenA5f6/8Cshige1sj8SRd+LkiFQlPym/HtfCQrvDV+5Kw2wwlfWkj8K/4gyH1f/rPz7cmWs/JnoU1ijT13KvKXMQ3vLI8q1gyitTtHnosK9y05UQlS0EAhR2ZAhXZNHqQWk5H3hSmTxh1Xfy+KHFN3TKXkjfZ/IkuuLnu+7qSy5t/+9/xay94/e98WFA+mVqaQegHSKCuovWXF5pL9dZdnnFe7uf77sK4uyZSl9tlMiNSmFaZppwzRWA/cmOzv/On/+/I0jhWT10UJ5E6Y4A3v9t3f5QDRsXNkYNOZkLEnWcrB15ISGhsYACZaw0uTH7Ebbcb+lZKRUE7wY0HtRg2CJbUKwRBlOJ8q/r0qoRgrBKveZ+rQuMqUJlo/mKKJQxEaK3m9LguX/zk9+/LWRJQxnKAmWrECwZLnnSVnh2b0yE0IQCAQIhUKk0+kNyWTPFw7af/9bRgLJChQp1fcxxBnYa7+zy8kNYeMWAYEtScsSQhgIhEDHYmloaAwcjpQyl8tpgqUJliZYmmANFcGSuVxOplIpJxgMTmxuaf3ncy++csYB++598/YmWQE/ueJS5ObLdt01KJ2/WzaBnC1twxABPS1oaGgMiSELhDv5CU2wNMHaLgRL4704rABg5nI5W0ppBALmX5959dWnD9xzz7Xf//73jUsvvdTZHgUzSkopbcv+ZTQoYjnLsQyBqWWnoaGhoaGhMeKZlhBmPp+3m5ubGg1bfkUIIT/wgQ8Y26s8BvTuGNz4ndnzwoY4tjPtONpypaGhoaGhobGDwUin01IITnjooYcCRxxxhLVdCRYscv81nOMbw4YojdXX0NDQ0NDQ0NgBIPL5vAB2Gjdu3Fhw82RtP4K1xyNefNmejs4qqqGhoaGhobEjQ8qAECIMcMkll2w/gnXzzeqNoFlKkOgIQQ0NDQ0NDY0dmWNt32O5DC0CDQ0NDQ0NDQ1NsDQ0NDQ0NDQ0NMHS0NDQ0NDQ0NAES0NDQ0NDQ0NDQxMsDQ0NDQ0NDQ1NsDQ0NDQ0NDQ0NMHS0NDQ0NDQ0NDQBEtDQ0NDQ0NDQxMsDQ0NDQ0NDQ1NsDQ0NDQ0NDQ0NDTB0tDQ0NDQ0NAYXgR0E2holIEQIOpcf0gJ0vH91qDu4zxLf6uhoaGhoQmWhsZ7llxZOWQuVd/1ZggRjrlkSQhkPg35DCCAGmeNmgFEqLH2dRoaGhoammBpaOzo5MocM43gzMOUdamSNUqCMLDbVpJf/iQEI8hcmuCUfQhM3hOkTWUvvPtbp2sDuSUPgRHUJEtDQ0NDEywNjfcqwTKQuTSBKfvQdMqP6vpJ9o37yL31b4xwI04uSXiP44gt/Fxdv82veZHsG/ciwiHXAqahoaGhoQmWhsZ7k2S5Viwc230ZZvnr1Hcyl+yNufJchI4NjgVGoPpvsz1UtpBpaGhoaGiCpaHxXiNZHrGqRLC870qD4YWhfiP7/1sNDQ0NjfcE9OiuoaGhoaGhoaEJloaGhoaGhoaGJlgaGhoaGhoaGppgaWhoaGhoaGhoaIKloaGhoaGhoaEJloaGhoaGhobGexU6TYOGhsYOD8dxCrnIClnFhPu/au9FSQ4yIYru4B5JKQyE0LnKNDQ0NMHS0NB4H0FKSayhAWEYSMfBEMI9dEiRJaOfBMsjVBKQjo1l2ViWheM4bno0Qxv+h1ueriw0qdXQBEtDQ0Nju0AIQTAY5OmnnuK1114ln8+7E7OkYoJ8UfGdxDBNwqEwDQ0NjBo1ivETxjNxwkTGjB1LU1MTtm2RyWSQUmqiNQzESkpJKBTCMAzy+Ty27WCYup01NMHaMTpxoTOr1arWAQ2NHXZCDgZD/P3vN3Dfvf/CNANDdl8pJUKAaQZoaGhgwoQJ7Lrbbuy3337MnjOHUChMKpnURGsIZWkGTCLhMOvWrSOdTjNp0iQaGhpIppKYuo01NMEaWQRK+taoHpkKCDCEJGhIHClI20KTLA2NHQyOdIjFYrz80ss8cP/9NDe3DNuz8vk8K1asYMmSJdx3773MmjWLoz94DIcccgiGIUin00NG7t6v5CoQCJLJZvj1r3/N008/jWVZjB8/nvM+eR6HHnYo6VRKE1mNHQ47tMZKwJFgq5cETAFhQ9IQkLQEHVqDDk1Bh4ghkUBX3mB9OsDTW6K83B4mKGSBiGloaOw4nd8wTN5++61e0uU4w/ISQhAOh2lqaiIUCrFkyRJ+8+v/5cc//hGrVq6iqanJDbLXGCDBgmAwyO9+9ztuu+028vk8UkpWr17NZZdfxquvvko0GtVtrLHDYYdZdkl6rVJCEamgIQkKiSnAAXKOoMcyaM8F2JI12ZQJsDHj/tuWNWnPmSRtg00Zk6CQfH1uG6aAXO8GJA0NjR0Itm1X/b6/gdJegHW5z73votEoAG+8/jqXXXYpH//EJzjqqKNJ9iQRhh5I+tve4XCYFStX8OSTTzJ27NjC5w0NDXR2dnLnnXey7z776MbS0ARrKOH4CFXQgJApCQiJDfTkDTamgrybDrAqGWR1Ksi6lEusOvImaVtgOQLH+72QGAJ6LIODx6T52u5tTGvI05030GOihsZ7c/Lur9VDCOG+DKMQOuAnV0DhnrFYDNu2+b/f/56uzi7iH/4wyZ4eHZTdTxmZpkFnZyf5fJ5wOFxoa8dxCAQCtLW1kcvl9K5CDU2wBtXZ6LVSBQTEAq6FKi8FbVmTVckgS7pDLOkOsSoZZFMmQNISWNLteAEhCRhgCknEkBim21FNIUnbBo6EC2Z18IkZHQhcd6Gp+6yGxntzcAsECAaDFa1S5WDbNvl8nmw6jWVZGIZBOBwmEAiUJVqGYdDY2MgNN1xPQ2MDH/rQh+ju7sY0TS2AfhLbSgRMQ0MTrEHA8ZGqaMDBEC75eb0zzCsdYV7tCLOsJ0Rb1iTruHltgoYbqB4LSFTWmyKC5sVnGQLacyY7xfJ8ZdetHDo2Tbflki1NrjQ03nswDINkMsnCRYs486yzSSWTboB02TxYfQlWOp2ho6ODdeve5Z2lS1m6dClbt24lEokQDAaLrGLubkNBLBbj2muuZfq06cyaPYt0OoOhTeMaGppgbQ/4CVAs4Lr+OnImL3VEeaYtykvtEdakgqQtgWm4gethQxI1ZRGRcioscAzhBr535w2OnJDkS3PaGRex6FBWKz32aWi8d+HlUxo1ejShYLAKwRIl5ExgGCaGYXDggQdiOzZbNm1m8eLF3HffvbS1tdHQ0NCHZJmmSTab4oYbruc73/mOJlcaGhrbnmB51qqQIYkGXNfdKx1hHtsU45m2KGtSASwpCClCFQ4VEyq7DouxKSBlCUKm5Mu7buW0qV3kHKFdghoa7zOSZeXzBVdf/UflWL5s4tA6ahSnxuMcethhXHP1VTz77LN9SJbjOMRiDbzxxhssXryYwxcupKdH52/S0NAEaxsRK4Co6br21qcD3Lk5xn82NvB2V4isIwj7XH5OPwhV0aAKtOcM5rbk+OpubezZmqUzZ7hJAzW50tB4X6EQtF7IKlzfWYReTJAQYFkWnZ2dNDc385WvfpX/+93veOyxx/qQLJCYhslDDz3EIfMPHVRQtkfw3H9Foby9//jqNYwE1XOB9uc5hVg1USyDkQZPdvXk15JSIh3H/bdXfQrvhVCatJ3qKaXEkRLpTbSid0L0ZCEYPjm4z3f6/QyvXb25W5Tpk5pg1UGsGhRxeqsrzL3rG3l0U5RN2QAB4br9IqZLqpxBxjQGBJw5rYvzZ3bSEHDoyPXHalUhtfv2DLQUwjeyipIyedlUt2cgaO/E1bd8hR6+vadZ34jop+LvOTrRK4tySw8dMDxgkmaaJrlcDkc6fOrTF/DuunWsWrmyz663cCTMO++8w5o1a5g6dSr5One/FUiJdCd8M2BimiamYWAYpo8gun3LcSS2bWPZliIKQ0u4HMchFAwSDAWxbZtsNlv1/t6OTcMw3N8FQximgZSSTCaD7VkRS+s7xISpnjZwpIOBIBqNIoBsLodt22WJluM4OFISDAYJRSLuZgeP+Cry6b3P53K99xLGNuFajuOAhGAwQCAYxDTMQh39ywlHOlh5i5yvrkNFZBzHIRgMYgZMbMsml8uVXbz45wbHkYVjrkzTxBACR0pyuSxW3kK8Ryy/w0aweomVg0TwYnuY29Y2sXhLlKRtEDUdWoJOUbLQwU6hOUcwpTHPBbt00BBwaM+ZhIwqNxZGLylwbJA22A4Sn3IKAwwDhNl7rXSGcbIS7vNczQU7j7Qtt2weqSqUK4Awg2Cosknplm3YZxyj93mOjbTy4Fjq2bKXbAkTYQbACBbXabjJTZFcHSUvp/h7w3D/9cig3AGTGArhq4PjysK2etu4cB6UgTACrp6oAXiHrfN2hGEYWPk8jY1NnHbaaVzxP/9T9pqenh6WLlnCLrvsQjabxawykXlWlEAoSDgUwjRM8vk8Pckeurq66O7qIplMkctlCylrwuEwjY1NtLa20jqqlcbGRkCQyWTJWzlMwxg00WpsbGDTxk1s3LSR1tZWpk6dSjabxbGdPve2bZtgKEhTUxPZbJaNGzeyYf0Gunu6iUQizJ07l+ampkLGe9uxCYVChEMhUipDey0rkndN0bNF8RQei8XcHaDZbMVdnI7jEIlEsC2LJUuWYNs206dPJxaLFcrSSwAdotEopkoV8caKFaxevZpNmzeTTCZdQh0K0dzSwsSJE5k2bRpTpkyhsbGRTDpDNpvBGKbdpI7jYJomjY2NOLbDli2bWbNmDe++u462tjZS6RRSOoSCIZqbmxk/fjxTpkxl0qRJNDc3k8vlyGaybhsOQlW8fGVbtmxh06aNNDU1M3nyZHL5HLZl99EVx3HPlmyMRcnn82zesoXNmzbS09NDMBRi1qxZNDY0klGEXhOsCsQqFnD/eHZrlFtWN/Ps1gh5R9AQcInVUJCqkvU5IUOyvCfIBc9M4uK5bezdmqGzXNyVYYLjIHNJsHJgGIhgDBFuQARjEAgCBjh5ZD6DzCV7rxUCghFEIOL+7dhDO1naeWS6GxwbEWpANI7BbBiDERuFCMXAMN0yZXtwkm04PZuRqU6X4ATC7jVDWa7SdpMSmUuBlQUzgIi2YrZOxmgYgwg3IYJhd6LPpXBS7Tg9W5DJNmQ6BYbpls8MDg9JNUyQTm/5hIEIRiAUQ5ghl1Q5FjKfReYzYGXcMgRCrtx3lFWTR5LyGWQ+rVJhRzAiLRjRFkSkEREIu3pg55HZFE6mE5nqQGa6CteLYHT4dOU9CtM0SadTzJ27J9OmTWPNmtWEQuE+1piVq1a67rUqE6RhGDQ0NCCEYEvbFl5etoy333qblStXsHHjRrq7u8lms1iWVXR/IQSBQIBYLMbo0aOZPn068+bNY968fRg7bizZTIZ8Po9h9H9y9xJ/3nTTTSQSt5FKJQmFQixYsIBPf/rTBANBbMedOD33WHNzM+0d7dx33308/vjjrFy5kp6engJ5nDx5Ml//2tfYfffdSaXSRGNRNmzYwN/+9jdWr16t2jTdJ6WG4ziEw2FWr17Nf/3Xf+GUtqdvApZSstNOO3HO2Wczbdo0MplMH9LmkatVq1bxy1/9iqVLlyKlZOLESVz0uQs54IADSKVSAASDIUKhIK+99hr33X8/L774Ips2bSaXyxZk4D3XI4CxWIypU6cyf/58jjziSCZPnkR3T4/Sg6EhC56Vs6mpie7ubh5+6GGeeupJli5dSkdHB/l8vsjoIH0ENRqNMmnSJObN24fDDjuMGTNmkM3lyGYzBctXv3UlEubuu+/irjvvJJVKEQwGOeCAAznn3I+6umLboHQFCQ2NjXR1dfLE44/z7LPPsnbNmgJZBRg3bhznnf8pZs+Z41pNNcHqJTiOdGOsAobkxfYI/1jVzOK2KLYiVp4b0B4mA4YEIqYb3/XVF8fz9d3b+NCkFF1WACHtgrtNpjoQwSjBnfcnNGM+gSnzMEdPc0mCRwCEj2Clu3C61mNtWkJ+zUvkVz+PvWU5SBsRaXZVeTDWACPgTpS5FEbzBEJzjiA0exHBKfMwRu2MEW0p69uXVhanexP2xrfJrVxMbumjWOvfACc/NOXyW3yQyHQHGEECk+YSmr2I0IyDMcfPwWga707o5UzB6Q6c9tXk175Mbumj5Fcuxuna6JKeYFRN7oNUCMN0SV2qHYJRglP2Jjj9EIJT5mGOmY6IjXaJlmG412WTOKmtOFvXkF/3KvmVi7HefRWZySAaRo/ctP7KWiXTXYDEHD2N4PQDCU47iMCkuZitkxHRVreu/qHJzuNkunG6Nrg6vPJZ8iuewtq0BGzL1RXVNhr1WQ8aGxuYPWcOy5YtIxyOFBEDwzDYvGkzlmWVXYVLKYlGo+RyOZ555hmefvopXn/9ddra2rBtG9M0CQQCmKbpuqZCobL3yGQyrFmzhuXLl/Of//yH8ePHs3DhIk488QTGjh1LT0+yX+f3ufVq5L777uPKK6+kubm5QHoSiQTBQJDPf/7zJFNJddB2kGAwyD3/uoebbrqJNWvWEAgECIfDRCIRhBAYhsHatWv55a9+xS9/8QsikSjt7e185zvfYcWKFUSj0cKB2cFgsMy60z3r8a23366xPhW8+uqrvPzyy/ziiiuYOHEi+Xy+iAiZpkkqleKHP/oRb7/9Nq2trQCsXr2Ky3/wA37z618zaeJEgqEQmzZv5qqrruLhhx8mk8kQiUQIh0NEo5GKZMNxHJYtW8abb77JHXfcQfzUUzn11FNBCHLZ3KCz/Nu2TTgSQSC4//77ueOOO1i5cmXhKCd/u5cScq98q1et4p133uHee//F/PmHEo/HmTR5Ej3dPf1yyzmOQ0NDjEcffZRrrr6ahoaGgvweuP8+DNPgU5/6NOl0WiWMNQkGQzz26CPceccdrFu3DtM0XUtmOFxw7W7atImrr7qK//7OdwiFQzj2jm1lHxKCZUvXehQLSt7qCvH3lS08silGXgoaAw4oYrUtQkAc6ZIsy4EfvD6eZHY9J4xvIxtqBTsHdo7I/mcQnX8ewan71rhbCBFqgIYxmGNnEJx5KNFDQOZS5Fc8Rfq5f5B9836wFaFxrP5PmNJBJtswx80ietC5hOedgtm6U1myUkREhEAEwpijpmKOmkpot6PhmG+RW/EU6cXXkX3j3t7Js7/lKiV/mS4wAoT3PoXoQR8jNHN+rxXFT2+LBOy6CY3YKIzYKAI7zSN68MexO94l+8rtpBdfj735HUS0pdAOAy5fuhMRihE9+GNEDjxHybXKYNY4DnPMdJi6H+F5p7jGoDUvkH7qKrKv3Al2vtf1NjKYFRgGMtMNwiC021FEDziL0KzDFZGutuQQYAYxGkZjNIwmMGkukXmnIq0c+RVPk37ub+RevxeZyyld2QYu3PcChGDSxEllJ1ovD5d/gu+dmCTRWIRXXnmF6667jtWrVhUsNbFYrNcyVPKqZE0zTZNw2F3cdHZ2ctNN/+DRRx/hk5/8JAsXLiKZTPZxpVUjKblcjvvvv59oNEow6FoghBCMHj2aJ554gtPPOJ3m5mYCgQCpVIqf//znPPLII0QiEVpaWgoTuVdux3Fobm5m7dq1vPHGGxxxxBHccustrFy5knHjxhXaqFo9PetLLWtKY2Mj69ev56677uILX/hCkatQSkksFuPBBx9k6TvvMHr0aCzLHRebm5vZunUrDz74IJ/73Od4/PHHueIXv2DDhg00NTURDocLdap1NFM4HCYajZJKpbjyj3/kxZde4qtf/SqtLa2kM+kBH1ht2zZNjY2sffdd/vjHP/L8888TCoWUe5iaulKY0cJhItEotm3z738/wPPPP8dHzz2XI484kmQyhUTW5ZoTQmBZNo888gihUKhIV1pHjeL5557jpJNOpqWlhYBpks1k+Muf/syTTz5BKBSiqampj64ANDY2snnzJpYte4d99tmXVDK5Q8djDZpgSaA15LApY/LnZc3cva6JnrxBU9AhioOjunapm65aDquhIFnhgEGys4vFo07gw0eOIf2vn2KOmkLzaf9DePdjfBfbPnNz8W6dQkFLyIMIxQjtehShXY8iv/JZeu77EbllT2DERvUlQtWIQbYHEQjR8MGvEVvwWZdsQK/7zCuTEMXlKyU1XtkMk9AuCwjtsoD8ysX03PcT8sueQMRG0e8gZ8/al2wjOHM+jR+6mOCMQ8q3m7+clYihqo/ZuhOxhRcRPehcUo//kdSjf0DmU4hwYz+JoPs8mWwjtOuRNB73HQKT96wg17JCLWq34NT9CE7dj9zep9Bx3flIKztyrFbSQSa3Epy1gMajvkpwl8Mq629RkLt/K1GxHotAiNDshYRmLyS/+gWSD/yM3Nv/GTzhfb9ASmINDWUnTCEElm31uggVz5VSEgqHWLtmLb+44grS6TSxWKzIAlJtQvO7pPx/e/8GAgFaWlro7OzkZz/7Ge++u46zzjqLVCpV03oiFZHJZrMkVWJWrzze/bO5LF2dXUyaNIm1a9fygx/8gKVLl9LS0oLjOBXJhzeBZjIZALZs2UIgEMC27bqD3es58siyLILBIJs3by4EvPvLIISgo6PDDXMoc/SRZVk89dRT/Pe3v41hGLS2tGDZdlG9SslHadk9EmaaJqNHj+a5557ju9/9LpddehktLS3k8v0/8se2bZqbm3nuuWf51a9+RXt7O83NzYXDyEv1xB/o79+A4S+fRywzmQy//c1vWLtmDed89Fyy2UzxztWqZDxbSOJbqiuWZdHd3c2kSZPYsHEDv/n1r1n2zjuFclfVFWRhU8WOjkERLDf7uuTvK5u5dkULm7IBYqZD2JSkbIEjBVIKSimHVAlGGwLDM4gLIchZNi1NDXz1S18gMnVnmqJjCe20F8HpB7kTuVBBzrV8z4UdciU1dxwQEJx+IKM+80967v0JqUd+41oBpKhOsowAMt1OYMJuNH3kFwSn7tc7WXrlqku3PPLlL5prgQhOP5hRn7mF5IO/IPngL5WLLFDfxCmUKy2fouHor9Jw9NdUfJNNb4C9Wa8wittPBVeLSDMNR3+N0G4fpPuW/4e17nWXCNZFstTgkemi4eiv0XDMN3ztV0/5yhFpNxA+tNvRtH7yOjLP31xC0LYDVLydEILGEy8jtvCzFNy+UrpuvbrkIMrosSyQ3+DO+9H6qRtJPfp/JO/7iXtPL05OoyrJqkWISklCOBTiqaeeoru7m9bW1oIVpdwE6V/hexOY53bzT6B+omXbduGIoGuvvRrTNDnzzDPp6e6qK+C61k7BcCTM1q1b+d73vseaNWvK1qG0Hvl8nlgsxowZM8jnLfbYYw/++c9/FqxwtQimV+ea3cUwyGQy7D53bh83WS25RCIRXnn1VR74978LxyNZigR4z7ZtG8uyCuTNMAwCgUCBYJSSX8uyaG1tZdmyZfz0Zz/l8ssvHzC5euLxx/mfK9xNFU1NTX0IileGcjF7AdMkFA5jmmaRvnhEsKmpiVtvvZVsNsf5n/oU6XRqCLqGG8vX3d3NL6+4gjVr1tDc3FyWWHltYhgGlmURDoWZMmVqWQvw+4pgCcCWgolRm1OndmM5gkPHpsk5AltC1hHkHUFOvfLqZQjJlmyAO99tHJ55yTDo6OjgsksuZeepO2NbeRoO+1TvRGoM1nAnfLuxbMCg8bhvYzSNp+eu7yIiLZUHXyOATLURmnMEzWf/wbV6OVbxDq/BWjwKREvQcPTXCEzYja6b/8t1fdWaOIUbCI7j0Hzm74jsEy/sFhya8rm7C12SahOcMo/WzybouvHz5N68DxEbU5tkCZCZbppO/QnRQz7RW5/BlM8jttImNHsR5qidldVtO5mnDROZS2HERtNy9u8JzjxU6ZStdrQyeB3274oFYgs/R2DCHDr/fpHrTjdDmmRVISJd3V1lLQiO4xAJRTBNE9uyCtYjr7mzWTcAuzRuy1v5Z7PZwi6xUChUcMEA5PN5MpmMCrYWRFTqgNLM8q6FooXrrruO6dOncdBBBynL1MD7iGma2LbNz372M1atWlWWXPnrkc/nsZUF6KLPfY6dd96Z9o52FixYwCmnnMKdd96JUO0QMM2ybkDXFWW5Vrha6Rcch6OOOorjjzuOZDJV93mQXtb/pUuXEggECIVChU0IUkp6enoKxGbMmDGEw2Fs2yaZTNLR0UE2my24VEv1wbIsWlpaePHFF7nxxhs5//zz6ezsrCuo3IuJe/GlF7niF1cUCF2pRU1KSXe3u2NzxowZTJ06ldbWVoQQdHd3s379elavXk1HR0ef4548wtXa2srdd99F66hWTj/9dLq6ugfszvTc5FJK/vCH/2PVqlVlyZVfVyzLKujKGWeeyU477eTu6hRihw5YGLSL0JFw3ORumjbF6MybzB+bojNvYgoQQvZxVjjSzYn1WmeY29c2YYihbb5AIMCWLVv4+LnncupJJ7ksPRAstm4M6UjrkQWL2IILcLo3kHroN4iGMkTBCCBT7YR2+yAtH/urGxju2ENA+CoRLbdc4b1OpCXSROd15/WSuXIEUAiQNtKxaPnonwnv/kGwLTBNVc8hLaBbb8fGiDTT+vGr6Lzhs2RfuwsRG12ZZBkmMrmVxpMuc8mVV766GYekKFNg6e+E2zbm2BnbcfY2kPk0RuM4Ws//G4EJuyq5BQCzukWlD9lU1tZqBNTrE7ZFaNejaP3ENXRcfW51XXmfw3EcVq9eXdEi0jqqhWAwiJXP+3aQuWRh33335Y477iCfzxfIUSqVwnEcxo4dy957782sWbOYMnUqY8eMoaGh0SVYAnK5HN1dXbz77jpee+01XnrpRTra22nwxeL4JznTNLjmmmvYY489ChaMgbBzzyJx7TXX8uKLL9Lc3FxErgzDwLZturvdiXnMmDFMnDCR8RPGs2jRIg455JBCGgTbtvniF7/IIQcfzJKlSwkFg2zYuJEHH3ywcKi2Rx7y+Tzjx4/ngx/8oBvj08c63qv706ZN49BD3QSvXjxQf+rnbSbwB8QbhsGCBQs4fMHhzJq1C62trZiqjKlkig0b1vP8Cy/w4IMPsmHDRpqaGsuSrObmZu68804WLVrE1CluyotqYvDKs3HjRn71y18WNhX47+25dIUQHHvssRx51FFM23maS1QLaydJLp9j06ZNPLN4Mffc8y/a2rb0SZLrWcpuvukmdpk5k3nz9iGZSg3oyCdPVxK33sIrL7/cx+LmWduSyaQbs9XaytixYxk9ZiwHHngA++67X+8u0B187BmSmb0nb9CWMwkI6LEMUpZQZ/0Jb4gvImR5KWnP9R64PBRN6CUD3LJlCyedeCJf+8r/K6xC6rZuFCYoWbzKr0nKlFXGsWk85mJyy55wXV6hWNGEJ7PdBKfuQ8tH/+iSK+nUb3XxpzWoFvNUjsTYFqHZi2g+87d0Xn8BItxQ8XqZTdJ85m8VuVIWr7rdJbK4jPWQWZVaAcOk+ezf0/HnNvKrnlEB13YZgrqVyEEfJXb4hS4BMOtUYT/BFhU+LyKacvu4B4UAx0IEIrR+4poSclVDP4RRTIS9Ovh1zLuurIkiAHae4IxDaD7jN3Re/ylEuAkd9F48eQQCAdrb23nrzTeLEo36CdbknXZShKZ4xZ5OZ9hjzz05//zzuemmm0ilUoTDYfbdd18OW7CAPffYk7Fjx2IGTDfGxrZxnN7M6EIY7DR5MnvuuRfHHHMM6zes5/bbbuO+++4jFAoVWcYcx83jtGLFCh566CFOPvlkurq667bslFobUqkUzz3/HNFotMhlKYSgp6eHhoYGjj76aBYcdhizZ82mdfQoIpEIjuOQLligXAtfLpfj0EMP5bDDDiMSifDSyy9z//33EwgEisZ0j2B9+lOf6usy8gXve6QqlUoVyOVAZOtZ6rq7u5kzezYXXngh8/bZB4Ebc2TbNo66rrW1hXHjxrLPfvtyysmn8Ner/sp9991HQ0MjssTya5omnZ2d3HPPPXzhC19wA96rjI8eyfvTn/7E5s2b+1iAPHlMmjSJiy66iHnz5pHL58hmcm6KDF+iUSEE48aN47SPfIQFCw7nT3/6I88++6ybQ8tHsjxZXnfddewya7Yiu86AdCWTyfDSSy8VNgh484thCFLJJJFolPnzD2X/Aw5g+vTpNDc3EwqHkdIhnUqP3J3c24NgmQJsRxANOhjqIOVKxFeo64Nersqh8KYIcBybLe1bOf200/nOxRcXKUzdBKZ0gqpnUiqalN1JquHor9F59cd8FXTzEYlwE81n/Z+7M7Fel5t3Xbm4LE/5a5XNdElWeI/jaTjqKyTv/1lfC5sRQCbbiC26iMi+pynLULC+diuUoUwmfMdW+aVEdWubdBCBMC1n/56tvz3O3TFnBnyEzYB8CnPcbJpOulzJpE7S7CMZMpd00xwIgdEwtpeglcpje3VwYSBzXTSf80c3aL8f5Epme8i+eie5dx7Dbl+DtHKIUAOBCbMJ734MoV2PUi5gp3LOLzOodOU4Go74Msl//xzRMHZwO1HfQ/BW+vfffz+bNm6ksampj8UiEAgwa9ZsbMfpo0aGIcikMxx/wgnst//+rHt3HaNGjWLa9GkEgkFymaxLEtRuLqPM5pt8TgIZQDJmzBi++MUvMnPmLlx55R/6pDrwLB+PPPIIxxxzDKY5OAu+P1eV5w5Np9MsWrSIs88+m1122QWkJJvNFQKdgaIzGb0xOZlMYts2+Xze3e1YYeFsWRZdXV3kSrPil+yOLI1PG9BcpsjV/Pnz+e+LLyYWi9HT3Y0UYJScqGGpsjsq2eY3v/EN1wp08819yItHdp955hk2b95MY2MjlmWXHWZs23UNPvzwQzz99NNlyVU6nWbGzJl8+7+/zdgxY+ns7HTHNGEUZ2lXw2c+nyebydLS0sI3vvlNfvPrX/Poo48WldMr48qVK3nggQc47bTT6O7uqkoE+6MrUkqSyRQHHngQJ59yMtOmTUcCuWy24HIFiSGM98ySbkjzYJlC1mwYIbxUCg6BOq6vRawEkMyDGYrxta9fxCfOPrNIqP0hVzKXIr9yMXbbSqRjYTSOJ7jzfpijptZZINedEp5zBIGd5mGtV1YsYSCTHTSddoXreqpr0iwmBvaW5dhdGwopIcwx0zBio+sngKZrYWs48svkljxMfu1LLtEr1D1JYPIeNBzzrfota77nOqmt2G2r3JQOZhCzeSLm2JnFmcNFDZLlWBgtk2k88VK6/nYhItaqYtxcxZFWlsbjvq12HNq1E4P6ypd5KUH25QTWpqUueQOMxrEEdzmM2PzzMMfNUtcL2F7p7QwTmWonsv8ZRPY+uT49UcQw++Z99Nx1Kfbmd9w6mwG8gPj8sidIP30toRnzaTz5BwQmza1O8FVesYajvkJ2yX/6WmPfx+SqsbGR5cuXc+fttxNROZzKWVxmzZpFLpstu8VcCEEymWTMmDFMmjipcBRNJpMpTJCl5w4W/ePT0Xw+z9atWznxxBPZunUrf/vb9TQ2NhVNmuFwmBUrVrBy5Up22WXWoHZo+cdWbxfgl770JU468STyVp6uri4MIRDCQBjVF7ielck0zaoWJ887YZpmVYI16O6nrEJz587lO9/+DqbhWuYKmwM892uJxUeAqnueT3/606xcuZLnnnuuyA3nEd1Nmzbx1ltvseCwBXTnuxFlxm3TdMtx6623FrlMvWfmcjnGjBnDt775TUaNHkV3j2uVrHZqmv+4JyNg8LmLLmLz5s0sWbKkyCLpkaz/PPhvjjjiCKLRiCJ3YlC64u0c/NjHP8EHjzkGS5Fqz2Hdu5FBvqcM5oHt8VBHQmPAIRaElG1ioA6qrMPfKhSxkkDaFuQdgz2berhoX5v5xx2olEzWnztDTcLZ1/9Fz92XYm9djVSrdSEEItJC9JCP0/ihi6ukSyi5n2ES3u0orDXPIyLNOJkugtMPInrgOS5hqEVefGQkvfha0s/+DXvzcmQ+5X5nBjBiownNnE9s4UWupaMmyRIFS1XDsf9Nx5/OKGa9do6GY77p7jash7woK4i14S1SD/+G3PIncZJb1Q5NgQhGMcfuQnT/M9xYKS+Wp9rArmKyIvNOJfPcjeTeeVTtypTITDfBmYcR3uO4+gigag+7fQ3dN3+F3DuPgBFEBEKF31pbVpBf/waZ52+i4aivEFt4kSrjwOJUBmm6cvOWxUbTeMw36wuwVyQp/cz1dN/yNTeTf8MY+qTkUG2eW/E07X84hZZzriS065GVdaZgjQ3SeOy36fjLme9rYuXtEGtqamLTpo38+n//l2QqVXB/lbpGDjzwQEaNaqW7u6fIclM6mefzefI51+3lkZH+UgZv4uzs7OSUU07hqaeeZO3atYRCoSKXVzKZZOnSpey22+5k0ulBbQjx5626+FvfYtGiD7C1fWuhLEWkcAeTczgU4otf/CLhSJhkT08vcamDnDm2jXQcPvrRj/LKK6/0mc88Uvr2W2+x8PCFZcOLvMD2hx56iGXLlpXdMWjbNhd8+gImTZpER2cnATNAvazEMAxsyyYUDfHJT57HJZd8v88GiWAwyMYNG3juuWf54AePUXF1gzu43LFtPvvZCzl0wQI6OzsKZ25KH3F9L2JII77rbSZHCmIBEPkUW9o7SKVShaBEb6VS+vJIVdYRdObdOK/ZTTm+NXcz/3tQO3uKZWz6bRynY527yqlntS3dtAi5dx6j87pPYXeuR0SbC0kZ3fxRkHzgZ/Tcc7lyZdVXy+D0g5SLTYKdI3b4ZxXJqDH4eKukbA+d13ycrpu/grX+dUC6R+eE3WNQZLqTzIu30P77k0g/c30htUJtC5tDaOahhOYsUm64IDLbQ3DaQW5+sHrIiyJgmZdvp/33J5B+8Z9uss9g2C1fyI3xsta/Tlfi63T85SycZFtvbFMdiC36fDHZdCxi8z9Z1EY1yVXHWjr+dDq5ZY8hGscios0QCKldeCYiGMZQhKT7ju+6JKVw/23c6Q0Dmekist9HMFqn1CbMSk65t/9D961fR0SaEKGo2gFq956/qM4oxLHdHFeORecNF2C9+0r1fFeersw6nNCcI1xdMcwdboArl7SznpebY8i10EQiEZqbm3n55Zf4wQ9+wLp16/qQK+jdMXbU0UeTzdbOd1SvS6tW0lFv4m5sbOTwww8nm832OVgZYNWqVUWEezAEK5VKceGFF7Jw0SLa2tpqWqFGOkzTpCeZ5Mgjj2Tu7ruT7En2O1bNMAxS6TS77rore+21V9HZhp4cTNNk9Zo15Ctk+RfCdRE+8sgjfVJNeAlsDzlkPofMP4Su7q6imLX+WurmzJnDggUL+pTT7f4mzz7zDJY1uFQJnjvzrLPP4bAFC+jo6Kjr7ElNsEpvJCSWU3v95Q4GOcLNY7n8J7/is+efx1577UVDQwPZbJbOzk7a29uLXh0dHSRzDqaAGY15TpvazU/32cSv99/IyTv1YDsOqUALsvNdUo/+Xz8mcpeUJO//iWt1CccKk1HhJcBonkzqqb+6x9DUSsKoJkVzzAxEtAUn24M5YVdCu30QRdvroqldN32JzKt3YTRPdM/J8ybVQg6kgLvbzjTp/udXyLx4S2/AeC3rGFJZ01QyPitHZP8z6yOQ3sT+zmN03XiRW6WG0SrHliw6WFmEYhhNE8gteYjOa89H5tLUTHiqLF2hmYcRmLKPe4SQlcMcM5PQnCMLZKRW+0k7T9c/vojdtsK16tge8fDIkyqHyolmNE8g9dRf6b7tW71xStvSeuU4iFAD0QPOcssmapFwgZPaSnfim+rcwToItmNBIILMZ+hKfEMlU62Ss03JKXrIJ4Adzz0ohMBUR87U+/K26ccaGmhqco+KWb58Gb//3W/5+c9+RvvWrUUuFf8EnUwmOeGEE5gyZQq5XP/dcB6xs227YDUrt+j07uslmnQtHJJcLsfuu88tS/4Mw2Dz5srH9/SLiPT0cOSRR3LCCSfQvnXrgCb5kWq9OvLII902GqjFRlmA9t133z47GT2CtXXrVrKZTB+rkLdzcN26d3nrrbf6yNGzLp1wwvFuLq5BWAkNFdu2aNEHiqyd3nM8t/KmTZv6nBHZH3KVTCY56KCD+eCHjqGzs5OAafJ+wpD0DIkbtO7Iug5kcLfmN4zhgIPmc8BB8wFo27qVdevWsX7DBtrbt5JMprBsm0g4RMuoMTS9ej1jNz3JpOYwjaaFLSFtG4XDnA1pQbiR3JKH3OSMwQiFFMpVrBzW+rfIr3vdjeuxrfKTjCEgnyb7xr/c+JU6Yp6MWCtGtBWrcwPhXY/2ud7M2i6fxdeRefl2jOaJbj6iSq3uWK4lJtJM9x3fJjj9IMxa1g8VjB6atRBz9M7YXRsxmicQ3u3oIoJYWdICmel2iYhhugdj21blNrYdRNMEcsseI/mfX9J47H8r4mpWtywaAcJzj8Va8wLSsQjtcqi7+7FmG7oEMPPMNeTeeRSjaYK7G7IW6bTzLsl64s8EpsxzCehQ5f6qPdoh8ymCU+YRmDi3thwUyU0//ieXQDaNqyyDMiRLRFvIr3qOzIv/JHrgRyvXUxHZ0OyFmOPnYLetcg/z3gFM+l48VLK7u5CZ3EvLIXxDUekkZdsWyWSKLVu2sGrlSt58602WL1tGJpOhoaGhMBmXko7u7m722WcfTjzxpN7n9WNyR7hBweFQ2HU3SUe5EHNYVs6drA3X4hUMBAgGQ4TDEQJB1yVn2w5SwtixY2lsbCSVSvnSMvROdoMlWF7KgbPPPtsNOn8PWCK8uKZJkyYxc+bMwWURV9bEGTNmlM2LZRgG6VSKXC5HOBLGcXrjmxxHEgqFeeutt+jq6ioKQBeGQSadZs6uuzJnzq6k05leF9tAimkYZDJZZsycyfTp01m+fHlhR6xHBLu6uli1ahWTJk3qu8GgDti2TUNDA6d+OD5ovXtfEyyAoCFJW/UHlYuguwqUjoMZCDBm9GjGjB7NXnvuWfYn2bW/I9WTxyJMZ94oxGKZ/gzhZhCneyN2x1oC42ZVj/lR256tDW9CPg3BSBWvkGsxsta9Xnvy8x4XCCMC7gHDodkL66OphonMdJF6+LcY0ab6dm5JBwIhZM8WUo/8nqZTf1zIMl9pAHAzqTcRnHYg1uJrCcxagNE8oXaMlCIv6Weux9r4Nka9E7udx2gYQ/rpa4ge/DF300BNEgihXRaQCkaRuTTBGfPrbEN3s0Lqib9g9Pf4HcfGiDaTfOB/CO9xrLuJYJukazDAyrjJRJU7tGJwu1R6kk2Sefl2dyOAl46jHxYzI9xI5gVFsCrqs7sYEoEIodmLSG+4EkLR3o0HI9gaEYlEeOGFF3jj9df7sfoW2LZFJpMhm8lgqazo4XC4z66wUovO1KlT+dxFny+4deqZTBzHwRCGS9wEbN68mRUrVrBi+QrWrXuXrVu3kkwmyeVyRSEUwWCQaDRKc3Mzo8eMYdLEiey0005MnbIzDY0NRKNRelT8kGeR8EhEn1xS/bRedXV1cdJJJzF9+vT3jEXC26k4efJkGhsbSaczSn5yQPeybZtRo3pTVPQ9j9Lx5SvrO7wsXbq0jw4ZasGw1157EQ6He5PVFoz2sijIXfb+0fu+5DvHdojGmpg9ezZvv/02kUjxoeW2bbN61SoOnX9ov5vCMAx6eno44ogj2HnnafR0d79v3IJDSrDc3YOwJhWkLWNy/ORk3bJwV5XFRz4UDYZK+2S2h66OLTiEMJB9zjX0T8wyl0Im22DcrBodRClZ9yakrGFuVQHHTnJrL0mpYyUjHQsjNprAxN1rEzNFXrJv3t/r1qqXHNg2ItxE9o1/0fDBr7suu6rk0iU3gZ33Qz7+R4JT9um1HIlANYEhrRyZF252d5XV7UaTKg3EFjIv3UrDEf9Vg2C55Q5MmIPROB67c51rOazV9qoN88ufxN6yTMUc9YMMSAmBCHbHGrKv30f0wLNrt8mQwCVNwSn7lrD0SrJz9SS/5gWM2Cik09nfaQCA3NJHsNa9SmDyXjWtsqFZC0k/8ecdatLM53Jk1fl3/fmdYRhE1RmB3oRYLmO7YRh0dXUxc+ZM/t9Xv0Zra6vr+qkjFYLj2ESjMaQjee6553j00Ud48803aW9vLyJTXoxW6dE4Xpm8cgUCAZoam5g4eVIhpqbcOXn1kr9KhDAUCrFo0aL3lEXC2+U2evRod9ceclDuN8dxiITdjOlewsx6SL5huCR47dq1RdZH757BYLBAsGKxWL8IloMsePml+sOx3R2Dc3bdFXH33WUM64INGzdiV1uwVxxKXXfmIfPn49j2jrjnYWQQLKHmpVfaw3TlDfJyYG1ZNmeVR7AMQd3GUOkgrVyvcolal1v1FtBHeOo4bRx3Z57RMsm19NT6map79q1/K9dMf5YMEgIhnK4N5Fc9Q3jusTXyRCkCM342BMKY42fXObEbWOtfx9r8juvy7M+2femAGSK39FGXYIlaZwVKRLgRo2USTqYTs3Vy3W2fe+ex/hGrkrYUwsBa8wIceDbDPjII13ImQg292eOrprNQh6e37kTTh3+OCEYHlj5BGJDP9Mb3VaqnIl2ByXtgxEYjrUzv6QU7wMQ5kPiges7Fy2azZLNZDluwgPPPP59YrIFMJlNx16D/3gCNTU288fob/OPGf/D6668VrG6xWKwouLnSxOwfK73rM9kMS5csKSQcHeq2zGazTJs2jV122aU30/Z7BF4CWVFIMrzNS1AICG9vb+9DsLy4qFv++U/uufse5VrsnyGkt8sWB857x+yUc2d2dnb6yLSsW1fy+TwTJ05k+vQZZHO5AefSet8TLENAj22wPhOgJ2/QmTMJmxJbvm9Ja5EFy2ya2hsYX1HJ1JZ8O4+94S0wwwOYNF13jvXuqy7BqtYZvMM1myZgRJowmyfW5i4ewXr3FchnINQA0upXFxeBMHbbCmSqQ+W4qmJlU9Yoo2kcRsdaN11DTZKqzrba+HZxktIBsB6Z69lWiuISrEgTRuPY2iRS1TE4/SB3p+oQ6mtVQtc8EWPUFKz1b6icWDvG1mo5BOX0L/6y2Sy5XI7JkycTj3+YhYsWkc/n+uzcqybvaDTCrbfcyj9uvBHbtokpa1kpsauVKNmfsR0oBMHLYZCNl1Zi1qxZNDY00tXdNaCM8BqVZOnmv8pms2V39Xkol/5hKGQbDof76JYwDLKZDLbdf4KVy+WYNm06jY2N9CSTbkD/+/BAiEERLAkEBHTlDXryBt2We2TOzrE8thTv8y7j7gwzoq0+a1yVhhTgpNpxkm0IMzAAZZSF1AR1MBH3/+EmRKQZEWmq+zf21tV9VkF1jyCGiUx3YfdsIhBrrcvEKCItoJK1Vi+jl87BxunePDQHem+z0dVR6S1i9T/at1tzcNU0a7u8Fbk2R++M9e7LQ3cEwzawYA3WjWXbNrmcm5XcNE2mTJ3KwsMXsnDRIlpaWkglk24IXB3kSkqHWKyB6669hltvvZWmpmbCYVGWVEkpiw7BBanWI6IwKbpnDZpFrkRZZz7BgZLVGdNnDHyHnUZdxKSa+zXmc10PpVwrpf+wLAvHkQO5KVOnTu1NHvo+NbcMgYtQkncEtoSMLWjLmsxoyG+3o9xG2LrEzU1UF1V1Y82kle09qLnfwnCPS6lqkSi63M0FJcxQ/TXKdA3OqmflkNlknW0CRiiC8I7sqUOppJVF5tMqQ/IO4MZCuDGAgf7JwT06aRuZ3dXiwGyZvI3TVwxussrn83XsfpJFf0ooSo8Qi8WYNHkyc2bPZu95+7D77rsVAqHdQPL6ZOAmkGzi7rvu4tZbb6W1tbVPbJd3EHIqlSIYDDJmzBjGjRtHa+sootEowhA4Kut7Mpmkq6uLrq4uuru76enpQUqHQCDYxxoxVJNwIBBgwoQJOLbzvtwRtm26WnWCPFzkuVSepmmSz+dVsH6YVMpLK1FnQlPTZOy4cUq/37+6MiTRu4aQBARYjqA9Z2IIN0xQYwBz/LbkBIIRz0HctFWyf3XaEVVPiBG8IlFkt3HsoAOAtxW5sizLjQGZMQPbsoraVvRRmF4RhMJhGhsaaW1tZdz4cUycMIExY8cRi8XUIcVZurvdI07qjUGSjhs/s3LlSv7xjxsLOxJLk0imUikaGho4/vjjOfjgg5m68840NzURDIbcCdC3Y9q2HXL5HKlUinaV4mbFihUsWbKElStXVowhG8zEHwwGaW5pxnZsNIZnrAsGg1Vdr7lcbthIVuniJBwOc8KJJ/Y7GsBL89Dc3Kzydb1/MWiC5SCImpJYwMGSgu68oamVb/CWuVSdrMBNzCmCYfc3AwkkVq4mv9Wh6uW2hbQyKuFknTUKNw1qBBGBYG8Z62gT8hk32ag3A9b6VSCCCMV8O0N3CF8WWDmknXeThtYp620WB6Vy9Yhw4w7RpkIIMpkMc/fYgws+eyFJb4t4HXmwDMM9R0/i7rJyHIt83qKnp0et7D1iVf8oJ3HJyd1330VPT0/Zw3uTySR77bUXn77gAqbvPB3Ltsjlc8oKly/qEu7Zba5LsKmpiVGtrcyZM4cjjzyKTCbDN77xdVatWlXIazQkKuA4mKZJJBwZ1E5EjSprXemeGxmNRunu7i5LtKZMmVJX4k9Z+Y+6CNLoMWM44YQT2G233Uin0/3a0OARrIL+vY9VJTBYpbAlNAQcxkdsXut0zwfUXU8ptGHipDtUY9XOnSVi7vE8TqYLETD7OY+5+a3MUTvX0aF6E4bKTFev269qZ1Dnmo2aUtYOUBeJsPOI2GjMpvF138NJdyrXac49R7CiP18UYoWMpomw7g0I7ghaIhHCxMkl3XxsgXB9IQvC2HYDl0pCKhrG7DDB7YVEoz09/Uo0KkSxXnqEa6A75gpnu23cwEsvvuhmgS8hV6lUinnz5vGtiy8mYAbo7OosnE1o+OPIyhwAbVkWtuXm7nIDpc1hIz+9B/JqDMciy7ZtotEoLS0trF+/vijDureL85Pnnce+++xLKpUcdB6s3o9k0d/ujkWXSKfTKQzR/4SmXoyglO/f+KuhsWBJCBuSWY057l/fgCU1vSpYa4wATtdGX6bs6uRABEIExs/G3rQUgv1N6OjmmgpMmVebvCgi5XRtwEl3Y3duqIOLeNv191QkoP+7HKWVIzhuFzc/Vc2Dn93nOT2bcDLdyOQWRMvk+vJ7Td6T3Jv31T7WqIb8thkME5npxkluxYy2Up1hud8l//Mr7C3LXYvXsJfVfabdvsrNpi93nDgsb6AfKMEaLFfxjj9ZuvQd2tvbaWho6M3OLXqzXZ//qU9hmiapdMo9vFfUX0eBF0MjtGVph54yXFfypEmTeO211/oQllwuxztLl3LA/gcgHYkUclgIFkAqlSo89/24+2/EECzPijVvVIaAIck5uoMXlNgM4nSux+neiNEyuca86ZKe0OwPkH3ljv6xfiHAymK27kTI27ovap/XZ216G5yc+28tq5faORTYaS/M0dNwOta6ByfXO7kLA+wcoV2P9JEhs0pbCGS6E6dzPeTTWFuWEyoQrOqmwPCcD5B65DcDJAIu2TUax9VhCRwaIu5mZu/BbluFOXZm9To67jFCTuc6Uo/9wU3tYFsDXyX252dmcIdK0TBSJk3DMFizerU6EsdP3gwymR4OO+xwpk6ZSndPt0uuBkEobcfucwaexo6kK4JZs2bxwAMP9DnHMBAI8PLLrxCPf9jdMTqca76CpVL39UG14+BXiZBxDOa25JgctcjaQu8eVHopzABOaiv5da+rVULtQ6LDex6P0bITWNn6l89GAJnpJjzvVDdflGPXSFbpPiu/6nlEMIq15iX1eY3kn46NCEaJzDsFJ9vTj3P6VNLV5olE9onXJoCqnayNb+N0b3L/XvNiHSTQPSg6OO0AgpP3VrFsRv8FZwYI73Xi0Jgw6m6fPPl3X6pdR1Wf6KHnY46aioi2IhpGIxpGDeA1WrmlS1+jfP/6XsGoJlcDID1SSto7OnqTWPq+cxzJ9OnT3NQHg1A1KXuTRnZ0dOgcVTviZGwY5HJ5dtttN2KxWFGcnuM4RKMR3n77LZYtW0YkGkEO8UYGb1er1H18BBEsIO/AmJDNwWPSZHQMVh9rSG7pw7VNBaL3EOzY4Z91Y7eMOoKIhAm5FMbonYkdfmHhWJ+qI7EwcFId5Fc/jxEbTX7dq27+LHVOYdXJXUp3ch89DXLp+giMGcBJtRNb+Dn38OVaBFARjNw7j7oB7oGwm529JglU5MwIEPvAF8HK9I9gmSGc7k1ED/qom8Szajb8IWbjZoj8sidr11G5PQMTdiO814k4PZvdzxy7fy/pgJ1z2zefceO/8mmX2Fs5918776ZlUL8ppMvQ6Ldlws7ny34OEIlEhuAZboD00iVL6ejocI980RPlDkfGczk3W7536LQ/5k0INxHp3XffRcAcOvl694nFYjQ0NGCa5pDvQn2/YkjSNAjAknDEhBQvtUdwdL8uTPYiFCP39kPIXFIlkqziJzTcyTN62AXklj5K9q0HFCHJl7ccGAGw80grS3P8Z667qMaZch5pyC35D07HGozG8TjdG8m9cT/RQ8+vfUagdDAaxtB06o/pvPrjblJUI1j+3EQhwAjidG0gvMfxxBZ8VhEgoyZplHae7Ov3uodmByPk17yIvWW5e5xMtTIaJkiH8J7HE9n/TNLP/R2jeaJLGqqRW2Gqch5H44mXK6IptqGeNJBf+yL25mWY42bWkKNrCWk89tvklj2B070JEWqo/+xKZfEM7rwfjSddrriuilEygor8ukRcGAGXYJlBUo/8jvQz1yGirYM4iuj9uMwSGGUsSp4LqLOzy7+uGPBTbNvmgQfuf8+5B99PVhXbdmhoiLBgweG8+uqrRYlFHcehoaGBxx57jMMOO4z5h86no6NzUG5lN7A+Qi6b48UXX8TK55g9Zw7NzS1kMhntjdreFixww3PStsHcliz7j86QtgU62a9KWBiIYG9ZTvbVu/Gyu1enqgJhmrSc/XvCux6J07XePVtRGC558F6ATLeDY9F8xq8J73a0sgzVIi/u5Jl+5gYwgkjHhkCE9PP/cCfoWgk6lbUkvPsxNJ/+K7DySG+npL98wj0Y2ulaT3j3D9Jy9u/VvWskqlLWrdySh7DWveaSUmEi0x2kn7+pQC7qsRw2nfJjQrscjtO5oahchZxTwnDJhp1HJrcQPfhjtHzsr+45i2zDvFRSHYad7nTlUKuOSoZG03hazvkjIhhB5pJQy8IkDDADbmoOO0ts4ecITplHYKd5BHbai8DkvQhM3I3AhF0JTNiNwPg5mGNnYo6fjdE4luyShwZ+9uH7eQwwBK2jRqkt633jat58803y+fyAiZFlWbS2tvKvf93Dyy+/XMjZtaNZb0rr72337+zo6HeqgB0VpumeR3j44Yez0047kc1m+7RLIBDgyiuvZPXqNTQ1NWFZ1oD00rZtmpubeffdd7ns8sv46U9+zBVXXMF3vv1tXn/ttbLnE2psB4IFvbsJ927NYEntJvSpMiIYJvX4la4VpdaZTuoYEhEbRev5f6PpxMswW3dC5tPIVDsy2Y5Md4JhEN79GEZdeDuR/U53dxzWiolSBCz71oPklz/pHpHjWIhwA9bal8i8fIciUDU6lWGCtIkccBatF95GaLejXUKV7nTLl2pH5tOYo6bQdPIPaT3vBt9ZgnVohnRIPfK73vMEpY0IN5F5/kacZFvBVVmdgAhEpInW864neuDZyEwXTqodmU+BlXfzTmV7cHq2YDSMofmMX9N8+q96d+Vt66VboY7/6HX71XLXOjbBnfej9fwbMZsnuL/zLJt+smsEXPnk0259o620nPNHwnsc55Jq79idci/bdW313Pdj7LZVEIjoOKx+EgcpJTvvvLPakSWLLBKRSIQ333yDxYsX09LaSt7K9+7yqmnZsd2cRaNH88gjD3P11VcTiUR2KGuPG4fm0NjQWJSWwCMBoVCIdevXs3z5cmKxGPl8vs81juNg2/Z7hAy46UVGjx7NSSed1OdQbS/tR0dHBz/64Q9ZvXp10akANfNjKWIVCARoaWnhmcWL+cHll7PsnXcKLsLNmzfzpz/9ke7ubtfVrAPdB4yAboJhnjcdxyUw775C6ok/E1t0kTupVTsrzwuGNQLEPvAFood9Cmvd626clJVDNIxyrQujpxUISe3YJLUzL58hee+PXGuH1xmlRASjJP/9c8K7H+0mAq1FMoTrigtO3ZfWT16H3bYSa9NSZGorBMKYo6YSmLSHsgZRH2lR7ZJefB355U8hGkb3uqICYZyOdaQe+jWNJ16qrG2121CEG2k+87dEDjib7EsJ8uteVRY3gTFqCuFdjyKy/5kYDaNVO26njOpSunXsXE/y37+g6dQf17ZIGmaBZI266G567v8J2VfudM+zFJ6lUKqjeCIExs8mMu9UIgee0+tOrqaHjgVmkNzyJ0k/fS1Gw6j63ZAaBQKRzWaZM2cOo1pbSZWxxAQCAf7y5z8zevRo9tprb3q6u7HUAbteUlFvcnSnYIlpBmlsbCJv5bnpH//ghr/9rXAm4Y7mTrMsi1GjRtHU1ET71nYCwUBR/icpJVdfcw277roro0aNIp1OF3ZkmqZJMBgkEAiQz+ffE5YuwzBJJpMce+yxPPHEE7z55ps0NDQUgt49Yr5hwwa+993v8olPfpJFCxdimCaZdAbLspAqnxVSHcclJIZwD3UOhIJs2riR6669lvvvv79wJJRHUBsbG2lra2PlyhXsvffepFIpvStVE6wRDMdGRFtJPngFodkL3VxSTg2Lk2fpchxEMOrujJt2QB9LT8GaUUcZMAMk7/2R63prGNM7WUoHglHsLcvpvvsSmk/7RW0C4z1XxSqZY6Zjjple/rmGUQe5ctMP2JvfoefeH7rWNb8Fx7EQsVZST11FeM/jCU4/uL42dM/aIbTLYYR2OcytbrYbMNycTkXP3847rxwLERtFevG1hOceQ2jOEbXJuIo5M5rG03zaL7AXfp7c0kewNr6Fk+nGCDdijp1JcOf9CU7dt9eNWKu+XjqIro103/Rf6todJDP+CCNY+XyeCRMmsP8BB3D//fcXZXL33ITJZJIf/fCHnH766RzxgSNpaW1BInFsu7AOMkwD0zQQCLq7e3jyySe58847eP2114g1NBTIyI7WPpZl0TqqlWnTprFx40aCod5M5e7uuSivvfYaX//61znzzDOZPXs2DQ0NCMOgJ51mzdq1rHv3XWbMmMHcuXPJZDI7uM64sVihUJALL7yQiy++mHw+TyAQKJAgj2SlUin+91e/4uGHHuKDxxzD3N3n0tLSghlQfVupg+3YpJIpli1bxuLFT/Poo4+yZcsWGhsbC/fzW1aFEMRiDe/7swQ1wdox7FgqJilL598/x6gLb8NoGFPHpC56E5RKWeya8WKI6oFtgRkg89zfST3+R0SsjCVCTe6ZxdcTmLQHsUM/5bqH6onr8Uhan/KJ+kiLageZ6aLzbxcisz2uFa1PILVrlem6+cuMuugutw1rBfV7lhyvfIbZe9yPlL2/Ly3ndjytXARCbh0vvN0lrTWJpFEgkua4XYiO26V6W5erbzl5pDvpuO487M53e9N/aAyIRORyOU486WQWL15MLpfDNM0CifDcPrZtc9VVV3H//fezzz77MnvObMaPG1c4ciSVSrFp0yaWLVvGG2+8werVqzEMg8amJl/yUlGYIHeY0VFKgoEgBx54IE899VSfsjuOQywW4+0lS/j+pZcyZvQoGhubEEKQSiZp7+gotOlZZ53F+eedRzaXw9iBrS6G4cZizZw5ky9+8Yv89Kc/LSTM9ZOsQCBAMBjklVde4eWXX2b8+PFM23kaEydNdNsISKaSbGlr4921a1m/fj3pdJpoNEqTT2/81tStW7eycNEitZMxgzHMObc0wdIYglHE3Slmb15G5zWfpPW8692M5rUsFB6xEAPIk6PilzADZF+5g65bv6EsQxW6i+MgYq303Pk9jEizG9vlTci1BquBHt3iTebZHjqu/STW+tfVLjWrQhtGsdtW0nnDZ9zYrmCkPuuTv3xeIk+1e7Dcc/qfP2vo9IRAGCfZRsc1H6f1Uzditkyuz61cIJKlq07ZK8Oq7SSLLFed152PteYFRFS7BoeCYE2ZMoWPnnsuv//tb2lqbi6QC+9fwzBobGxk8+bN3HXXnQghCIVChZQLlmUVYpBCoRANDQ2FidYwDGzbTTIaDoexLGuHIVmGYZBKp1i4cCH//Oc/2bp1a5/z9jxLFkAymaKrq7vw21AoVAjIvu6669hrzz2ZP39+7xFJOyhM06S7u5sFCw4nlUrzm9/8mmAwSCgUKrKASikLuw07OjrYtGlTH+IkhCAYDBIMBmlqbkaqmC3/90II2tvbOfTQQ/nMZz47oOB5jRLd1k2wDeFYiGgL+dXP0f6Xs9yYKiOgAo2HeI3g5ZpSMU2dN37eDeCuGmSv4h5CMbpu/jKpJ/+idt6JobdeSFkgRk7nejr+ejb5ZU9WJle+eoloK/llj9N53Xmuu88w1W/qzSpfYSejVyZh4KTat18wt2Mjwo3Ym5fR8ecz3aOT6tUTtTOyXJB71eN31IHOGAHyKxfTfuWp5Ne+OOLJ1Y7iEjMMg56eHo4++oOcfc45dHV1FQ5Q9tfFcRx3EmxqorGxkWAwWJgAQ6EQjY2NNDU1EQqFCoHNpmmSyWSwbZvzzjufcePHD3hXYj1B0sNBQPP5PGPHjuXcc88llUphGEZZS5ZX31AoVEQ+bdsuxKC98uqrRRbCess/lHUbqnb0SNYxxxzDt771LUKhED09PX3OnPTaJhAI0NDQQHNzc9GrsdHdROAOL3bR803TxLLcA81POvlkvvKVrxAwzUGfCKDzsGmCtZ1IVivWu6/Q/odTyb79oJoARW8CyIGrtLqHOn4ll6T79v+m+9avu5Yew6g9QSvXmAg10HP7f9Od+AbSy9ruEZDBGIyl4yN/JrklD9P+h1PcrPKxOidzx0LERpN7+yHa//gRrPVvKOvOQNpQWfl8Zcq+eic991yuQo62084kx0ZEmrDbVtL+xw+Tfe3uIdSTEkKpXNEylyL5wM/p+PNZ2B2eW3AEr2KFG5ArpSwEgrsc0w30bm5uHlFWHMMwSCWTnHHGmVx44YUA9PT0IJTrxyurR7RKd4X5P/cmRiklnZ2djB8/nu9+93uccOIJWPl8SYJK975+QlJpQvSIi9umosi6EQwEicaiw7JbzzRcInHcscdyzjnnsHXr1kKahnLpG/wvr4yGYWBZFmNGj65YP8/qJ4qOLHL/bmxsHLS+CM/aFosWCE3pczwrlL+Na+lNV1cXhx56KD/68Y/Zc8+96OzsJJ/PF0hlqY541kzvVapLQm0Q8PSnuamZ//qvL3P++eeTtyysGuTKc2t77uvSa03T3OF2tL7HCJbsR9bpflpPpNOPe/dTAfqTLbsaQYg04fRsofOaT9Cd+CZ2x7u9eZr8bSOdCoRG9sYQFZ4nChan7Ov30v77E0k/8WdErJX68kf5Jl7cVBHpp66m/fcnkn39Hp+LSRSXT8X/lC+jv3yyEP/jdK6j+7aL6bjmY9jdmxDRfk7mKmbMWv867VfGST30m15rljfZlmYul04vmSq0rXITqjL13HMZHVd/3CWV7tKwN/6t0qtc3Wv9ptpviyxZDchsD503XED3Lf9PWT3N3g0GRTKoQ67+33jytHNkXriZ9t8dT88DPwcz4Oa7GsExV0IIctkc+x9wII2NjaTTqUKMSjqVoqGhgQMOPJBcLjeiSJYQgp6eHo49/jguvewy9ttvf7KZDD09PQW3njdplr78k2k2m6Wzs5NgMMhpp53GT3/6U/bcc08cx2HevHl0dXX1HnKtiNyBBx5IJBLGKaMrLjGwiUQiLFiwgJ6enoLb0jAM2tvb2XfffZk4ceKwtanrKkzzmQsu4POf/3xh8rcsq1D/ci/PArZx40bmzp3LkUcdVbCC+e+dyWTYb7/9mDhxIl1dXYXfZzIZQqEQhx166ODrpoL2x4wew0EHHURHR0eRHLq6ujhk/nwam5qKjsKp15I1ZcoULrnkEr7whS8wYcIEurq6SKVSBVlV0p1y+tPV1UUwGOSkk0/mBz/8AYcvXFiQe602kFISDIU46OCD+zy/q7OT3efOZcLEiYPK7/ZewHaKwZK9box6dDbS0o+AY+lmtfYl5Czfm93vRDBcJ/GQtYOD/WUORauX2bFdlx0h0k9fRfaNfxHZ93Qi+32EwMTdKzxHHXnuubgEvn9BZrrJLXmI9DPXk1v2OBiB4t2CAyDAomEM1pbldF73aUKzFhA96FxCc45wY7kqWsC8Ibtv7Ji14U0yL/yTzIv/xOla77oEGaAL0rHcYHjboudfl5N+4R9E9juD8B7HERg/u7KsfOWR2ST5NS+QffUusm/c62ZFD0RcvUC4ubgqjnrqu9LYKC/eqdoGgcJvg7UJvRlEmCHSz9xA9s1/EznwbKL7nYE5bpe+Xr9yZMvbEFGkN2C3ryX7+r/IvHAT1ruvQCCsNl9YIz6ZqBfXNHnyZD59wQVcf911dHR0ADBq1CjO/djH2GmnKaTTacwRFofjnRk4ffp0Lr74Yl599RUeeeQR3njjDdra2gqxL55Vy2+tEUIQiUSYNm0aBx54IAsXLmTnnXcmnc6QTqcJhoKcedZZbNmyhWeffbbgUjv55JM5+eSTSSZTFeOSvPQAJ510Eps3b+a+++4jr6xhhx56KJ/+9KfJ54Z5wpSSdDrN2Wedxf77789tt93G888/T1tbG/kyxw0BRMJhJk6axKmnnMLpp59OU2MjuXy+KMjdI2Fjxozh4m99iyt+8QvWrVuHlJKmpiY+c8EFzN19d5KKmA3G8CKEIJPN8ImPf4LOzk6eeuqpggvzxBNP5IwzziCdShVZXeslWZlMBoHB8ccfz2GHHcbTixfz5BNP8M477xTczp41r9Qi6ulPLBZlxowZ7L//ARx62KFMmTKFTNol+Z5u1Kq/t5A56uij2bJlCw/++98FMrXvvvtx7rkfw9YxXO5Qe9PpmGfcjL35e7vc2RQ2T+zMOLYQmMP2SMfCaBhDcPqB1Xdrebmb7Dz5ZU+ojOai5r2D0w7EaBxT172tzcuwNr6NCISqaJUoxE+FZs6vTUwQSMchv/yJ+g4cNkywcjjZHoxIM8Gp+xCceSjBqfthjp2J0ThGHbPjq4udx8l04XSuw1r/JrkVT5Nf8RR22woQpks8GCIXl5eHJ9sDjo05dgahmfMJTj+EwKS5GC2TMSJNJYRCInMpnJ4t2FtWkF/zAvllT5Bf+zJOpgsj3AiB0BBZSQQYbiJNmUtjxFoJTNyd4E57Y46fg9k6GRFpRpghZD6Dk2zDbluBte418u++gr11FVh5N21DIAx2DhFtVXnGqhxt5Mk63e4m4TQDYFsYLZPcI47q+W22B3vLsvqC6pWeyGwPIjaK4IxDCM85guDO+2OOmV6Z9HpcLbkVu20F+TUvknvnMazVz7uHaQcjrn5JOXzEShgIK01u9K5s/OCv+jxHeESwn++llEQjETo7O1m+fDkIwS4zZ9LS2komk0YIo1cCivj735emRBaimIGXf9/7WZ/3RZeL8u+9IcVxMIRBNBrFMA22bNnC6lWrWLVqNRs3bqS7u4tcLodhuNeMGj2ayZMnM2P6dKZO3ZnGxkYy2Qz5XM6tpxBIJMFAAMMwePvtJWzd2saECROYPXs2uVwOx5HK5Vfc+v5yCiEIhyMsX7aMdevX0drayu677+4ukPKWezB1aa0FdXxW/Lko1QDfT9wjXKIEgyE2bd7E8mXLWLNmDW1tbWSVlSkWizF+/HimT5vGjBkzaG1tJZ1OFyxeZfuA4xCNxejq7OSNN98kn8sxe/ZsJk6cWJTvyZ0KJPhtzLL2e1lY50jMgGshe/vtt9m8aTPjJ4xnzpw55PN5bMsuXujJojsVP1/6xlT1sW1bBAIBotEYlmWxfv06li9fzqpVq9i4cRNd3Z3kc3lAEAwGaGxsZOzYsey00xSmz5jOTpN3IhqNkslmyeWyrgb44nP9z/TW9YUyyOIxLBwOs2rVKtatX0dzYxOzZs9BGBTIuPQbB7xayN47FLdjyfOkrPBsqrm6pWmawrbtbDhgztlzzz1Xf//73zcuvfTSbb5q3A4Eq5ewyFyq7stFqLFOK5Zwjw2pd+IOhNz4pLqOX7GR2WT9tQw31L8bzbMyOLbbLnYOzBAi0owRG+UShFDEdWdZOWSuByfVgUx3FNpRBKPg1WU4JkrPCpLPuIcE4wbEi+gojFiLK6NAyG2nXAaZ6XSzp2e6e+sTihVyNw15EHmhDS1kPtN7/qBnLfXcanYeKW2EMF1y4QX/O04vKXIspJWt0yQRUNZI9Vs7h7Tzdf7WVL/tZx1tq6DnItyA0TQeo3kSRtM4jGgLmO6CQeZTyFQHTs9m7K4NOD1tyHwaYZiuLLyEs8NtsRomguVOZm5wbygSAQn5XNadZE2jD6kZSQTL+8RNmulukQ+HIpimgRRuMLLbR1yLhFsfsPJ5crk8tm1jmIay1PhYS+EQ6SimaWLbFtlsVpXXKCl3uXKC47jENRB0cy+l025/N0p2Cw8XwfImUCkhGAoSDoWKNgR4lRC4iUqz2WyBWJU7dscP23EIqBghAWRzuT4HKw+WYLkRHA4S9zDvgBEgb+cLOboEoihDen8JlhciYkuJUCQqGAoV9MmyLVevJAXdMYQbm5i38uRyOWzLRhhGgVcV0Zw6CZaULmkNh8OYARPHdshmszjSKWj7+5lgbVcXoRsbVK87yK773iLcWL9Lse6JXrqWoWEpM70pFUCVv5cMOJ3rkO1rfIlFRe9BvEbQDQ736jKccTPS7bAFUuqOxMh0B1Zyi68t3dWQUDvYiuoznGUstKEbpE/BiieLVlzuwOyNKk5vvUr1MxysX5/9zwiE+kea+kNuvDoKw03zoWTgdG3Cbn8XpFWcM8135qIwg4hg2HVfq9+9F3JbeSkKUsmkIgFih9qebxguabFtm1QqWTi/0KuL9E1MQggMIRDCjXcpZyD1yEWBFBmi3249wzDIZrNkspneMm7r1b8iSpZlYZUckeMnWEIIhIr/6Y++9PT0FJ4zHPUrkoN05Vd4jhySB7jkWkI+nyebyyGVhbI3JY3q6tIp+q4Q5D4EhTEMw7WOZnsJnVDler9jO+bBksM40TrDJFy5bSakQi4jZTUKhCh/uqP07QTblqKTxRsPTHfyLl++kvpsszJW0gFZp27IgVvYagWvD4cuBoKum7uaS7ywMeK9lzDUb7UQ74E6+K085T6rm7gx8Hy5tSxB26VdyhCsobjncO52c8+gZFjP9POIdyEet+RZfsvjcJTDfb6hSdXIIVga9VtHhmrJM4yES/eskSEDLQYNDQ2NEQGdB0tDQ0NDQ0NDQxMsDQ0NDQ0NDQ1NsDQ0NDQ0NDQ0NMHS0NDQ0NDQ0NDQBEtDQ0NDQ0NDQxMsDQ0NDQ0NDQ1NsDQ0NDQ0NDQ0NDTB0tDQ0NDQ0NDQBEtDQ0NDQ0NDQxMsDQ0NDQ0NDQ0NTbA0NDQ0NDQ0NDTB0tDQ0NDQ0NDYAQnW6aerd5Ju90BuqY+M1dDQ0NDQ0NjhIAwDIUjm8/kugEsuuWS7cBrXgvX6IuHyK/GWIYRmVxoaGhoaGho7HrkSwgkFgxLJ8n333bdDSimEENuPYN38xiMSwLG5P513BAjtOtTQ0NDQ0NDYoSCllKFwWEjBPQAPP/ywub3KYgCccTO2/D7GhOA7z6RyzrONEcOQEluLSkNDQ0NDQ2NHIVfBQED0dHenbMP4syJYznYlWAC8gRCX4hjS+Jp0wBRIR6K9hRoaGhoaGho7AvLNra2mlbcuPWivvdbcdNNN5qWXXrr9CZa4GVuejjn+h0sf7c45F4+KmQEDpLZkaWhoaGhoaIxUSCltwBo7dmyofWvb3/bfd97PbrrpJvOMM87Yrvwl4H8jbsaWN2GKM975ycbvzZKxkPETU0B31pEgbQBB7/81NDQ06hwCGX57uKz6to5faLw/NJHSjfKyz/te7ZDFH1Z9L4sfUvS+yCFU8t7/vD7P991E+u5d/Kf/O9+9/e/LfCd9f/hrI4sL7i9ZcXmKquS/sLS/l3w3tOQq0NDQYArDoH3r1t/ddsstX5JSGoCzvXWtLFO66XTMM27GXvfdWYtiAXGJhA80hgykUiCpKZaGhka/RhoDrDT5MXPZeMIfQTp9ByIhBvRe+J/hf2+470Txj4reGyUjmRDFw2L5976lZun74gKVf+/7TPT+UeF9nzd9PhO9lQWjqLTuR6LvkC9KPhN9ZoNyn6lPRZ+71flZ8eeiVAPEyJxXtjfBckoJllP434glWE7R84oJlkQWqI9bZqfPdWXbtPR5UiKlJJlMOoZpPJ7POz/db+897pFSquFBbPf1U0V9di1Zrnuw4/szD5CG+QHHcXazJa2aX2loaPQPJqadIdMyI7/hmN+tB6vMQFSyednofW+U+brPrwRl7mL0+VNU+r7wSKPS15SUyF/EssOrQfXRUviIUTkYJeSpT0mMvj81ylxDxWv6Erjqk4NRrXnquM6gRpX7yngAxMuoIhiXnzg1rCKVLS2FX6p7lL4vfy19DCqyr1mt7+9KbuKUrYvvIqfSlfhIjVOWRTqVrEuOvzxOhbKpb5y+X8jyjdH7l/R/Kqs+23tjGEIahpl0hFwpDOOZebvv/qoiXYYQwtkhhkT5fQwpNZnS0NDQ0NDQGKFcRUpx0003mSOtXHWRJ/l9DFhkPAx8YI9HdNiChobGAHE6D4+7aJgWbR+o+raOX2hoaAwBHu7XBQ8Prtd/4APODmO10tDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NAoh7L5aKSUJtVzZEnAqZaKvo571HsfAfQngZgUQthl7hOodU2VZ1a6Z+l1drm6lDy7Ys6Okjar9EyD4iTIdj/lYA/VEQIlZfGfoFRVrmXqUAt92qxOvZCqHZ0qdQgMoOp92rAeGQ9RvYvuIYSwhqJe5e4zFOPAIHSr3LOHatypJct65FRLx4vKUUlO9fb9/vb7IeijQzLu1tGmgx6Phmi+GrTMt4EM+jtvlRs/6pljasm+5ri6Hcd7ZyQckTOUg+CIuU8/n/mez1A/XHWUUhr13Ht7yLVSOd4P8n4vtK+UUtS610iS50jR8QrtaGzv8tdTjm0lz209X6lxckhlMJLGMVU/cwTq/ogZHypZsE4FJuCe/CNKrk8Cy4DnhRC50rN/pJRCCCGllEcDuwB2Gfban/tMBY4vU5Zy7NUAVgkh7vUf+CilbALOVN8LoE0I8U/vGWWUNwacra41gA1CiNvLlG0ycJKqown8Swix2n9fKWUEOAsIqfu9IIR41l9f3/2OAWaox2wWQtzqV2YhhCOlXAjsjnuYmwncBax3q1pRDrN8198uhNhQWvf+KK+36pFSHgAcCewGNAI9SqZPCCEe9pe7pA67Awsr6EbRSkaV+XUhxONqsJKqXhOAU6l8NLsNbABeEUKs8bdJiZXnLKCB+o94F0BCCLHJV5+g0q+Y+v4lIcRi3/fev/sBBylZ1FPvN4QQj3mDtLrH3sB8dY0E/iGE6C7RuZCqV6TOOuWAG4UQmZL7nAJMrND3upWsXxFCZEplPdDJ2PfsRbiJ1qeoer4LPA88KoToqvRbKeWHgOn9GC/uFkKsVX1fqDbeHziwgpwEkAFWqr7cXWEcOQNoUR/lgRuEELkqdT8TaFXlSgJ/L9GducDhPrnfJIToKtePS/rcrsAHgb2A0arsq4DFwINCiFRJu4s6+1dpO74rhLir0rii9PYYNRYFgM3Ay0qe6wajL1Xmmnpk5bXvAcABNWS+Anix3H1qjJN7AEcBewCjlHyXqro/XuZ6r15jgdN9Y/dyIcT95fRNXT8GOM03frwlhHikZNw8FpimflprXivXhyw137wphFhZrd/72vYgYL86x70A8LQQ4qWScW+m0uNK/dpSY8RLQoiN5cb7EWPxkFK+KWvjbSnleT4TYBEbl1LeLevD21LKT1W5z0myf3jIx2IN9ffMMtcdW7p68NwqUspflFz7Skn7eGU7puS6U0sZtJRyfMk1V/ifVXK/+33XLSl5ple2v5fc794y9TDUynGOlDJfcv0RA13N+cq5n5TygRpyeFZKeZRfrr46fKmfMr3K+72vDIfX+dtuKeV1UsqJpRYSKWWjlLJH9h+HldSnSUqZ9n3/25LvvX9/2M/nXOOrt3ePb5dcM7PUqiilbJFS5vrxHFtKOa7MfV6p47fLpJSXSylHDcZK4HvmZCnlvVWet1pKebGqoyjTJx/sZxsf7+uzXhv/tM7frpVSXlzS57x7XF9y7XH+70v6xdySa+9Q1/rL9OWSa2aVjpkl99xJ6X22SvnfkVJ+ssLYdng/2/GZkucL1SZhKeWVSsfKoUNK+Tsp5ZR6LeMDnGtWSym/UUbHvfb9eZ31XCOl/FY1S76vXLOllDeXGYP9eFoRRP/vhHo1SSnbfNd2SSmbSy1Zvjp8veTenygzbj7i+/7VCrL/YB3tkFLz1fGVLM++cv2qn7r0vTLj3rl1/narlPI3UsrGkWDxq8Qm2xUjzFb43gLmAH+VUn7XW2mVXNOlrssATo37/FlKebG6j1lmde2VxaqjTnYFZpzy3ccBfiOljPmUwxRCWGr1+iW16vSe2VHhWXn1fVr9m6uwwtuqvrfU6qUSOn3XtVe4ptvXrlngQ1LKs4UQtq/tPOb+W7UiyPraMT9Qs6t6xkeAJ4Cjq8gjr1aD/5ZSfrqMXNO+OtQjU6dK2+er3MNRlrVzgYfVitBvuZUVZGb5XpVW7aXvt9Qh45Sv3nYd9baq3COn/nYqlG9LP+RdqSwdNcYBCcwEvgM8J6U8WOmIMUByFVUW2Q9VqLsDTAV+BHxf6bhRoQ9l67RKlrsmWYecLGAn4EdSyj+qFbzw3e+nSkbePT6uyivLjL9nq7ql1bU/KrPyTvvqVbZcPovBPsDTSu8DFXQkp6w+V0kp/1dZLox+9q9qOuRZ1K8EPlNFFo3ARcCNqv0GMiH65xpZoWxTgZ9KKf/sk9VAZD4F+LGU8g/l7qNkYCvS9DTwkSp1ygMHAw9IKb/qjeFK9qYQohv4uSpPEmhS3hwoif1VsjvHJ7NlwN9U37IrzDG15rVcFdlHlEXpbinl7zyZVyA0yX6Oe+X0NVsHD7CVhfALwD3KeyS2J8mqFAhrqu8MoA141ackOys3lq2U+TIp5d1CiBdKOqh3D8+8+kzJwDJTKaulrvmBlPKfQoilJfcRvvuY6j5byyitra5bXGHgDKiXqQQ4C/iOEOK/FUv2Bpjf+5TXUH+bVdxFAfWsQJWOFPC1dbXJx/RdZ1Yhxf57OcAvlCWrU0oZFELkpZQfVR3ABsLqOmMgA5iPXB0M/F09P6fcnpuB/wCblDwXAmNUm7QDrykF9wd3GiX1fEx1wkoyfamMTIVv8jCUjrb5JrkWYF91bQbYVcn7y4rsOer1rK+8AFFlyvfKu1KRFcNnnu4uU556ZGz49EQAz6l2FCX38ur9tu85pW3n1NG3Pd1cDixRv5Ul5MJz12fL1Mk/DrQrl47X9uOVq9ob/GYC90kpDxVCvNFPd6G3uDlHySyrdPZp4F9qMJ+vdAtgI/Bbn15VGrs61HggqrhhN1ZpY+/+j5cM6lPU+OGozy+QUv5DCPGgZzkXQrwqpXwWOExdd7yUcrxyLQvfxBhU7lxD6d6LwDPKvWH7LF6lZRIVLFcTgbuByb52TAMPKhfXaGCBchNJVbZnqoxtXv96QfXxSn305d6iFMaLfYBP+MaK5cA/1Pt9lNusUd3jspJFYn/gn2uSql95mKT6vlTE4VNSyjuFELeXPMvfvg7wlE/mQpFpT+Y28Fkl84d89fUI7l7A7SpkwJNBB/AQsBYYCyxSMsqrZ/+PlHKTEOI63/iEGm+/73P3f1yRUadkbD5QtWkeCCqXdF5KGVB9qz9zjCd7L/TlZdX/harLLFUHbwy9CAgLIT6tym5XGfds3NOdrQoEKaDGqtI+KXzlDih97PL1h7HAnr7x6HDgQiHEr1QfssqEApWvvLvY8G9QkZUWhZW+r7WSXOwzuSVKrolIKb+jvvPMz78qY4q8yXeP18o8q1FK+b/q+4z696tl7nOs+s4zsx7YD2LgDTrTfWV1lLnaUm6UvXzXfVFdk1PXWer9ExVMqUf6rpdSyhPKuAjHSSk7fW3xgyouwlt91z1XwUX4Z197OL5nX6m+D0opR0spN/jqKX0m+sP748rxmfoDUsqXS+R+g5RyfMn1E5XJv1vF0ZRzEX5W/d5S9ZgyALfA/BK9OKbMtQuklJtV3W0p5XI1oVXsZFLKWSWy/3gd/aVRSrneJ7ufV3ARfteng0kVM1Fvvb17fNUnz6yUcnoZt0ezlHKTrzyXDdCi9ITvHveXykFKeZCU8j8lOvGM3z3fz7pdp+rlSCmXlrluf+U+/GgZt7inF7f7yvxoP+vtleMS3z3a1ErYf11QSvk1X70dX//zuzU+UTK+fcY/vqm+dXRJ+11UQXc+V9JnZpb0La/+15Y88ykp5W5lxt6vqj76hZLf192/6mjHz/v6UlZKOa3kuulK5j8biHu5wlzzQhk9/aSqR07p151l3MKX+e6xRUoZLrlPyOeC82T+fyX1NdQ9ny6R6U1Syp1K7tfqc53lVbk61Pgp/AHkUsqET/Zprx29cVn9/RvfNdkq+uF3pz5ZYV47okT2h5eUfYwK80ipcnu69pGS+3hl+7HvmRu9MbifunRGyVw7r8y1p6gyWapcT5Zzo48EF2HRSlgJMqjYckYI8QPcIL2Qumb3KqY9AMPbUeEpjhCiRzHzbnUfSW+Ad63VSk1SVUe9pWL6/6dWHVOAH6g6BAdoqt7WEKqsNvAZKeUiIURemZUn+FYgg9IRZYn4ELC3bzX6HyHER9WKPOBNGkKIDUKIzwP7eAGWdVgyzHom/BqI+vTUUJa8x9UK0LPcjVUr+FICKXykuLTzexNhsJ4dbv1EqFL9hvhZxhD0mYCPaBtCCFsI8Qxu4PITqi453ODw4yq4+2u56cK+FWlMbXDxryyfF0IcK4S4wbPw1NE/GKRuCaDRN3maQoi8EOJ/gHfo3byys68uXrkSykLmjZMf84+TauX7cd+qvAO4qYbblgquQVtKOUNZw2z1zJXA8UKIt0r6aI8Q4gpgnhDit97vh2Hcjaj28Fy5u5TIc6UQ4mNCiG/UKc+6dN0/z+Bu278aeFT1bQPYxfc8UafMc0KInyvXmyfzqSVWO0dZ5Q72jZOPCCHOEEK865NBQAjRIYT4MvAXJfu8srpf4Hd9K/280qcTEdwNFH7LbwNucLtUcrpfCLF8sJtOfIj5xlYhhGgTQvwad2OPpxsS+LbSg20x3sdKxntTBew/oO5vABNVWzslMWsNKoazWRkjxqj3LSruzZRSjpJSjvXCiMqUMaq+H1WtvIF+DNCGrzPnKY4z6S9DrFSgXB2/nSml3Koa0S65Z48Q4t067vEcboyQDRymrBQfAJrVZ5uAdcC8EUyuTNzdQEHcnV6o2IDLgPNVPYLAk2rSCwzwOZ6sTvaZbCXwbW+F4c/x49uNtazODi6AOWrFWNo5BbBVCLG5zh0hosZ3NiUxSb7dU94uG1nBZCyHYUeKZ+0QJc8VamKwh+g546SUc5QOWGXaZEU987gaqPDtUPPc0V9Teubpxmm4sVSinzq2TP2dU+6T56SUf1duwueFEFt8k7mscxCeU0avvGeuEUKkBjFmSd+/+RJ9CahdfjcC/6Xafb6Ucq4Q4g1Vj9HAiT433K1CiC3+HWX9GJ8dRXaDyiUeAX4qhGiXUob8OxhVHzXUJCzqnISnqbYsN+4mhRBry7TLMlU2S5GNu6WUNyndeNrb3eu7z1D0L1EyH4WUy6hrAPNVrV2o+TLXxkvGyYv9faXE+iaB/1aEydvJfCJweUkbP6jcZrPV+4+qzVJeex2jXKGee/CPnozrIDv1wPFIis99FhRC3Kmsgaeo8s4DdvNCBCq0WQCYK6XsKSNzAWxSOtvf8b7SzsI+uy2BfwOHqO96VNlb1WXtuC7024BxwBtq535pO96jXLKbFZcou6O3nkk3qyZQ/yR6rPJ35tU9VpVYhsoKyP9eBbRehhu45/mpX6yjMa8r8wzPUnMXcGqVAcpT/J+q1eTJql5X+QaCAPBl3PQD+4xw69Vy4NdqpWzjxqnc4WuPJ4Hvqg46UGuW47NSehaetT5Z2WUIi6yTXHkd7l8VOkcAuAL4pip7tWDblJK57dOxw3ADP72V6gqg3s47nLBx420eozcG0V/vIHAtcMkAJttybXyBIt2iTF9ox41R2TqAdrHUYPs8sJre7d+79dMK460wrwa+osaCPG6c13+p1xYp5ePAtUKIRMmAWamN9wXeqKDThpqY/lOjjaVauNklk+NX1ITnWSpeLhmnPN3/C27QrbcoOgf4jqrvKbhBud729T8NUq/29I3rNvCQeo5Vpo/a/bQu/46+W+S9MeVB3M023v08eT6gPB2zlTzDymL3caBHhUHcCFxXmi5iELBKkrpaKibqCN848K4vqF/WKfMA8P+UFc6T+Sv+BZH6e4+ScfKFCjLw2n+TlHIx7qYhgBlSyiYvFYSyUuWllFfjbu7IKyJzoBDCizf+hE/uy4H7+2sF7dfE47adt7HtDqXHlpLvXNXnjAp9cjTlY/688f4bwC/qGO+TZcb7k3Hjjr3+9LZv44DtszTdoOZGC/ikGmd+o3hIUi1QJiiDy6HAASrtjreg3E8ZZGoS8UAdg/Nctb3VY8O7Ah9VDZBXN7+xZOVS2qjTS2I4TKWo03wdbz1wh2/Xg9EPd4fpd7nUqI/XGS5Sbi8vINYLsHtYCPF3KeVZjHyMFULcJqW8md58KUEfc/8MbqAlA10d+gbgJt/HW4UQWb8FqMrv6rXGVfqslr/e04efSSk3+Uh+q1pZCN+A+AfPukB9O6OGmyBPq/L9hDpW0f15VqW+HhnMQKv+zEspt/jq01hNN8rpipps3pZSxoH/K2kbC9e9e6paQN2rFkhtNSZlUUO3alkybKX3/5JS5n2ymKrGQa+/5YBr/MTKV6dXVQznQqWXZ0kpLxdCZH3xfQFlVV9cp7uuElp89UsBnUrfGYI+Wi4bd9lx1yMvQoiklPIktVg4qESeDWqS+gDwRSnlOUKIVwbp1nKASWq+8mQ1Rc1XLT7L3t+ryN9WE+u9VWTuWcX8Mpd+3VfY4o2TlfRTkZSNJf2xgd6NNF5bXK8Wy15bf1zpyzR680MZwDVKtwK1Tg8YJDyL9qaScapxkOO9Wed4/ycpZYdvvB/nM4h4Gwd+V268EkL81kec5wOjhBBf8n02RpVjjZL7ObibZTzO83GlB22Ku8iBEixHWS5+WuZzoYR9lRDi3744ALMMqWlQSlBOmYO4W0fPEkJ0+nZiVCpTt2/VL33lMam87bTPQKR84pcAP/YJJIkbyzTQ7cL1WhT6fjiweBvPXPtFtUIb7SMTVwghXleJFwde2N4Br8f38RgV+FuRZPVzoOzyrS6lTzcCJc+tZtmsZm0MAX9VndIY5oFnqDCUGZIzuDvJyrlhOgdKvn06a1Ic29Zdh4WpEsn6l5RyX1y3yam47u0xvn5uA8cCfxVCnFzDXWipspTW24txydfRV4Mlq1X/GOjtsvuUEOKdMjrvLUqvVATLUgvLA6SUy5QrwrMC/UkRE5OBu3W6fX0nArRKKTdWkDv+BJR13LvHt6CuOe76XEpvSykXKG/B6bi7Kv2bWnLK6nOHSkbaPQhLloPrKvtphe8iytp2jTcOlDlSqprMbZ918Dx/nJNPD/0u5/E1xkmPpIzzfZb2j3leLKMQYo2U8m7ctA8SOF1tUDhZLaJt1c+vLSFmw7ZAVHUeWzKvddXRpzopdqP62zZd5/MPqmJACQI/UAnHjTLHTnmZARw1NwiVwsevxzHgPvXZ2VLKrwNZlcT5XGUl9BbxAyZY1VhkUpnVvt2PmAj/wOcNzLcA31Ydsdqk7N3/bNzt237/svRZKqhjBei5Nn6uFPQQ9ftvCSGWKiEMlXk1S3EeoeZyBE4Nrq0lkyJUj03wzl3aKKX8EvA31aZvAN9VchksmfDa+W01OOZxtyzvJ4R4ssIWWI9s1xooPdP5UbjuO39dPZmmVfv0tx5e9uNNwP8TQvytwrb+7QFD6cSn1SrIKFPvVUNk5veCZC+nb/yMNxB39Mfi5B8/lMl8H581OkCvW87sp/55K8x2VeYr1eRzoJpYzvXd8yQp5RwhxJIK8R6mWnWeUIFgCW8y6KfFyEtP46UX+ZoQ4pkKY5d33zuUhd6zSp6u9N0jaO3AP4dA3q/7dD8CHKUC3D0rW58+WgcR9ia+z6oJp9y4my9nEfNZDPJqnL9FnaqxD26m8E/jukhzSn+OE0L8Y5gszA5uKMiXB3Bvv8wfAb5eehqHr13exHUr5XHjCA9Wm32CfkLvxWCpOLyDfEaLZUKIngqnA1yp+oGtLDYnqvnL0/e7hBArhyCsoJ6FlUdQT/RxCcfX950yFsKAGu8OKLPw8aeMGcx4v1SN93dV4hNqbvLIrff8gmtZfeaV5VrFEw7HTUd0pFrwXQlcWms+CdQxOK9TA4nXGF4+nPuEEPUEx5rqHt+i18X4Xd9qKKPIVajaURI+dAgh2qocyVBX7I/nR8aNTXkTeEztqKm3HPW6T7rVJO+tUo5Sz/ZWT0JNUq1q4PE62sqSjltN4QPKrXk6bpDl+UKItE9ZhsLidgfwKd/nPwCOLFkFeoeH2lLK/VRutHpWo1uFEG11WNEqDZwmrt/+BdVe38GN+/BygHmxCsZwDjz9JD0WcJvaTVuPHg0GKdVnjCqHUNd9cLAX8K/01gT+h94YRuEjC7Ifg7ZnCdhFuVY61USxGTeg9B4Vg/UX34Q3DTf4t5L116qhV6KGfppqkP2a6sfjcGMCvQFYKHIVLDdp+4Lde6SUfwO+qvT1XHoTHhvAP4UQWwcxMXoyvZ9et6UEviGl/JsKGg74ymWpProXsLT0iKRKVub+jLu+gOhxQFQdIWbixjY9BjymNgA85Rvjpg/BwqVDEUG/Ve914AEhxOt1EEpTWZC+pv4dr/TbL/Nny8jcu99tijh6+ImUcoGXk6pEBqhNSa30xiHfXro48cUPPazmqt1Ue/2vj7SjFiTD4XkRvr7vLepzUsrjlJXZIzfPA2+XWPXK6eqWSuOel6KiDkPLJbi7eMPAT+jNZRgGHvdtIhgMPHfyz4GPqTx3n1M6dj/wy1oLokAdCvu0EOKsCo1h1rlVeqsQ4jrf73ZVLoAc7o6IJ4QQ/1en33goY39CaoX3ZUUiYQgtHL4kb08qM3gO2EPlwvqur5PFcBOcjvJ1tAf79ygpcIPBF/sD8oaAKHpZgv+lBqo9FDk+Qkp5A/AVIcQmX0HG4AYqfl1KeakQ4tI6SG+mlvuoDgJ4lxDCOyZpGW5ySEcNXneowERrBJ1PJZQLp5LrTg7RFmt8A7UziD7jbVRxfCvw/XADbxf59PZJ4P7+xBL5BuQJSm6bpZRfFkL8p+TStK/t/Alfq1keBkNeharXn3zWnvG4O8OywAIp5S+EEP+vitXFa1vPemJQ7PKUwB8H2Uc9N9I7Kh7zbFW+nXF37p0vhHjL195htVj6BXCnlPIMNYkOybhbMsn/E9hdjbE3l+hEqkSePYPUcwP3vL6zqiwQZB1WdU/mjk/m31KfL5RS/lwI8XW/zH3j5H24G4D2VeP9IcBtUsovemf3qXs24e7E/jy9u//agL+Uyb4OvSkZrgJ+pr6fQW8ajHdwd8fB0LsHsyV9fzRuXNJP6XW1B3DdcrJG2hdJFTdgmdMOKo33N/t24yZx48BzSudvFkJ8UMlnMG3RqEKJXgdOVkl8j8ON5c0od+GgLFgAIZ/P0p83pD/byAvb0VWFv6AG5bFKQX8upby/xtZ+77m/llKWulX8lowlQoiv1MnkPTfW/5YZEIeEY3krC9ydXF4w/beBE1Wm5yBuLMYu9Ab8bwBurdDRKk1+UplHf1pnLpJ+juEiL6W8UJnIvUzu5wAflFL+R5V5Mm6syQT1/SVqxXN5hZxIntn9BtVJRAWZPimE+GGNjtuidCykXJf/A3xdDYpzgctVvp2REOBe0L86XamD1cFzVFxTpfgeCXxGCLG+Qr9xcOOGHvX1wzEUZ3IP456wcD5lMo3XcDd4g/a/cVOOTAQeVLurnlIW4BkU7wjdTK9LrJw7wgH2klLeVYHAerr1ayHEfVVydglgtJSyXT3j+7jHlcxTOv4VKeXtyg3UZ8Hpiy17XUr5iHIxWL7xd7EQ4rlBBrd7iyxD6fyRqg9mcXcWvyClfBA3bcIo9Zm3s+8jwM1qwSsqkBZwjwT6EuVPAzBwd8xd6MvhJKSU16rxwMHdufUdKeVjuO7vMbg5u7z8aaYi14MdgwMlshQlC4R6Fz+jfUHU38d1x+2pyvo1KeUd6iB2v8yFIkEXqIWGV7cTgUXqnNwVat5biBtAnac3b9OFVdJ0eGW/QZWngd5M6gHgan/m9iFcBIJ7aoKXyT2Ie2rDOHpjIr0NRLfXMLp46RDu8W0gKDfe3yaE+FONPHqtaiwPKrfyqUqfssDRUsrPCyF+N8j28HIjXqWsmFeqtv5zvXoaqNIQls/Mbqv8N/2NVfDfw/JZdTZLKT+vVjdp3C3rf1IDQ+kKSKr7eG6B+TWeu3O1VXzpAOHfrlsyyfnLX20Lt0XfoHu/9ccUQjwvpbwc1zWK6nTzKM6zlfeZ9j/tc5GU62hly1US/2SWKeOALHS+ejyusmhfqzqVpTramWXaOqQmxufLHJXjlJTpA/3s8OXqZXlHQqi6f1dNhHPVSvkrUsrbFPmqtS3f8lkX6h2U/WWp5s60fM8YCBxf+aw6yiMVed+lxn2bcOOESgNPvb7XghuHUNpW3vEZS4Bz6oilrNTmAdzdVHv66nmwepU+D+AStZXd24JNmTK34sZgVcOdZXTL37aWIsKWzyL9Kdw4UC8X0h+llPOquNr8we5H+sayAL2pGWotipyScVBWIHLvqhMl7sQN+HaUfE4suZ833uSV66lSP/D6wAE12nGNT3e8hVNXSd1295Fyf71CuJsWXh7gLsI+89Ug+lUlmZ+vyL5f5vuoHXtCucy91AvPSylPw42JbVLla6Q3XsrfR70x/yIhxD8rjU0+K+U6lXvqdDWPeIHh19c56fdnXvPGwD0rXOPtLP3fkiPIKrWtV99apwKsrDHei5Lx3qB3o9cY5RH5kZTyX3UkXHUqtIMN5BU/uAXXJXkyrkfvFfXMfC0DSCWLwCh6zzJrGeBE0OK7x+gSq1FACHGLUsCoKscRUsof+wRXsKCpe4TrtLgZFT6LldyrSHnLDIr+8o+qZN1T30fVv6Eq5OR7uHlUtlA+nUQQN0DweCHE3VVWtE2VyuV18gpljKh/gwMRpq8eNyqL2yNUP8vyduBQIcQ9ZdxQ0ZIy1VxJVGgv/z1CfgKptkd7uZ9i6pq7pJST6c3TU2nREfTpW7RO4jfWJ5dKW5UbfPdvpv8JevHVJaT+NmqUJ8jAMcrXXyplvF6Gm8/uIDWxmP2ZIH2B0JuEEEcD5+HGeFaqVztuEOvvK/SRlhplrme8aPDJcqzvPt7Y9TyuazSs2ncOcL1aURuVLOW4efq8rd0RRfxvqdNSHfXVK1KuT/gm4eeVa+qmCtY9r/88hRtH+Vv6uqSDPv3pbx+VKvP5hWoy/U+VhZ2DGx7xuQFslurPWF0LtWT+LO6Oc0/muwHXlcrcJ4O7lDHgTiofYh3AzTC/SIXI1Ay58QW7m0ongrjx0Kvr7Hv1tFXQN8ZUkn0a1x36IUWuhDrdQVZp2wj17Y4up6/hkrk26F90qSTEF/me04zrHm8uY7QpnU9LxwovvUuDkulKJSeUNcvT9xb1nPryYPka5zu4wX1ecsb+mG29636lBhQvMN5vMfIGnM/TG/vkrao8X7PXyC+r6xxqZ9Yt5BQpyf+yGbiQ3iy/1UzR3mdX4CbwlMr95W8f75rXVNm8rdYvlruvb2XzSxW3dAxu/Mo49ds1akX8gBAiV4Fxe++vVG0mFVmrFBfhL+NFvtX/WwM1w/tI1jPAB6SUh6pVw2ylpN24QZgPCSFeUortHzS8Zz7YT5kuL1PmJb56eYfReq4AFYctnlF5eHamd2dVq1oFlnN1ALxbct+HK7WXr90zSr9iqj6leuD9e6typXirsfYq8qskz7vU77zV5WbfpCZ9g99nqT/HlcR36LHvPt/zWUFKLTwdily96uX6Gaiby3+4qhDiauVa8qxXuyjC2oGb2PE+T36lyYvVv/+Du2OtXt16qIx8/6ncWFK5HHrKjF0/UP02SO/xWlEvQaRfpr68UCkp5afpPYT8dSFERw0XsVeuB3x9BmUdpoLV3BBCrAbOlFLugZvEcg81mWSU3B4VQjxapY96/ase3RFKPtKvz6ocDwAPqHIcpojJKNzNA28BDwoh3hyENbd0rmkb4D1uVnOdJ/NkGZlfRu/pGZ5rLlK66883TnqxO3urcdKTQVq178NCiKfLyKDi+KuufQzXFezlJvxnHTukvXr+DPfAbemfK0uueaNkzvAjh7tp7Q0hxCqfnKvNpTeq+tbbJ18u0yef9s21Bm7MWel4f6vKXzmG3lQlLepEBVHmWeAmMW6lOP6vG9d1vsH32ZcVubrXZ338mJr3Uv0YxzWGC/WczTbA0+S3dT2MWjFu3nlg27mcQmvdttHroWrr90ofqVcfh0tHvd1Y9fTl7a0b9YwnO6i8a46B9cppBNfPHMn9a3tDVBnAhG9Faw+kY9W6h3cUQIlp2a5xTc1H13EPuxbbHGD567lvpfpIeoPVaw2IRr2yGUgZBypj6gwoLanDsMq0pIw161/mvnUFx5YkLHSqpEPwuxOsgQxqJW1Xqd79zXHX5z5l2m5AOjvAgdKo8Oxa8qtV5j6r7FJZ1SOncv24HnkOdGytV+61xot6nz0U426dfd4Z7G7ZIZqvhlPmA5LBYMebIZzXyvV72Y9n9ne8L9cnh2u8N5Uc7TLt6/h2knp1sH0W2rK/1dDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0BgaiMEfVaehoaGhoaGhoeGHoZtAQ0NDQ0NDQ0MTLA0NDQ0NDQ0NTbA0NDQ0NDQ0NDTB0tDQ0NDQ0NDQ0ARLQ0NDQ0NDQ0MTLA0NDQ0NDQ0NTbA0NDQ0NDQ0NDQ0wdLQ0NDQ0NDQ0ARLQ0NDQ0NDQ0MTLA0NDQ0NDQ0NDU2wNDQ0NDQ0NDQ0wdLQ0NDQ0NDQ0ARLQ0NDQ0NDQ0MTLA0NDQ0NDQ0NDU2wNDQ0NDQ0NDQ0wdLQ0NDQ0NDQ0ARLQ0NDQ0NDQ0NDEywNDQ0NDQ0NDU2wNDQ0NDQ0NDTeewjsiIWOx+Njgc0VvnaAbuBt4F7gt4lEYnOdv80CbcArwI3AdYlEwunn80vxu0Qi8YUav9srkUi8VuY5HwTuL/k4mUgkGquUZVUikZhe7/e+614D9vB9NCORSKwcrnL3Q9YGcBLwYeBgYCIQU3LaCDwHPAjclEgk7IHKZjC6EY/H1wI7DUCV5wPv9FN+A9W14bqv1+fyqt9tBJYA/wauTyQSXYPo53OBLwEfAKYCIfWMTmAtsBS4JZFI3D3Yeg12bIjH43cBJ/iuPyqRSPynQr0agA2A1x86gEnqfc2+uq37xWDkMVzj+FCN5SUy+SRwPLAPMAaw1f2fA24DbkwkEta2lPlQ9Lft1SdKypABwiUfnw3sBnwfyAHzlC69BTQDVyYSiQu1BWvk1akFOAj4HvBmPB4/qM7fhoHJwLHA1cDd8Xh8W5DQL1f4/CsjvK2HtdzxeHwv4CU1uH0c2FXJNqgmlHnAp4C/AU3DXNftpRs7Sp8LA2MVSY8DvwPejcfj5w1Q9mcq2X9WyT2mFoSjgOnAAuA84LhtVMda8r+q5PqPV7nXh30TLcDfE4lEZiT3i+0gj8GM4/3qr/F4/FhgBfBbRbAmq9/HgGnAacB1wBvxeHyf7SHz4e5vwz0mJhKJiFpQAlyRSCREIpG40XfJs8DvgV8CL2sL1shCgfXH4/HxwNeAr6vvxgC3xOPxOYlEIl3pt0ox5gE3qAEEpTgfK9ORKj5/gPhoPB7/ViKR2OLr9Lup549kDFu54/H4/sDDvkHJAq5QslgBjFar6IOAcwA5DLKpSzcSicSUMuV/Sf3Gw+xEIvFOhdXlgHR9uPrQANsoqKx4xwHfUQNvI/DXeDw+PZFIfL8fsh8H/FkRBoDHFJl/U016h6uJ/thhbq/+jA13qtX8GPX+tHg8flEikUiVuW/pRHzVSO4XQyyP4RrHBzSWx+Px45XsPGPDGmWl+7ey0H1YtW8zMBt4NB6PH6os99tE5sPQ37ZVn+gPfgP8FYgApyqd0gRrpCGRSGyKx+PfVIq3p/p4inp/a5XfWcDz8Xj8MqU0Hk4YRGeoFxHgQuAHJdYhMcKbe1jKHY/Hw8AtJSu+jycSib/73m9Qr2fV6m04dWp76saO0u/ywErg/+Lx+O3A02qiB/hePB5/PJFIPFDn7Y4vkf2XEonES+rvtLLc3BaPx48G9tsGdasp/0QikYvH438Dvqi+a1SWhRtKdHsn4EjfR68nEolnR3i/2ObyGOg43p/+Go/Hm5VlyiNXGeDoRCKxxPebP8fj8XeBe9T7JuCGeDy+z7aQ+TbqbyNhTGxTBGsirqv5PYH3ZJB7IpGQwOKSj+fW+fM3St5PGsaiPqtWoAAXqVUJ8Xh8jG/F0w28NsKaeLjL/Ulc07yHe0smke2FbakbO3L/W0dfN/El/bhFaTxbsMJz/p1IJH42guR/dcn7j5W5x7kl4+5VO0C/2C7yGOQ4Xo+8LsC1+Hm4toRceeX4F/CE76O96XWFDrfMt0V/GxFjYiKR+GIikTj9vTQW6l2EfSHKMOvhwmrfamwScKb6+7NAVP39V9zAv5GE4S73KSXv//4+1I0dHbcDflfJfOX2qQelQbXXx+PxM+PxeMtIln8ikXgBN+DXw9HxeHxSlQnYAq7fAfrFSJXHYPtrqUvz3ir3uqfk/Ye2kcy3RX/TY+Iw4T0ZpBuPxwXuzppqTLsS9ih5/2Qdv5kWj8crxTrs6zOnl8MvgTPU31+Ox+P/AD6v3jvAr4FrR2AzD2e5dy95/8ogyjkY2QyFbgw1hrI+w3bfRCJhxePxt+h1GQncHUOb6vj5XbiuJ4+sz8HdpSTj8fgK4BncGJmb69iluK3lfzXwC/W3iRsHdYUal/Yvuce/EonExh2gXwylPLbVOF6PvOaUvH+nyr3eqfLb4ZT5cPS37TImJhKJp0sJWSKRuIQSa1sikXiLkR8eUxfecxYsFZD5U3r99uBuIf5Xjd8F4vH4AcB3fR+vAK4czvIqpfPM4Pvjxk1MVu/vSCQSy0diOw9zuVtL3ndvZ53aLrrxHkB3DblW0q31uFu4k2VWyzOBs3CDrlfF4/EzRpj8r8fdQu/h4xX+hv67irZLv9ge8hjoON5PeTWXvE9VuW1p3Vu2kcyHvb/pMVFbsAazGmsDPlJl50m530ogAXw5kUi01/H8we7s+qVaEYIbF+D/fCRjuMrdUTI4DGar+WBkMxS6MdQYabsIq6G5jFzrndRvj8fjs3E3UZyIu2PJLDOB3BCPx19NJBJvjgT5JxKJzfF4/B563Xl7x+PxvZXl5SzfpVuUZWiH6BdDKI/hGscHIq+ukvaMVbl3Q8n7zm0k8+Hob++1MXHE4r0YgyVVx3kOuByYm0gkFvfzHkJZY0ZvozLfgrs92I8XEonEo0Nwb6tM3erRBWs7lrt0cN57BOnXttaNHRJqG/duJf3yrf5aThKJxPcTicT+avJYBPwKd7eXf5H4kREm/3L5kY4F/DEx16udYDtMv9jG8hiKcbyWvEoD2mdVuU/pd0u3kcy3WX/TY6ImWNVWY0K9jEQi0ZJIJA5MJBLfSyQSm+r5rRowLsDNKAtwCPBQPB6fsQ0GLgs3DwhDaAXyr7T8nXpUhetGlXTOLdux3LeXvD97e+rV9tSNHZlj0RuzA/BUHX2xmq6lEonEo4lE4ivAf5V8PXaEyf9uimNfzsFNwunH1TtwvxgueQxmHB+IvEqD2j9U5d7H1fjtcMl8u/Q3PSZqgjXUA0Z3IpH4M27WYD/p+Ms2KsKf6PXzrwf+MUT1krhpFTw0xePxPUtWP7vg5h/x8HI/sgwPR7mvBlb53h8bj8fPfh/rxo7FrOLxyaggXx8u6cfv4/F4/L9V3qdyeLfk/fqRJH+18PDnBpqEm7DSw4uJROLlHaVfjDR5DKG8/gz4XVofj8fjs8rU/0O4meo9vEZJLNgwynzY+5seE4cP+qiPvvgFcD69u0SOiMfjH04kErcOs8J2UJzMbyjxv8ChvvfXxOPxz+C6HOYAfyi5/lfbs9yJRCIbj8dPozhj9bXxeHwebvqHlbixEzupldNHgRMSiUTne1E3dhBSFcB1ExyPG/g62ff1Zf1MetgA/BD4Ujwe/6OyDryJ67beB/ix71obN9HlSBsbrqLykVFX7WD9YqTKY1DySiQSnfF4/BOqvIayAD0Yj8e/iHuOY0hZhn7hu2cP8FG1cB12mW+j/qbHRE2wttnqJx+Px79OsTn+5/F4/O5EIpGt8LNqwZkvJxKJfbZznW6Kx+P7At/E9ZfvhxvbUA6/TCQS14wAOTwfj8cPxT1PbU+lq99Ur3IQwy2bAerGjoKBtlO133XjBr7+dYBlmqAmj+9W+F4C31TbuhlJ8k8kEq/G4/EX6JvZPKd0ekfsF0MhjxE1licSiTvj8fjJwDW4R97sTF9XrIdlwJmJROKVCs8bFpkPQ3/TY+I2gnYRlleaO9QKxsNM+sYZ7Gh1ulitav8EvK46o61WZG/gmnYPSyQS/28ElflV3N1Kcdyt0EtwA1/zuKfIv6JW7h9l221Zf8/pxhBAqklki9KtBPA5YKcBkqt/q9//CTfH0krcWEJPX99U+npQIpG4YgSPDeWsFncmEom2HaxfjFh5DIW8EonE3bgHVn8JN7ZqPZDFzf21WunzJ4DdE4nE8zUeOSwyH+b+psfEYYKQUupW0NDQ0NDQ0NAYQmgLloaGhoaGhoaGJlgaGhoaGhoaGppgaWhoaGhoaGhogqWhoaGhoaGhoaEJloaGhoaGhoaGJlgaGhoaGhoaGppgaWhoaGhoaGhoaIKloaGhoaGhoaEJloaGhoaGhobGewD/HyFJ9mnUmS+GAAAAAElFTkSuQmCC";


function LogoEledia({size=36, lang}) {
  // Real eLeDia wordmark, embedded as data URI (no external requests).
  return React.createElement("img",{
    src:ELEDIA_LOGO_DATA, alt:t(lang,"alt_eledia_logo"),
    style:{display:"block",height:size,width:"auto"}
  });
}

function IconEledia({size=36, lang}) {
  // Square eLeDia favicon (orange dot pattern + lowercase "e"), data URI.
  return React.createElement("img",{
    src:ELEDIA_FAVICON_DATA, alt:t(lang,"alt_eledia_favicon"),
    style:{display:"block",height:size,width:size}
  });
}

function LogoMoodlePartner({size=44, lang}) {
  // Real Moodle Premium Certified Services Provider Partner badge, data URI.
  return React.createElement("img",{
    src:MOODLE_PARTNER_DATA, alt:t(lang,"alt_moodle_partner"),
    style:{display:"block",height:size,width:"auto"}
  });
}

function IconGitHub({size=22, lang}) {
  // Standard GitHub octocat mark (simplified inline path).
  return React.createElement("svg",{
    xmlns:"http://www.w3.org/2000/svg", viewBox:"0 0 24 24", height:size, width:size,
    role:"img","aria-label":t(lang,"alt_github"), fill:"currentColor",
    style:{display:"block"}
  },
    React.createElement("path",{d:"M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.11.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.87-1.54-3.87-1.54-.52-1.32-1.27-1.67-1.27-1.67-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.02 1.75 2.69 1.25 3.34.96.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.7 0-1.26.45-2.29 1.18-3.1-.12-.29-.51-1.46.11-3.04 0 0 .97-.31 3.18 1.18a11 11 0 0 1 5.79 0c2.21-1.49 3.18-1.18 3.18-1.18.62 1.58.23 2.75.11 3.04.74.81 1.18 1.84 1.18 3.1 0 4.43-2.69 5.41-5.25 5.69.41.36.78 1.06.78 2.13 0 1.54-.01 2.78-.01 3.16 0 .31.21.68.8.56C20.71 21.39 24 17.08 24 12 24 5.65 18.85.5 12.5.5z"})
  );
}


function IconMonitorCog({size=18, color="currentColor"}) {
  return React.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:color,strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true"},
    React.createElement("path",{d:"M12 17v4"}),
    React.createElement("path",{d:"m15.2 4.9-.9-.4"}),
    React.createElement("path",{d:"m15.2 7.1-.9.4"}),
    React.createElement("path",{d:"m16.9 3.2-.4-.9"}),
    React.createElement("path",{d:"m16.9 8.8-.4.9"}),
    React.createElement("path",{d:"m19.5 2.3-.4.9"}),
    React.createElement("path",{d:"m19.5 9.7-.4-.9"}),
    React.createElement("path",{d:"m21.7 4.5-.9.4"}),
    React.createElement("path",{d:"m21.7 7.5-.9-.4"}),
    React.createElement("path",{d:"M22 13v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9"}),
    React.createElement("path",{d:"M8 21h8"}),
    React.createElement("circle",{cx:"18",cy:"6",r:"3"})
  );
}
function IconUsers({size=18, color="currentColor"}) {
  return React.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:color,strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true"},
    React.createElement("path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"}),
    React.createElement("circle",{cx:"9",cy:"7",r:"4"}),
    React.createElement("path",{d:"M22 21v-2a4 4 0 0 0-3-3.87"}),
    React.createElement("path",{d:"M16 3.13a4 4 0 0 1 0 7.75"})
  );
}
function IconLayoutGrid({size=18, color="currentColor"}) {
  return React.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:color,strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true"},
    React.createElement("rect",{width:"7",height:"7",x:"3",y:"3",rx:"1"}),
    React.createElement("rect",{width:"7",height:"7",x:"14",y:"3",rx:"1"}),
    React.createElement("rect",{width:"7",height:"7",x:"14",y:"14",rx:"1"}),
    React.createElement("rect",{width:"7",height:"7",x:"3",y:"14",rx:"1"})
  );
}
function IconStickyNote({size=18, color="currentColor"}) {
  return React.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:color,strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true"},
    React.createElement("path",{d:"M16 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11l5-5V5a2 2 0 0 0-2-2z"}),
    React.createElement("path",{d:"M15 3v4a2 2 0 0 0 2 2h4"})
  );
}
function IconBotMessageSquare({size=18, color="currentColor"}) {
  return React.createElement("svg",{xmlns:"http://www.w3.org/2000/svg",width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:color,strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true"},
    React.createElement("path",{d:"M12 6V2H8"}),
    React.createElement("path",{d:"m8 18-4 4V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2Z"}),
    React.createElement("path",{d:"M2 12h2"}),
    React.createElement("path",{d:"M9 11v2"}),
    React.createElement("path",{d:"M15 11v2"}),
    React.createElement("path",{d:"M20 12h2"})
  );
}

function IconCC({size=24, lang}) {
  return React.createElement("img",{
    src:CC_BYNCSA_DATA,
    alt:t(lang,"alt_cc_byncsa"),
    style:{height:size,width:"auto",display:"inline-block",verticalAlign:"middle"}
  });
}

function Footer({lang}) {
  const linkSty = {color:"#194866",textDecoration:"underline"};
  return React.createElement("footer",{
    role:"contentinfo",
    style:{background:"#FFECDB",color:"#194866",padding:"14px 24px",fontSize:11,lineHeight:1.55,borderTop:"1px solid #FCBC82"}
  },
    React.createElement("div",{
      style:{maxWidth:1100,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",gap:20,flexWrap:"wrap"}
    },
      // LEFT: credits + license icon + github icon
      React.createElement("div",{style:{flex:"1 1 460px",minWidth:260}},
        React.createElement("p",{style:{margin:"0 0 4px"}},
          React.createElement("strong",{style:{color:"#194866"}},"Moodle Tool Guide"),
          " · ",t(lang,"credit_original")," ",
          React.createElement("a",{href:"https://www.joyceseitzinger.com/",target:"_blank",rel:"noopener",style:linkSty},"Joyce Seitzinger"),
          ", ",
          React.createElement("a",{href:"https://www.brickfield.ie/about_us/",target:"_blank",rel:"noopener",style:linkSty},"Gavin Henrick"),
          " & ",
          React.createElement("a",{href:"https://blog.martignoni.net/a-propos/",target:"_blank",rel:"noopener",style:linkSty},"Nicolas Martignoni"),
          " (",
          React.createElement("a",{href:"https://moodletoolguide.net/",target:"_blank",rel:"noopener",style:linkSty},"moodletoolguide.net"),
          ")"
        ),
        React.createElement("p",{style:{margin:"0 0 4px"}},
          t(lang,"credit_translation")," ",
          React.createElement("a",{href:"https://www.linkedin.com/in/ralfhilgenstock/",target:"_blank",rel:"noopener",style:linkSty},"Ralf Hilgenstock"),
          ", Susanne Gebauer & Gerald Hartwig"
        ),
        React.createElement("p",{style:{margin:"0 0 6px"}},
          t(lang,"credit_eledia")," ",
          React.createElement("a",{href:"https://eledia.academy/",target:"_blank",rel:"noopener",style:{...linkSty,fontWeight:600}},"eledia.academy")
        ),
        React.createElement("div",{style:{display:"flex",alignItems:"center",gap:14}},
          React.createElement("a",{
            href:"https://creativecommons.org/licenses/by-nc-sa/4.0/",target:"_blank",rel:"noopener",
            title:"CC BY-NC-SA 4.0",
            style:{display:"inline-flex",alignItems:"center",color:"#194866",textDecoration:"none"}
          }, React.createElement(IconCC,{size:24,lang:lang})),
          React.createElement("a",{
            href:REPO_URL,target:"_blank",rel:"noopener",
            title:t(lang,"alt_github"),
            style:{display:"inline-flex",alignItems:"center",color:"#194866",textDecoration:"none"}
          }, React.createElement(IconGitHub,{size:18,lang:lang}))
        )
      ),
      // RIGHT: logos
      React.createElement("div",{
        style:{display:"flex",alignItems:"center",gap:18,flexShrink:0}
      },
        React.createElement("a",{
          href:"https://eledia.de/",target:"_blank",rel:"noopener",
          style:{display:"inline-flex",alignItems:"center"},
          "aria-label":t(lang,"alt_eledia_logo")+" – eledia.de"
        }, React.createElement(LogoEledia,{size:42,lang:lang})),
        React.createElement("a",{
          href:"https://moodle.com/de/certified-service-provider/eledia-gmbh/",target:"_blank",rel:"noopener",
          style:{display:"inline-flex",alignItems:"center"},
          "aria-label":t(lang,"alt_moodle_partner")
        }, React.createElement(LogoMoodlePartner,{size:42,lang:lang}))
      )
    )
  );
}

function App() {
  const [view,setView]=React.useState("matrix");
  const [selectedTool,setSelectedTool]=React.useState(null);
  const [compareIds,setCompareIds]=React.useState([]);
  const [showCompare,setShowCompare]=React.useState(false);
  const [search,setSearch]=React.useState("");
  const [lang,setLang]=React.useState("de");
  const [fontScale,setFontScale]=React.useState(1);
  React.useEffect(()=>{ document.documentElement.lang = lang; },[lang]);
  const [filters,setFilters]=React.useState({setup:null,support:null,bloomMin:0,goal:null,onlyGreen:false});

  const resetFilters = () => setFilters({setup:null,support:null,bloomMin:0,goal:null,onlyGreen:false});
  const toggleCompare = id => setCompareIds(p=>p.includes(id)?p.filter(x=>x!==id):p.length>=4?p:[...p,id]);
  const filteredTools = TOOLS.filter(t2=>!search||t2.name.toLowerCase().includes(search.toLowerCase())||t2.desc.toLowerCase().includes(search.toLowerCase()));

  const navBtn = (v,label,Icon) => React.createElement("button",{onClick:()=>setView(v),"aria-current":view===v?"page":undefined,style:{padding:"8px 16px",borderRadius:8,border:"none",background:view===v?"#194866":"transparent",color:view===v?"white":"#707070",cursor:"pointer",fontSize:14,fontWeight:view===v?600:400,display:"inline-flex",alignItems:"center",gap:8}},Icon?React.createElement(Icon,{size:18,color:view===v?"white":"#707070"}):null,label);

  const langBtn = (code, label) => React.createElement("button",{key:code,onClick:()=>setLang(code),"aria-pressed":lang===code,style:{padding:"4px 10px",borderRadius:6,border:"none",background:lang===code?"#194866":"transparent",color:lang===code?"white":"#194866",cursor:"pointer",fontSize:12,fontWeight:lang===code?700:400}},label);

  return React.createElement("div",{style:{fontFamily:"Inter, system-ui, -apple-system, sans-serif",background:"#F3F5F8",minHeight:"100vh",zoom:fontScale}},
    React.createElement("a",{href:"#main",style:{position:"absolute",left:"-9999px",top:0,padding:8,background:"#194866",color:"white",zIndex:200},onFocus:e=>e.currentTarget.style.left="0",onBlur:e=>e.currentTarget.style.left="-9999px"},"Zum Inhalt springen"),
    React.createElement("header",{style:{background:"#FFECDB",color:"#194866",padding:"20px 24px",borderBottom:"1px solid #FCBC82"}},
      React.createElement("div",{style:{maxWidth:1200,margin:"0 auto"}},
        React.createElement("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",gap:16,flexWrap:"wrap"}},
          React.createElement("div",null,
            React.createElement("div",{style:{display:"flex",alignItems:"center",gap:12,marginBottom:4,flexWrap:"wrap"}},
              React.createElement("span",{style:{fontSize:26},"aria-hidden":"true"},"\u{1F393}"),
              React.createElement("h1",{style:{margin:0,fontSize:22,fontWeight:700,color:"#194866"}},t(lang,"title")),
              React.createElement("span",{style:{background:"#f98012",color:"white",fontSize:11,padding:"2px 10px",borderRadius:10,fontWeight:600}},"Moodle 5")
            ),
            React.createElement("p",{style:{margin:0,fontSize:13,color:"#267372"}},t(lang,"subtitle"))
          ),
          React.createElement("div",{style:{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}},
            React.createElement("div",{role:"group","aria-label":"Schriftgröße",style:{display:"flex",gap:2,background:"rgba(25,72,102,0.08)",padding:3,borderRadius:8}},
              React.createElement("button",{onClick:()=>setFontScale(s=>Math.max(0.85,Math.round((s-0.1)*100)/100)),title:t(lang,"a11y_font_smaller"),"aria-label":t(lang,"a11y_font_smaller"),"aria-pressed":fontScale<0.999,style:{padding:"4px 10px",borderRadius:6,border:"none",background:fontScale<0.999?"#194866":"transparent",color:fontScale<0.999?"white":"#194866",cursor:"pointer",fontSize:12,fontWeight:fontScale<0.999?700:400}},"A−"),
              React.createElement("button",{onClick:()=>setFontScale(1),title:t(lang,"a11y_font_reset"),"aria-label":t(lang,"a11y_font_reset"),"aria-pressed":Math.abs(fontScale-1)<0.001,style:{padding:"4px 10px",borderRadius:6,border:"none",background:Math.abs(fontScale-1)<0.001?"#194866":"transparent",color:Math.abs(fontScale-1)<0.001?"white":"#194866",cursor:"pointer",fontSize:12,fontWeight:Math.abs(fontScale-1)<0.001?700:400}},"A"),
              React.createElement("button",{onClick:()=>setFontScale(s=>Math.min(1.4,Math.round((s+0.1)*100)/100)),title:t(lang,"a11y_font_larger"),"aria-label":t(lang,"a11y_font_larger"),"aria-pressed":fontScale>1.001,style:{padding:"4px 10px",borderRadius:6,border:"none",background:fontScale>1.001?"#194866":"transparent",color:fontScale>1.001?"white":"#194866",cursor:"pointer",fontSize:12,fontWeight:fontScale>1.001?700:400}},"A+")
            ),
            React.createElement("div",{role:"group","aria-label":"Sprache",style:{display:"flex",gap:2,background:"rgba(25,72,102,0.08)",padding:3,borderRadius:8}},
              langBtn("de","DE"), langBtn("en","EN"), langBtn("fr","FR"), langBtn("es","ES")
            )
          )
        )
      )
    ),
    React.createElement("nav",{"aria-label":"Ansichten",style:{background:"#F3F5F8",borderBottom:"1px solid #E9E9E9",padding:"8px 24px",position:"sticky",top:0,zIndex:50}},
      React.createElement("div",{style:{maxWidth:1200,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}},
        React.createElement("div",{style:{display:"flex",gap:4,flexWrap:"wrap"}},
          navBtn("matrix",t(lang,"nav_matrix"),IconLayoutGrid),
          navBtn("cards",t(lang,"nav_cards"),IconStickyNote),
          navBtn("wizard",t(lang,"nav_wizard"),IconBotMessageSquare)
        ),
        React.createElement("div",{style:{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}},
          view!=="wizard"&&React.createElement("input",{value:search,onChange:e=>setSearch(e.target.value),placeholder:t(lang,"search_placeholder"),"aria-label":"Suche",style:{padding:"6px 12px",borderRadius:8,border:"1px solid #E9E9E9",fontSize:13,width:160}}),
          compareIds.length>=2&&React.createElement("button",{onClick:()=>setShowCompare(true),style:{padding:"6px 14px",borderRadius:8,background:"#f98012",color:"white",border:"none",cursor:"pointer",fontSize:13,fontWeight:600}},t(lang,"compare_btn")+" ("+compareIds.length+")")
        )
      )
    ),
    view!=="wizard"&&React.createElement("div",{style:{maxWidth:1200,margin:"0 auto",padding:"12px 24px",display:"flex",gap:8,flexWrap:"wrap"}},
      React.createElement("label",{style:{display:"inline-flex",alignItems:"center",gap:6,padding:"6px 10px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",fontSize:12,color:"#353535"}},
        React.createElement(IconMonitorCog,{size:14,color:"#194866"}),
        React.createElement("select",{value:filters.setup||"","aria-label":t(lang,"setup"),onChange:e=>setFilters(f=>({...f,setup:e.target.value||null})),style:{border:"none",outline:"none",background:"transparent",fontSize:12,color:"#353535",cursor:"pointer",padding:0}},
          React.createElement("option",{value:""},t(lang,"filter_setup_all")),
          React.createElement("option",{value:"einfach"},"●○○ "+t(lang,"setup_einfach")),
          React.createElement("option",{value:"mittel"},"●●○ "+t(lang,"setup_mittel")),
          React.createElement("option",{value:"komplex"},"●●● "+t(lang,"setup_komplex"))
        )
      ),
      React.createElement("label",{style:{display:"inline-flex",alignItems:"center",gap:6,padding:"6px 10px",borderRadius:8,border:"1px solid #E9E9E9",background:"white",fontSize:12,color:"#353535"}},
        React.createElement(IconUsers,{size:14,color:"#194866"}),
        React.createElement("select",{value:filters.support||"","aria-label":t(lang,"support"),onChange:e=>setFilters(f=>({...f,support:e.target.value||null})),style:{border:"none",outline:"none",background:"transparent",fontSize:12,color:"#353535",cursor:"pointer",padding:0}},
          React.createElement("option",{value:""},t(lang,"filter_support_all")),
          React.createElement("option",{value:"gering"},"●○○ "+t(lang,"support_gering")),
          React.createElement("option",{value:"mittel"},"●●○ "+t(lang,"support_mittel")),
          React.createElement("option",{value:"hoch"},"●●● "+t(lang,"support_hoch"))
        )
      ),
      React.createElement("select",{value:filters.goal||"","aria-label":t(lang,"filter_goal_default"),onChange:e=>setFilters(f=>({...f,goal:e.target.value||null,onlyGreen:!!e.target.value})),style:{padding:"6px 12px",borderRadius:8,border:"1px solid #E9E9E9",fontSize:12}},
        React.createElement("option",{value:""},t(lang,"filter_goal_default")),
        ["info","bewerten","komm","collab"].map(gk=>React.createElement("option",{key:gk,value:gk},"\u2714 "+tg(lang,gk).label))
      ),
      React.createElement("select",{value:filters.bloomMin||"","aria-label":"Bloom",onChange:e=>setFilters(f=>({...f,bloomMin:parseInt(e.target.value)||0})),style:{padding:"6px 12px",borderRadius:8,border:"1px solid #E9E9E9",fontSize:12}},
        React.createElement("option",{value:""},t(lang,"filter_bloom_all")),
        I18N[lang].bloom_levels.map((name,i)=>React.createElement("option",{key:i,value:i+1},t(lang,"filter_bloom_from")+" "+(i+1)+": "+name))
      )
    ),
    React.createElement("main",{id:"main",style:{maxWidth:1200,margin:"0 auto",padding:"16px 24px 40px"}},
      view==="matrix"&&React.createElement("section",{"aria-labelledby":"view-matrix-title"},React.createElement("h2",{id:"view-matrix-title",className:"sr-only"},t(lang,"nav_matrix")),React.createElement(MatrixView,{tools:filteredTools,onSelect:setSelectedTool,filters:filters,onResetFilters:resetFilters,lang:lang})),
      view==="cards"&&React.createElement("section",{"aria-labelledby":"view-cards-title"},React.createElement("h2",{id:"view-cards-title",className:"sr-only"},t(lang,"nav_cards")),(filteredTools.filter(t2=>{
        if(filters.setup&&t2.setup!==filters.setup) return false;
        if(filters.support&&t2.support!==filters.support) return false;
        if(filters.goal&&filters.onlyGreen&&t2.goals[filters.goal]?.r!=="grün") return false;
        if(filters.bloomMin&&parseInt(t2.bloom)<filters.bloomMin) return false;
        return true;
      }).length===0 ?
        React.createElement("div",{role:"status","aria-live":"polite",style:{maxWidth:600,margin:"40px auto",padding:32,background:"#FFECDB",border:"2px dashed #f98012",borderRadius:12,textAlign:"center"}},
          React.createElement("div",{style:{fontSize:48,marginBottom:8},"aria-hidden":"true"},"🔍"),
          React.createElement("h3",{style:{margin:"0 0 8px",color:"#194866",fontSize:18}},t(lang,"empty_title")),
          React.createElement("p",{style:{margin:"0 0 16px",color:"#353535",fontSize:14,lineHeight:1.5}},t(lang,"empty_text")),
          React.createElement("button",{onClick:resetFilters,style:{padding:"8px 16px",borderRadius:8,border:"none",background:"#b85a00",color:"white",cursor:"pointer",fontSize:13,fontWeight:600}},t(lang,"empty_reset"))
        ) :
        React.createElement("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(280px, 1fr))",gap:14}},
          filteredTools.filter(t2=>{
            if(filters.setup&&t2.setup!==filters.setup) return false;
            if(filters.support&&t2.support!==filters.support) return false;
            if(filters.goal&&filters.onlyGreen&&t2.goals[filters.goal]?.r!=="grün") return false;
            if(filters.bloomMin&&parseInt(t2.bloom)<filters.bloomMin) return false;
            return true;
          }).map(t2=>React.createElement(ToolCard,{key:t2.id,tool:t2,onSelect:setSelectedTool,onCompare:toggleCompare,isC:compareIds.includes(t2.id),lang:lang}))
        )
      )),
      view==="wizard"&&React.createElement("section",{"aria-labelledby":"view-wizard-title"},React.createElement("h2",{id:"view-wizard-title",className:"sr-only"},t(lang,"nav_wizard")),React.createElement(WizardView,{tools:TOOLS,onSelect:setSelectedTool,lang:lang}))
    ),
    selectedTool&&React.createElement(DetailModal,{tool:selectedTool,onClose:()=>setSelectedTool(null),lang:lang}),
    showCompare&&React.createElement(CompareView,{toolIds:compareIds,tools:TOOLS,onClose:()=>setShowCompare(false),lang:lang}),
    React.createElement(Footer,{lang:lang})
  );
}

ReactDOM.render(React.createElement(App), document.getElementById("toolguide-root"));

})();
